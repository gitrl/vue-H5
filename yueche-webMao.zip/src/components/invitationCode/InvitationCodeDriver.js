require('normalize.css/normalize.css');
import Device from "../Devices";
import Path from "../url";
import ModalExamples from '../Bomb/bomb'
import React from 'react';
import {
  render,
  Link
} from 'react-router'
import {
  Button,
  Popover,
  PopoverTrigger,
} from 'amazeui-touch';
import $ from 'jquery'
import  '../../styles/App.css';
import  './invitate.css';
import driverbindingbtn_icon from '../../images/driverbindingbtn_icon .png';
import drivertxt_pic from '../../images/drivertxt_pic.png';
import rule from '../../images/invite/txt.png';


class AppComponent extends React.Component {
  constructor(props){
    super(props);
    this.state={
      flag:false,
      content:"",
      show:false
    }

  }
  componentWillMount(){
    document.title='邀请码'
    // document.body.style.overflowY='hidden';
  }
  //获得角度
   getAngle(angx, angy) {
    return Math.atan2(angy, angx) * 180 / Math.PI;
  };

  //根据起点终点返回方向 1向上 2向下 3向左 4向右 0未滑动
   getDirection(startx, starty, endx, endy) {
      var angx = endx - startx;
      var angy = endy - starty;
      var result = 0;

      //如果滑动距离太短
      if (Math.abs(angx) < 2 && Math.abs(angy) < 2) {
        return result;
      }

      var angle = this.getAngle(angx, angy);
      if (angle >= -135 && angle <= -45) {
        result = 1;
      } else if (angle > 45 && angle < 135) {
        result = 2;
      } else if ((angle >= 135 && angle <= 180) || (angle >= -180 && angle < -135)) {
        result = 3;
      } else if (angle >= -45 && angle <= 45) {
        result = 4;
      }

      return result;
  }
  componentDidMount(){
    var _this = this
    // var startx, starty;
    //
    // //手指接触屏幕
    // document.addEventListener("touchstart", function(e) {
    //   startx = e.touches[0].pageX;
    //   starty = e.touches[0].pageY;
    // }, false);
    // //手指离开屏幕
    // document.addEventListener("touchend", function(e) {
    //   var  letters = _this.refs.test;
    //   var  letter = _this.refs.test2
    //   var endx, endy;
    //   endx = e.changedTouches[0].pageX;
    //   endy = e.changedTouches[0].pageY;
    //   var direction = _this.getDirection(startx, starty, endx, endy);
    //   switch (direction) {
    //     case 0:
    //       // alert("未滑动！");
    //       break;
    //     case 1:
    //       // alert("向上！")
    //       // document.body.style.overflowY='scroll';
    //       letters.scrollIntoView(true)
    //       break;
    //     case 2:
    //       letter.scrollIntoView(true)
    //       break;
    //     case 3:
    //       // alert("向左！")
    //       break;
    //     case 4:
    //       // alert("向右！")
    //       break;
    //     default:
    //   }
    // }, false);

  }
  /*关闭页面*/
  closePage=()=>{
    if(Device.getMobileOperatingSystem()=='Android'){
      window.just_android.closeWeb();
    }
    else{
      // ios
      window.webkit.messageHandlers.closeWeb.postMessage({});
    }
  };
  closeModal=()=>{
    this.setState({
      flag: false
    });
  };
  bindCode(){
    var url = Path.getUrl(1);
    var _this = this;
    var param = Path.GetRequest();
    var userId = param.userId;
    var code  = this.refs.ivcode.value;
    if(code == ''){
      _this.setState({ flag: true,content:'邀请码不能为空'});
      return;
    }
    $.ajax({
      url:url+'/passport/updateinviter',
      type:'post',
      data:{
        ivcode:code,
        userId:userId
      },
      success:function(data){
        console.log(data);
        if(data.code == 200){
            _this.setState({ show: true});
            setTimeout(function () {
              _this.closePage()
            },2000)
        }
        else {
          _this.setState({ flag: true,content:data.msg,show:false});
        }
      }
    })
  }

  /*关闭页面*/
  closePage=()=>{
    if(Device.getMobileOperatingSystem()=='Android'){
      window.just_android.closeWeb();
    }
    else{
      // ios
      window.webkit.messageHandlers.closeWeb.postMessage({});
    }
  };
  render() {
    var style={display:this.state.show?'block':'none'};
    return (
        <div className="bigBox dirverBox">
          <div className=" inviteCode" ref="test2">
            <header className="textPic textAlign"><img src={drivertxt_pic} alt=""/></header>
            <section className="outsideBox">
              <div className="codebigBox">
                <div className="middleBox marginCenter">
                  <div className="lastBox marginCenter">
                    <div className="lastBoxText">请输入好友邀请码</div>
                    <input className='inputInviteCode' type="text" ref="ivcode"/>
                    <div className="popover" style={style}>绑定成功</div>
                  </div>
                </div>
              </div>
              <div className="bindingBtn">
                  <img src={driverbindingbtn_icon} onClick={this.bindCode.bind(this)} alt=""/>
              </div>
            </section>
            <div className="closeWeb closeWebDriver" onClick={this.closePage}>没有邀请码，点击跳过 ></div>
            <section className="bindActiviteRule bindActiviteRuleDriver">
              <div className="bindActRuleCon">
                <div className="hunguanImg"><img src={rule} alt=""/></div>
                <div>
                  <p>1、未使用过牦牛出行的好友，可通过您分享的推荐链接领取牦牛出行优惠券（券有效期为7天）</p>
                  <p>2、您的好友在成功注册成为牦牛出行用户后，您便可以获得5元推荐奖励；
                    您的好友在领取本活动牦牛出行10元优惠券后7天内第一次体验牦牛出行网约车，并成功付款后，您可得到积分奖励。在活动期间，
                    您可获得好友每次打车总金额3%的高额积分奖励，并可将积分兑换成等额优惠券，奖金优渥，等你来拿！
                  </p>
                  <p>3、拥有相同设备（手机），账户，手机号，微信号，支付账号，银行卡号的用户将被视为同一用户（适用于您与您的好友），
                    本活动仅对成功推荐好友完成并支付首次牦牛出行网约车订单的用户发放推荐奖励。
                  </p>
                  <p>4、针对违规推荐奖励的行为，将不予发放推荐奖励，追回相关奖励或封停账号、并依法追究其法律责任。</p>
                </div>
                <div className="fontSize175">活动详情咨询 <span className="colorB">400-656-2666</span></div>
              </div>
            </section>
            <ModalExamples state={this.state.flag} closeModal={this.closeModal} content={this.state.content}/>
          </div>
        </div>

    );
  }
}

export default AppComponent;

import React from 'react';
import {
  render,
  Link
} from 'react-router'
import $ from 'jquery'
import '../../styles/public.css'
import './invitate.css'
import Path from "../url";
import daddd_pic from '../../images/invite/daddd_pic.png'
import cli_pic from '../../images/invite/cli_pic.png'
class AppComponent extends React.Component {
  constructor(props){
    super(props)
    this.state = {
      ivCode:'',
    }
  }
  componentWillMount(){
    document.title='邀请注册';
  }
  componentDidMount(){
    var _this = this;
    var param = Path.GetRequest();
    var userType = param.userType;
    if(userType == 1 ){
      var url = Path.getUrl(2);
      url = url +'select-byprimarykey?userId='+ param.userId
    }
    if(userType == 6){
      var url = Path.getUrl(1);
      url = url +'select-byprimarykey?userId='+ param.userId
    }
    $.ajax({
      url:url,
      type:'get',
      success:function(data){
        if (data.code == 200 && data.data != undefined){
          _this.setState({ivCode: data.data.ivcode})
        }
        else {
          _this.setState({ivCode: "获取失败"})
        }

      },
      error:function (e) {
        console.log(e)
      }
    })
  }

  render() {
    var style={display:this.state.show?'block':'none'};
    return (
      <section className="passengerReg">
        <div className="passengerRegTOP"><Link to="/ycUser/invitateRule"><img src={daddd_pic} alt=""/></Link></div>
        <div className="p_InviteCode">
          <div className="p_inviteHeng"></div>
          <div className="p_InviteCodeCon">
            <div className="p_InviteCodeConTop">
              <div className="p_InviteHeader">好友邀请码</div>
              <div className="p_CodeCon">{this.state.ivCode}</div>
            </div>
            <div  className="textAlign downloaderweima">
              <img className="downloadImg" src={cli_pic} alt=""/>
              <div className="marginT1 textAlign fontS15">扫码下载牦牛出行</div>
            </div>
          </div>
        </div>
      </section>
    );
  }
}

export default AppComponent;

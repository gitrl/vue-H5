require('normalize.css/normalize.css');
import React from 'react';
import {
  Card
} from 'amazeui-touch';
import  '../../styles/App.css';
import '../../styles/rule.css'
import  './invitate.css';
import name_pic from '../../images/name_pic.png';
import pay_pic from '../../images/pay_pic.png';
import invite_pic from '../../images/invite_pic.png';
import {
  render,
  Link
} from 'react-router'

class AppComponent extends React.Component {
  constructor(){
    super();
  }
  componentWillMount(){
    document.title='活动规则'
    document.body.style.background='#fff';
  }
  componentDidMount(){

  }

  render() {
    return (
      <section className="index">
        <div className="activiteRule">
          <Card
            header="活动内容" className="activiteRuleCon fontS15">
            <p>活动时间：2018.09.10-2018.12.10</p>
            活动简介：邀请好友体验快捷键舒适的牦牛出行网约车，好友注册成功后您可获得5元牦牛出行优惠券，
            您的好友将获得10元首单优惠券，每当您的1位好友完成第一次牦牛出行行程并成功支付订单，您便可获得推荐积分奖励。
            积分可无限累积并兑换优惠券，并可用于支付车费。
          </Card>
          <Card header="参与流程" className="activiteRuleCon fontS15">
            <div className="flexBox">
              <div className="">
                <div className="JoinStep">01</div>
                <div>
                  进入牦牛出行“推荐有奖”或
                  进入好友的“推荐有奖”链接
                </div>
              </div>
              <div><img src={name_pic} alt=""/></div>
            </div>
            <div className="flexBox">
              <div className="">
                <div className="JoinStep">02</div>
                <div>
                  根据页面提示获得您的
                  专属推荐有奖链接
                </div>
              </div>
              <div><img src={invite_pic} alt=""/></div>
            </div>
            <div className="">
              <div className="JoinStep">03</div>
              <div>分享给您的好友</div>
              <div className='dashBorder'>
                <div className='recomdToApp'>推荐好友成为乘客</div>
                <p>1. 您的好友填写您分享的邀请码，完成注册并领取60元新人礼包</p>
                <p className='flexBox'>
                  2. 您的好友完成第一次快车行程并完成订单支付
                  <img src={pay_pic} alt=""/>
                </p>
                <p>3. 您获得5元现金券及积分奖励</p>
              </div>
              <div className='dashBorder'>
                <div className='recomdToApp'>推荐好友成为司机</div>
                <p>1. 您的好友填写您分享的邀请码，完成注册并审核通过</p>
                <p>2. 您获得5元现金券及积分奖励</p>
              </div>
            </div>
          </Card>
        </div>
        <div className="rule-explain bgcolorW padding2 fontSize163">
          <h3>活动说明</h3>
          <p><span>*</span>未使用过牦牛出行的好友，可通过您分享的推荐链接领取牦牛出行优惠券（券有效期为7天）</p>
          <p>
            <span>*</span>
            您的好友在成功注册成为牦牛出行用户后，您便可以获得5元推荐奖励；
            您的好友在领取本活动牦牛出行10元优惠券后7天内第一次体验牦牛出行网约车，并成功付款后，您可得到积分奖励。在活动期间，
            您可获得好友每次打车总金额3%的高额积分奖励，并可将积分兑换成等额优惠券，奖金优渥，等你来拿！
          </p>
          <p>
            <span>*</span>
            拥有相同设备（手机），账户，手机号，微信号，支付账号，银行卡号的用户将被视为同一用户（适用于您与您的好友），
            本活动仅对成功推荐好友完成并支付首次牦牛出行网约车订单的用户发放推荐奖励。
          </p>
          <p><span>*</span>针对违规推荐奖励的行为，将不予发放推荐奖励，追回相关奖励或封停账号、并依法追究其法律责任。</p>
          <div>活动详情咨询：400-656-2666</div>
        </div>
      </section>
    );
  }
}

export default AppComponent;

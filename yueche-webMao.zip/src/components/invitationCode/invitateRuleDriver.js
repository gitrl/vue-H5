require('normalize.css/normalize.css');
import React from 'react';
import {
  Card
} from 'amazeui-touch';
import  '../../styles/App.css';
import '../../styles/rule.css'
import  './invitate.css';
import driverinvite_pic from '../../images/driverinvite_pic.png';
import driverpay_pic from '../../images/driverpay_pic.png';
import driverperson_pic from '../../images/driverperson_pic.png';
import {
  render,
  Link
} from 'react-router'

class AppComponent extends React.Component {
  constructor(){
    super();
  }
  componentWillMount(){
    document.title='活动规则'
    document.body.style.background='#fff';
  }
  componentDidMount(){

  }

  render() {
    return (
      <section className="index">
        <div className="activiteRule invitateRuleDriver">
          <Card
            header="活动内容" className="activiteRuleCon fontS15">
            <p>活动时间：2018.09.10-2018.12.10</p>
            活动简介：邀请好友成为牦牛司机，好友与您都将获得5元现金奖励。邀请好友体验快捷舒适的牦牛出行网约车，
            好友将享受首单10元优惠券奖励，您可获得5元现金券奖励。
            每当您的1位好友完成牦牛出行行程并成功支付订单，您便可获得推荐奖励。金额将存如您的账户，可提现。
          </Card>
          <Card header="参与流程" className="activiteRuleCon fontS15">
            <div className="flexBox">
              <div className="">
                <div className="JoinStep">01</div>
                <div>
                  进入牦牛出行“推荐有奖”或
                  进入好友的“推荐有奖”链接
                </div>
              </div>
              <div><img src={driverperson_pic} alt=""/></div>
            </div>
            <div className="flexBox">
              <div className="">
                <div className="JoinStep">02</div>
                <div>
                  根据页面提示获得您的
                  专属推荐有奖链接
                </div>
              </div>
              <div><img src={driverinvite_pic} alt=""/></div>
            </div>
            <div className="">
              <div className="JoinStep">03</div>
              <div>分享给您的好友</div>
              <div className='dashBorder'>
                <div className='recomdToApp'>推荐好友成为乘客</div>
                <p>1. 您的好友填写您分享的邀请码，完成注册并领取60元新人礼包</p>
                <p className='flexBox'>
                  2. 您的好友完成第一次快车行程并完成订单支付
                  <img src={driverpay_pic} alt=""/>
                </p>
                <p>3. 您获得5元现金券及积分奖励</p>
              </div>
              <div className='dashBorder'>
                <div className='recomdToApp'>推荐好友成为司机</div>
                <p>1. 您的好友填写您分享的邀请码，完成注册并审核通过</p>
                <p>2. 您获得5元现金券及积分奖励</p>
              </div>
            </div>
          </Card>
        </div>


        <div className="rule-explain bgcolorW padding2 fontSize163">
          <h3>活动说明</h3>
          <p><span>*</span>您可邀请您的好友成为牦牛出行司机，邀请成功后您与您的好友均将获得5元现金奖励。</p>
          <p>
            <span>*</span>
            邀请您的好友体验牦牛出行的优质服务。您的好友在成功注册成为牦牛出行用户后，您便可以获得5元推荐奖励；
            您的好友在领取本活动牦牛出行10元优惠券后7天内第一次体验牦牛出行网约车，并成功付款后，您可得到推荐奖励。
            在活动期间，您可获得好友每次打车总金额3%的高额推荐奖励，并可将推荐奖励提现。奖金优渥，等你来拿！
          </p>
          <p>
            <span>*</span>
            拥有相同设备（手机）、账户、手机号、微信号、支付账号、银行卡的用户被视为同一用户（适用于您与您的好友），
            本活动仅对成功推荐好友完成并支付首次牦牛出行网约车订单的用户发放推荐奖励。
          </p>
          <p><span>*</span>针对违规推荐奖励的行为，将不予发放推荐奖励、追回相关奖励或封停账号、并依法追究其法律责任。</p>
          <div >活动详情咨询：400-656-2666</div>
        </div>
      </section>
    );
  }
}

export default AppComponent;

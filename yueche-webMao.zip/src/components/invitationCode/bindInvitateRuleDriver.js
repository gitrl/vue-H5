require('normalize.css/normalize.css');
import React from 'react';
import {
  Card
} from 'amazeui-touch';
import  '../../styles/App.css';
import '../../styles/rule.css'
import  './invitate.css';
import rule from '../../images/invite/txt.png';
import kuang from '../../images/invite/kuang.png';
import {
  render,
  Link
} from 'react-router'

class AppComponent extends React.Component {
  constructor(){
    super();
  }
  componentWillMount(){
    document.title='绑定邀请码'
  }
  componentDidMount(){

  }

  render() {
    return (
      <section className="bindActiviteRule bindActiviteRuleDriver">
        <div className="hunguanImg"><img src={rule} alt=""/></div>
        <div className="bindActRuleCon">
          <div>
            <p>1、未使用过牦牛出行的好友，可通过您分享的推荐链接领取牦牛出行优惠券（券有效期为7天）</p>
            <p>2、您的好友在成功注册成为牦牛出行用户后，您便可以获得5元推荐奖励；
              您的好友在领取本活动牦牛出行10元优惠券后7天内第一次体验牦牛出行网约车，并成功付款后，您可得到积分奖励。在活动期间，
              您可获得好友每次打车总金额3%的高额积分奖励，并可将积分兑换成等额优惠券，奖金优渥，等你来拿！
            </p>
            <p>3、拥有相同设备（手机），账户，手机号，微信号，支付账号，银行卡号的用户将被视为同一用户（适用于您与您的好友），
              本活动仅对成功推荐好友完成并支付首次牦牛出行网约车订单的用户发放推荐奖励。
            </p>
            <p>4、针对违规推荐奖励的行为，将不予发放推荐奖励，追回相关奖励或封停账号、并依法追究其法律责任。</p>
          </div>
          <div className="fontSize175">活动详情咨询 <span className="colorB">400-656-2666</span></div>
        </div>
      </section>
    );
  }
}

export default AppComponent;

import React from 'react';
import {
  Container,
  Accordion,
} from 'amazeui-touch';
import '../../styles/public.css'
import '../ycUser/rule/rule.css';
class AccordionExample extends React.Component{
  componentWillMount(){
    document.title='乘车规则';
    document.body.style.background='#fff';
  }
  render() {
    return (
      <div className="index">
        <div className="cancelRule">
          <div className="rule-header fontSize25">乘车说明</div>
          <div className="rule-content">
            <p>1、接站：哈达、矿泉水接站，机场等待不超过1小时，火车站不等待</p>
            <p>2、送站：飞机提前3.5小时左右出发，火车提前2小时左右出发 </p>
            <p>3、等待：返航晚点免费等待，免费再派车</p>
            <p>4、价格：价格统一，24小时服务，早晚班、淡旺季不变价</p>
            <p>5、 接单：24小时接单，临时单80%异构拼车方式处理，为保证服务质量，
              提前1日18：00发的业务单中心无条件安排，建议提前发单。（截至收单为头一天的18：00）
            </p>
          </div>
        </div>
        <div className="cancelRule">
          <div className="rule-header border-top fontSize25">取消规则</div>
          <div className="rule-content">
            <p>航班起飞、到达前5小时免费取消，火车发车、到站前3小时免费取消，其他用车提前5小时免费取消。</p>
          </div>
        </div>
      </div>
    );
  }
};
export default AccordionExample;

require('normalize.css/normalize.css');
require('styles/public.css');
require('styles/App.css');
import React from 'react';

class ResComponent extends React.Component {
  componentWillMount(){
    document.title='服务标准及违约责任认定';
  }
  render() {
    return (
      <div className="index">
        <div className='fee-reason bgcolorW padding10'>
          <h3 className='textAlign'>服务标准及违约责任认定</h3>
            <p className="colorGray fontSize15 ">
              1、打开牦牛打车软件，确认出车或收车，出车为接单，收车为不接单，并按全部按钮，确认接收实时、预约或全部订单，
              实时为10分钟可以到达的订单，预约为半小时以上到达的订单，全部为两种订单均接收，然后准备抢单。接收订单时要注意看清订单内容，尤其是上车和到达地点，防止盲目或错误接单；
            </p>
            <p className="colorGray fontSize15 ">
              2、听到订单提示音，三秒之后要迅速按下抢单按钮，确认抢单（抢单时间为20秒）成功后应立即按手机上的电话按钮，主动与客户联系确认，
              话术为：您好！我是牦牛专车司机刘先生，您是从上地去西单吗？请问您的具体上车地点，我会准时到达，请您稍后；
            </p>
        </div>
      </div>
    );
  }
}

export default ResComponent;

//积分兑换
import Path from "../../url";
require('normalize.css/normalize.css');
import React from 'react';
import  '../../../styles/public.css';
import  '../recomdNewUser/receiveCoupon.css';
import './newUserIdentity.css'
import $ from 'jquery'
import gift_pic from '../../../images/gift_piciden.png'
import unselect from '../../../images/unselect.png'
import select from '../../../images/select.png'
import Device from "../../Devices";
class AppComponent extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      show:false,
      txtCon:'',
      mobileNum:''
    }
  }
  componentWillMount(){
    document.title='身份确认'
  }
  componentDidMount(){
    var img = document.querySelector('.localer');
    var img2 = document.querySelector('.traveler');
    img.onclick = function () {
      var src = this.getAttribute('src');
      if(src == unselect ) {
        this.setAttribute('src', select);
        img2.setAttribute('src',unselect)
      }
      else {
        this.setAttribute('src',select);
        img2.setAttribute('src',unselect)
      }
    }
    img2.onclick = function () {
      var src = this.getAttribute('src');
      if(src == unselect ) {
        this.setAttribute('src', select);
        img.setAttribute('src',unselect)
        // $(this).parent()[0].nextSibling.children[0].src=unselect
      }
      else {
        this.setAttribute('src',select);
        img.setAttribute('src',unselect)
        // $(this).parent()[0].nextSibling.children[0].src=select
      }
    }
  }
  getCoupon(){
    var that = this;
    var url = Path.getUrl(2);
    var imgs = document.querySelectorAll('.chanceToIdentiey img');
    var userIdenty;
    var locals;
    //获取url参数
    var param = Path.GetRequest();
    var userId = param.userId
    for(var i =0; i<imgs.length; i++){
      if(imgs[i].getAttribute('src') == select){
        userIdenty = imgs[i].nextSibling.innerHTML
      }
    }
    if(userIdenty == undefined){
      that.setState({ show:true,txtCon:"请选择您的身份"});
      setTimeout(function () {
        that.setState({ show: false});
      },1500);
      return;
    }
    if(userIdenty == '我是本地人'){
      locals = 1
    }
    if(userIdenty == '我是旅行者'){
      locals = 0
    }
    //立即领取
    $.ajax({
      // url:url + '/passengerinfo/updatepassenegerinformationForH5',
      url:'https://user-passeneger.maoniuchuxing.com/v1.0/passengerinfo/updatepassenegerinformationForH5',
      // url:'http://192.168.1.237:8899/usercenter-passengers/v1.0/passengerinfo/updatepassenegerinformationForH5',
      type:'post',
      data:{
          userId:userId,
          locals:locals
        },
      dataType:'json',
      success:function (data) {
        console.log(data);
        if(data.code == 200){
          that.setState({ show:true,txtCon:"领取成功"});
          setTimeout(function () {
            that.setState({ show: false});
            that.closePage()
          },1500);
        }
      }
    })
  }
  /*关闭页面*/
  closePage=()=>{
    if(Device.getMobileOperatingSystem()=='Android'){
      window.just_android.closeWeb();
    }
    else{
      // ios
      window.webkit.messageHandlers.closeWeb.postMessage({});
    }
  };
  render() {
    var style={display:this.state.show?'block':'none'};
    return (
      <section className="couponContent chanceIdentity">
        <div className='gift_pic'><img src={gift_pic} alt=""/></div>
        <div className="couponConBottom">
          {/*<div className='textAlign coloWhite'>优惠券已放入账号:{this.state.mobileNum}</div>*/}
          <div className="couponTypeList">
            <div className='couponType'>首单优惠券10元</div>
            <ul>
              <li><span className='circleList'></span>最高抵扣10元</li>
              <li><span className='circleList'></span>有效期：7天内有效</li>
            </ul>
          </div>
          <div className="couponTypeList">
            <div className='couponType'>10元优惠券 x 2张</div>
            <ul>
              <li><span className='circleList'></span>满60元可用</li>
              <li><span className='circleList'></span>有效期：15天内有效</li>
            </ul>
          </div>
          <div className="couponTypeList">
            <div className='couponType'>15元优惠券 x 2张</div>
            <ul>
              <li><span className='circleList'></span>满80元可用</li>
              <li><span className='circleList'></span>有效期：15天内有效</li>
            </ul>
          </div>
          <div className="userIdentityCon coloWhite">
            <div className=" fontSize163">请选择您的身份</div>
            <div className="chanceToIdentiey fontS15">
              <div>
                <img className="localer" src={unselect} alt=""/><span>我是本地人</span>
              </div>
              <div>
                <img className="traveler" src={unselect} alt=""/><span>我是旅行者</span>
              </div>
            </div>
            <div className="textAlign" >
                <button className="receiveCoupon" onClick={this.getCoupon.bind(this)}>立即领取优惠券</button>
            </div>
            <div className="popover" style={style}>{this.state.txtCon}</div>
          </div>
        </div>
      </section>
    );
  }
}
export default AppComponent;

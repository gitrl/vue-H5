import React from 'react'
require('normalize.css/normalize.css');
import '../../../styles/public.css'
import './newUserIdentity.css'
import $ from 'jquery'
import unselect from '../../../images/unselect.png'
import select from '../../../images/select.png'
import rightnow from '../../../images/rightnow.png'
class AppComponent extends React.Component{
  componentWillMount(){
    document.title='身份确认'
  }
  componentDidMount() {
    var img = document.querySelector('.localer');
    var img2 = document.querySelector('.traveler');
      img.onclick = function () {
        var src = this.getAttribute('src');
        if(src == unselect ) {
          this.setAttribute('src', select);
          img2.setAttribute('src',unselect)
          // console.log($(this).parent());
          // $(this).parent()[0].previousSibling.children[0].src=unselect
        }
        else {
          this.setAttribute('src',select);
          img2.setAttribute('src',unselect)
        }
      }
    img2.onclick = function () {
      var src = this.getAttribute('src');
      if(src == unselect ) {
        this.setAttribute('src', select);
        img.setAttribute('src',unselect)
        // $(this).parent()[0].nextSibling.children[0].src=unselect
      }
      else {
        this.setAttribute('src',select);
        img.setAttribute('src',unselect)
        // $(this).parent()[0].nextSibling.children[0].src=select
      }
    }

  }
  getCoupon(){
    var imgs = document.querySelectorAll('.chanceToIdentiey img');
    for(var i =0; i<imgs.length; i++){
      if(imgs[i].getAttribute('src') == select){
        var userIdenty = imgs[i].nextSibling.innerHTML
        // console.log(imgs[i].nextSibling.innerHTML)
      }
    }
    $.ajax({
      url:'http://192.168.1.237:13122/v1.0/passengerinfo/updatepassenegerinformation',
      type:'put',
      data:{
        userId:'244575415',
        locals:'1'
      },
      dataType:'json',
      success:function (data) {
        console.log(data);
      }
    })
  }
    render(){
    return(
      <div className="userIdentity">
        <div className="userIdentityCon coloWhite">
          <div className=" fontSize2">请选择您的身份</div>
          <div className="chanceToIdentiey fontS15">
            <div>
              <img className="localer" src={unselect} alt=""/><span>我是本地人</span>
            </div>
            <div>
              <img className="traveler" src={select} alt=""/><span>我是旅行者</span>
            </div>
          </div>
          <div className="getCoupon"><img src={rightnow} onClick={this.getCoupon} alt=""/></div>
        </div>
      </div>
    )
  }
}
export default AppComponent;

import React from 'react';
import '../../download/download.css'
import $ from 'jquery'
import Path from "../../url";
import Downlogo_pic from '../../../images/coupondownlogo_pic.png'
import Android_icon from '../../../images/couponandroid_icon.png'
import Iphone_icon from '../../../images/couponiphone_icon.png'
import Yddownload_pic from '../../../images/yddownload_pic.png'
// import ModalExamples from '../Bomb/bomb'
import {
  Group,
  Button,
  ButtonGroup,
  Icon,
  Badge,
  Popover,
  PopoverTrigger,
  Field,
  List,
} from 'amazeui-touch';
class AppComponent extends React.Component {
  constructor(){
    super();
    this.state={
      isShow:false,//蒙层
      flag:false,
      content:''
    }
  };
  componentWillMount(){
    document.title='牦牛出行下载'
  };
//判断是否微信登陆
  isWeiXin() {
    var ua = window.navigator.userAgent.toLowerCase();
    // console.log(ua);
    if (ua.match(/MicroMessenger/i) == 'micromessenger') {
      return true;
    } else {
      return false;
    }
  }
  componentDidMount(){
    document.body.style.background='#fff';
    var ua = navigator.userAgent.toLowerCase();
    if (ua.match(/MicroMessenger/i) == "micromessenger") {
      // console.log(" 是来自微信内置浏览器")
      this.setState({isShow:true});
    }
    else {
      // console.log("不是来自微信内置浏览器")
      this.setState({isShow:false});
    }


  };
  getDownload(device,projectCode){
    var _that = this;
    var url = Path.getUrl("down");
    if(_that.isWeiXin()){
      this.setState({isShow:true});
    }
    else {
      $.ajax({
        url:url,
        type:'get',
        data:{
          projectCode:projectCode,
          buildCode:0,
          device:device
        },
        dataType:'json',
        success:function (data) {
          console.log(data);
          window.location.href = data.data.downloadUrl
        }
      })
    }
  }
  showM(){
    this.setState({flag:!this.state.flag,content:"敬请期待。。。"});
    //判断是否事微信内置浏览器
    if(this.isWeiXin()){
      this.setState({isShow:true});
    }
    else {

    }
  }
  closeModal=()=>{
    this.setState({
      flag: false
    });
  };

  closeM(){
    this.setState({isShow:false,flag: !this.state.flag,content:"敬请期待。。。"})
  }
  render() {
    var style = {display:this.state.isShow?'block':'none'};
    return (
      <div className="download couponDownload">
        <div className='download-content'>
          <div className='download-logo'>
            <img src={Downlogo_pic} alt=""/>
          </div>
          <div className='download-btn'>
            <Button
              amStyle="secondary"
              onClick={this.getDownload.bind(this,1,1)}
            >
              <img src={Android_icon} alt=""/>
              Android下载
              {/*<a href="http://www.maoniuchuxing.com:1145/client-online-release.apk">Android下载</a>*/}
            </Button>
          </div>

          <div className='download-btn'>
            <Button
              amStyle="secondary"
              onClick={this.getDownload.bind(this,2,2)}
            >
              <img src={Iphone_icon} alt=""/>
              iPhone下载
              {/*<a href="https://itunes.apple.com/cn/app/%E7%89%A6%E7%89%9B%E5%87%BA%E8%A1%8C/id1346482679?mt=8">iPhone下载</a>*/}
            </Button>
          </div>
        </div>
        {/*<ModalExamples state={this.state.flag} closeModal={this.closeModal} content={this.state.content}/>*/}
        <div className='modal-backdrop' style={style} onClick={this.closeM.bind(this)}><img src={Yddownload_pic} alt=""/></div>
      </div>
    );
  }
}

export default AppComponent;

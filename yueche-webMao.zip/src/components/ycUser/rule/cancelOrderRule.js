import React from 'react';
import {
  Container,
  Accordion,
} from 'amazeui-touch';
import '../../../styles/public.css'
import './rule.css'
class AccordionExample extends React.Component{
  componentWillMount(){
    document.title='订单取消规则';
    document.body.style.background='#f4f4f4';
  }
  render() {
    return (
      <div className="index userCancel">
        <div className="cancelRule bgcolorW">
          <div className="rule-header fontSize25">您需支付司机补偿费的情况</div>
          <div className="rule-content">
            <p>1.司机正常到达，乘客取消。</p>
            <p>2.司机正常到达，多次无法联系到乘客，任意方取消。</p>
            <p>3.司机正常到达，乘客迟到五分钟，任意方取消。</p>
          </div>
        </div>
        <div className="cancelRule bgcolorW">
          <div className="rule-header fontSize25">您无需支付司机补偿费的情况</div>
          <div className="rule-content">
            <p>1.乘客在3分钟内取消订单。</p>
            <p>2.司机未在规定时间内到达上车点，乘客取消订单。</p>
            <p>3.乘客多次无法联系到司机，乘客取消订单。</p>
          </div>
        </div>
        <div className="cancelRule bgcolorW">
          <div className="rule-header fontSize25">司机补偿费的计算方式</div>
          <div className="rule-content">
            <p>1.若司机空驶小于1公里，您需支付3元补偿费。</p>
            <p> 2.若司机空驶大于1公里，超过部分每公里支付1元补偿费，总共补偿费不超过5元。</p>
          </div>
        </div>
      </div>
    );
  }
}

export default AccordionExample;

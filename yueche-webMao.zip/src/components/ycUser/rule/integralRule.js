require('normalize.css/normalize.css');
require('styles/public.css');
require('styles/App.css');
import React from 'react';
class Pro2Component extends React.Component {
  componentWillMount(){
    document.title='积分规则';
  }
  componentDidMount(){
    document.body.style.background='#f4f4f4';
  };
  render() {
    return (
      <div className="index">
          <div className=" bgcolorW padding2 margin25">
            <div>
              <p className="fontSize25 colorg">
                每次行程消费金额即为积分数量，每10积分抵扣1元，每次行程结束自动抵扣积分。</p>
            </div>
          </div>
      </div>
    );
  }
}

export default Pro2Component;

import React from 'react';
import {
  Container,
} from 'amazeui-touch';
import '../../../styles/public.css'
import './rule.css'
class AccordionExample extends React.Component{
  componentWillMount(){
    document.title='计价规则';

  }
  componentDidMount(){
    document.body.style.background='#f4f4f4';
  };
  render() {
    return (
      <div className="index">
        <Container {...this.props} className="padding5 fontSize25">
            <div className="bgcolorW borderR10 padding10">
                <ul className="yc-rule valuation">
                  <p className="fontSize2 textAlign ">出租车普通订单</p>
                  <li>实时最低消费 <span>10元 (3KM以内)</span></li>
                  <li>
                    里程费(超出3公里)
                    <p className="fontSize2">07:00-00:00 <span>2.0元/公里</span></p>
                    <p className="fontSize2">00:00-07:00 <span>2.4元/公里</span></p>
                  </li>
                  <li>时长费 <span>0.25元/分钟</span></li>
                  <li>
                    远途费(超出8公里)
                    <p className="fontSize2">正常时段: <span>2 * 1.5 = 3元/公里</span></p>
                    <p className="fontSize2">夜间时段:<span>2.4 * 1.5 = 3.6元/公里</span></p>
                  </li>

                  {/*<div className="rule-explain bgcolorW fontSize163">*/}
                    {/*<p className="padding3"><span>*</span>超出8公里后，需加收50%空载返程费</p>*/}
                  {/*</div>*/}
                </ul>
            </div>
      </Container>
      </div>
    );
  }
};

export default AccordionExample;

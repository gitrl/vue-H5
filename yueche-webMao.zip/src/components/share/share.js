import React from 'react';
import '../../styles/public.css'
import './share.css'
import logo_icon from '../../images/logo_icon.png'
import airplay_pic from '../../images/airplay_pic.png'
import choose_icon from '../../images/choose_icon.png'
import nochoose_icon  from '../../images/nochoose_icon .png'
import person_pic  from '../../images/person_pic.png'
class AppComponent extends React.Component {
  componentWillMount(){
    document.title='邀请好友';
  }
  componentDidMount(){
    document.body.style.background='#f4f4f4';
  }
  changeSelected(e){
    var src = this.refs.readRule.src;
    console.log(src)
    if(src == choose_icon){
      e.target.setAttribute("src",nochoose_icon )
    }
    else
      {
      e.target.setAttribute("src",choose_icon )
    }
  }
  render() {
    return (
      <section className="share">
        <div className='share-top bgcolorW'>
          <div className='share-logo'><img src={logo_icon} alt=""/></div>
          <div className='fire-logo'><img src={airplay_pic} alt=""/></div>
          <div>
            <div className='share-hello fontSize2'>您的好友邀您体验牦牛出行</div>
            <div className='share-new fontSize2'>送您100元新人礼包！</div>
            <div className='share-bg'><img src={person_pic} alt=""/></div>
          </div>
        </div>
        <div className='share-Num'>
          <input type="text" placeholder='请输入手机号'/>
          <button>立即领取</button>
          <div className='agreen-rule'>
          <img src={choose_icon} alt="" onClick={this.changeSelected.bind(this)} ref='readRule'/>
            <span>我已阅读并同意牦牛出行的 <a href="">【活动规则】</a></span>
          </div>
        </div>
      </section>
    );
  }
}

export default AppComponent;

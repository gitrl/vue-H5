import React from 'react';
import {
  Container,
} from 'amazeui-touch';
import '../../../styles/public.css'
import '../../../styles/rule.css'
class AccordionExample extends React.Component{
  componentWillMount(){
    document.title='规则';
  }
  componentDidMount(){
    document.body.style.background='#f4f4f4';

  };
  render() {

    return (
      <div className="index">
        <Container {...this.props} className="padding5 fontSize25">
            {/*<div className="bgcolorW borderR10 padding10">*/}
                {/*<ul className="yc-rule">*/}
                  {/*<p className="fontSize2 textAlign">分成规则</p>*/}
                  {/*<li>业务费用 <span>100%</span></li>*/}
                  {/*<li>订单奖励 <span>100%</span></li>*/}
                  {/*<li>附加费用 <span>100%</span></li>*/}
                  {/*<li>其他费用 <span>100%</span></li>*/}
                {/*</ul>*/}
                {/*<div className="rule-explain bgcolorW padding2 fontSize163">*/}
                  {/*<p><span>*</span>每单收入=业务费用+订单奖励+附加费用+其他费用。</p>*/}
                  {/*<p><span>*</span>业务费用包括里程费、时长费、远途费；附加费用包括高速费、路桥费、停车费。</p>*/}
                {/*</div>*/}
            {/*</div>*/}
          <div className="bgcolorW borderR10 margin25 padding10">
            <ul className="yc-rule">
              <p className="fontSize2 textAlign">提现规则</p>
              <li>发起提现时间 <span>每周星期二</span></li>
              <li>到账时间 <span>72小时内(节假日顺延)</span></li>
              <li>单日提现限额 <span>60000元</span></li>
              <li>提现次数 <span>当日上限3次</span></li>
              <li>单次最高提现金额 <span>20000元</span></li>
            </ul>
            <div className="rule-explain bgcolorW padding2 fontSize163">
              <p><span>*</span>仅支持提现到储蓄卡。</p>
              <p><span>*</span>注册名需与提现银行卡开户名一致。</p>
              <p><span>*</span>若出现提现失败的情况，请核查银行卡号以及姓名是否填写一致，并向对应银行咨询银行卡状态是否正常。</p>
            </div>
          </div>

      </Container>
      </div>
    );
  }
};

export default AccordionExample;

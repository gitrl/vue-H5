require('normalize.css/normalize.css');
import React from 'react';
require('styles/public.css');
import '../../../styles/rule.css'

class Pro2Component extends React.Component {
  componentWillMount(){
    document.title='取消规则';
  }
  componentDidMount(){
    document.body.style.background='#f4f4f4';
  };
  render() {
    return (
      <div className="index ">
        <div className='P_cancelRule'>
          <h3 className='textAlign fontSize2'>乘客取消</h3>
          <div className='responsibility fontSize2 boeder_bottom'>
            <h3 className='fontSize2'>无责取消情况</h3>
            <p>1.	司机接单后，实时订单乘客在2分钟内取消，预约订单乘客在预约出发时间45分钟之前取消。</p>
            <p>2.	司机未在规定时间内（实时订单从接单开始10分钟，预约订单从乘客预约出发时间开始10分钟）到达上车点，乘客取消</p>
            <p>3.	司机未朝上车点行驶，或以其他各种理由不来接，乘客取消</p>
            <p>4.	多次无法联系司机，乘客取消</p>
          </div>
          <div className='responsibility fontSize2'>
            <h3 className='fontSize2'>有责取消</h3>
            <p>司机到接单超过2分钟取消（如司机要求加价或者现金，不是订单显示车辆或司机，乘客无责）。 </p>
            <p>预约订单乘客在预约出发时间10分钟内取消（若因司机原因造成取消，如迟到、拒载等行为，乘客无责） </p>
          </div>
        </div>
      </div>
    );
  }
}

export default Pro2Component;

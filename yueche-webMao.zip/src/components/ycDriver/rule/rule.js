import React from 'react';
import {
  Container,
  Accordion,
} from 'amazeui-touch';
import '../../../styles/public.css'
import '../../../styles/rule.css'
import person from '../../../images/icontsrq.png'
class AccordionExample extends React.Component{
  componentWillMount(){
    document.title='评分规则';
    document.body.style.background='#f4f4f4';
  }
  render() {
    return (
      <div className="index">
          <Container {...this.props}>
          <Accordion defaultActiveKey={1}>
                <Accordion.Item
                  title="星级(默认5星)"
                  key={1}
                >
                    <ul className="yc-rule">
                      <li>五星 <span>+0.1</span></li>
                      <li>四星 <span>+0</span></li>
                      <li>三星 <span>-0.1</span></li>
                      <li>二星 <span>-0.3</span></li>
                      <li>一星 <span>-0.5</span></li>
                    </ul>
                </Accordion.Item>
          </Accordion>
          <Accordion defaultActiveKey={1}>
            <Accordion.Item
              title="附加分"
              key={1}
            >
              <p>
                <ul className="yc-rule" >
                  <li>神准时 <span>+0.1</span></li>
                  <li>认路回导航 <span>+0.1</span></li>
                  <li>服务态度好 <span>+0.1</span></li>
                  <li>安全又平稳 <span>+0.1</span></li>
                  <li>车辆干净整洁 <span>+0.1</span></li>
                  <li>打电话或抽烟  <span>-0.1</span></li>
                  <li>服务态度恶劣  <span>-0.1</span></li>
                  <li>开车太急  <span>-0.1</span></li>
                  <li>车辆脏乱<span>-0.1</span></li>
                  <li>未提醒系安全带  <span>-0.1</span></li>
                  <li>车辆或司机不符  <span>-0.1</span></li>
                </ul>
              </p>
            </Accordion.Item>
          </Accordion>
          <Accordion defaultActiveKey={1}>
            <Accordion.Item
              title="订单申诉"
              key={1}
            >
              <p>
                <ul className="yc-rule">
                  <li>乘客每次申诉成功<span>-0.5</span></li>
                </ul>
              </p>
            </Accordion.Item>
          </Accordion>
        </Container>
        <div className="rule-explain bgcolorW padding2">
          <p><span>*</span>考核成绩初始为80分。</p>
          <p><span>*</span>以上规则适用于累计接单到达40单以上的车主。</p>
          <p><span>*</span>一周内连续每天在线4小时以上，奖励3分</p>
          <p><span>*</span>以上规则最终解释权归牦牛用车所有。</p>
        </div>
      </div>
    );
  }
};

export default AccordionExample;

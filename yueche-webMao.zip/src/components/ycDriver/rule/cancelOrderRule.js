import React from 'react';
import {
  Container,
  Accordion,
} from 'amazeui-touch';
import '../../../styles/public.css'
import '../../../styles/rule.css'
class AccordionExample extends React.Component{
  componentWillMount(){
    document.title='订单取消规则';
    document.body.style.background='#f4f4f4';
  }
  render() {
    return (
      <div className="index driverCancel">
        <div className="cancelRule bgcolorW">
          <div className="rule-header fontSize25">您会被惩罚的情况</div>
          <div className="rule-content">
            <p>1.司机迟到，任意方取消。</p>
            <p>2.司机未到上车点就点击到达，并迟到，任意方取消。</p>
            <p>3.司机正常到达，乘客未迟到，司机取消订单。</p>
            <p>4.乘客多次无法联系到司机，任意方取消订单。</p>
          </div>
        </div>
        <div className="cancelRule bgcolorW">
          <div className="rule-header fontSize25">您不会被惩罚的情况</div>
          <div className="rule-content">
            <p>1.司机正常到达，乘客取消订单。</p>
            <p>2.司机正常到达，乘客到达5分钟，任意方取消订单。</p>
            <p>3.司机正常到达，多次无法联系到乘客，任意方取消。</p>
            <p>4.乘客多次无法联系到司机，任意方取消订单。</p>
            <p>5.司机在早晚高峰迟到不超过5分钟，乘客取消。</p>
            <p>7.司机正在路上并且没有迟到，乘客取消订单。</p>
          </div>
        </div>
        <div className="cancelRule bgcolorW">
          <div className="rule-header fontSize25">惩罚的计算方式</div>
          <div className="rule-content">
            <p>1.一天内第一次取消订单，扣取考核分1分。</p>
            <p> 2.第二次取消订单，扣取考核分1分并且罚款15元。</p>
            <p>3.第三次取消订单，罚款15元并且封号3天。</p>
            <p>4.预约和顺风车若是取消机场接送订单，扣分和罚款翻倍。</p>
          </div>
        </div>
      </div>
    );
  }
};

export default AccordionExample;

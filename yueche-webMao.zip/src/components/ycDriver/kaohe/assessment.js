require('normalize.css/normalize.css');
require('styles/public.css');
require('styles/assessment.css');
import $ from 'jquery'
import React from 'react';
import '../../../../public/js/font-awesome/css/font-awesome.min.css'
import img1 from '../../../images/inllustrate_icon.png';
class AppComponent extends React.Component {
  constructor(){
    super();
    this.state={
      flag:false,
      score:'80', //总分
      averageScore:'20%',  //星级
      complaintPercent:'20%',  //投诉率
      completePercent:'20%', //成交率
      dispatchPercent:'20%', //派单率
      defeatPercent:'20%'  //击败
    }
  };
  componentWillMount(){
   document.title='考核'
  };
  componentDidMount(){
    // var id = queryString.parse(_this.props.location.search);
    // console.log(id)
    document.body.style.background='#3A3A4F';
    var that = this;
    //获取司机分数
    // $.ajax({
    //   type:'get',
    //   url:'http://192.168.1.57:8081/yueche-driver/json/operate/get_accout_score',
    //   dataType:'json',
    //   beforeSend: function(request) {
    //     request.setRequestHeader("Authorization", 12345654);
    //   },
    //   success:function (data) {
    //     // console.log(data)
    //     that.setState({
    //       score:data.result.score,
    //       averageScore:data.result.averageScore,
    //       complaintPercent:data.result.complaintPercent,
    //       completePercent:data.result.completePercent,
    //       dispatchPercent:data.result.dispatchPercent,
    //       defeatPercent:data.result.defeatPercent
    //     })
    //   }
    // });

  //  维度点击事件
  //   console.log($('.list li'));
    $('.list li').click(function (e) {
      console.dir(e.target.dataset.value);
      var queryTime=e.target.dataset.value;
      $($(this).siblings()).removeClass('colorOr');
      $(this).addClass("colorOr");
      // $.ajax({
      //   type:'get',
      //   url:'http://192.168.1.57:8080/yueche-driver/json/operate/get_accout_score',
      //   dataType:'json',
      //   data:{
      //     queryTime:queryTime
      //   },
      //   success:function (data) {
      //     // console.log(data)
      //     that.setState({
      //       score:data.result.score,
      //       averageScore:data.result.averageScore,
      //       complaintPercent:data.result.complaintPercent,
      //       completePercent:data.result.completePercent,
      //       dispatchPercent:data.result.dispatchPercent,
      //       defeatPercent:data.result.defeatPercent
      //     })
      //   }
      // });
    })
  };
  /*侧栏滑动*/
  changeRight=()=>{
    var flag = this.state.flag;
    if(!flag){
      this.setState({flag:true});
      // console.log(flag);
      $(".list").addClass('move');
     $(".offcavas-btns").html('<i class="fa fa-angle-double-left coloWhite" aria-hidden="true"></i>')
    }
    else {
      // console.log(flag);
      this.setState({flag:false});
      $(".list").removeClass('move');
      $(".offcavas-btns").html('<i class="fa fa-angle-double-right coloWhite" aria-hidden="true"></i>')
    }
  }


//  获取司机id
// setDriver(id){
//     alert(111);
//     alert(id)
// };

  render() {
    return (
      <div className="assessment">
        <div className="scoringRules fontS15 "><a href="#/ycDriver/rule/scoringRules" className="colorG"><img src={img1} alt=""/>评分规则说明</a></div>
        <div className="assContent textAlign">
           <p className="colorG fontS25">考核成绩</p>
            <div className="assScore colorOr">
               <p className="score fontS625"><span>{this.state.score}</span>分</p>
               {/*<p className="fontS25 fail">恭喜你击败了{this.state.defeatPercent}的司机!</p>*/}
               <p className="fontS25 fail">表现良好，请继续保持</p>
            </div>
        </div>
        <div className="offcavas coloWhite">
          <ul className="list">
            <p className='fontSize2' >维度</p>
            <li data-value="all" className="colorOr">全部</li>
            <li data-value="month">月</li>
            <li data-value="week">周</li>
            <li data-value="day">日</li>
          </ul>
          <button className="offcavas-btns" onClick={this.changeRight}>
            <i className="fa fa-angle-double-right coloWhite fontS25" aria-hidden="true"></i>
          </button>
        </div>
        <div className="scoreItem">
          <ul>
            <li><div>{this.state.averageScore}</div> <span>星级</span></li>
            <li><div>{this.state.completePercent}</div> <span>成交率</span></li>
            <li><div>{this.state.dispatchPercent}</div> <span>派单率</span></li>
            <li><div>{this.state.complaintPercent}</div> <span>被投诉率</span></li>
          </ul>
        </div>
        <p className="textAlign colorG fontSize2">附加分: <span>3.5</span></p>
      </div>
    );
  }
}

export default AppComponent;

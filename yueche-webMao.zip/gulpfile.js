
var gulp    = require('gulp');                 //基础库
var minifycss = require('gulp-minify-css');    //css压缩
var clean_css = require('gulp-clean-css');
var rename = require('gulp-rename');
var fs = require('fs');
var path = require('path');
var util = require("util");
var UglifyJS = require("uglify-js");
var exec = require("child_process").exec;

// 样式处理
gulp.task('css', function () {
    var cssSrc = './htdocs/css/*.css',
        cssDst = './dev/css/';

    gulp.src(cssSrc)
        .pipe(clean_css())
        .pipe(gulp.dest(cssDst));
});



gulp.task('lib', function () {

    var jsDst ='./dev/js/lib/',
        base = './htdocs/js/lib/';

    var exists = fs.existsSync("./dev/js/lib");
    if(!exists){
        exists = fs.existsSync("./dev");
        if(!exists){
            fs.mkdirSync("./dev");
            exists = fs.existsSync("./dev/js");
            if(!exists){
                fs.mkdirSync("./dev/js");
                exists = fs.existsSync("./dev/js/lib");
                if(!exists){
                    fs.mkdirSync("./dev/js/lib");
                }
            }
        }
    }

    getDirName(base,"",function(err,result){

        result.forEach(function(obj){
            var distDir = jsDst+obj.dirPath,
                dist = jsDst+obj.dirPath+obj.file,
                src = base+obj.dirPath+obj.file,
                cmd = "uglifyjs "+src+" -m -r '$,require,exports' -o "+dist;

            var exists = fs.existsSync(distDir);
            if(!exists){
                fs.mkdirSync(distDir);
            }
            console.log("cmd:"+cmd);
            exec(cmd);
        });
    });

});

gulp.task('biz', function () {

    var jsDst ='./dev/js/business/',
        base = './htdocs/js/business/';
    var exists = fs.existsSync(jsDst);
    if(!exists){
        fs.mkdirSync("./dev/js/business");
    }

    getDirName(base,"",function(err,result){
        result.forEach(function(obj){

            var distDir = jsDst+obj.dirPath,
                dist = jsDst+obj.dirPath+obj.file,
                src = base+obj.dirPath+obj.file,
                cmd = "uglifyjs "+src+" -m -r '$,require,exports' -o "+dist;

            var exists = fs.existsSync(distDir);
            if(!exists){
                fs.mkdirSync(distDir);
            }
            console.log("cmd:"+cmd);
            exec(cmd);
        });
    });

});

gulp.task('data', function () {

    var jsDst ='./dev/js/data/',
        base = './htdocs/js/data/';
    var exists = fs.existsSync(jsDst);
    if(!exists){
        fs.mkdirSync("./dev/js/data");
    }

    getDirName(base,"",function(err,result){
        result.forEach(function(obj){

            var distDir = jsDst+obj.dirPath,
                dist = jsDst+obj.dirPath+obj.file,
                src = base+obj.dirPath+obj.file,
                cmd = "uglifyjs "+src+" -m -r '$,require,exports' -o "+dist;

            var exists = fs.existsSync(distDir);
            if(!exists){
                fs.mkdirSync(distDir);
            }
            console.log("cmd:"+cmd);
            exec(cmd);
        });
    });
});

gulp.task('cp', function() {
    var cmd = "mkdir  -p dev/images";
    exec(cmd);
    cmd = "cp -R htdocs/images/* dev/images";
    exec(cmd);
    cmd = "cp -R htdocs/js/seajs/ dev/js/";
    exec(cmd);
    cmd = "cp -R htdocs/js/jquery dev/js/";
    exec(cmd);
});
/*
gulp.task('rename', function() {
    gulp
      .src('dist/index.html')
      .pipe(rename({
          basename:'index5',
          suffix:'ejs'
          })
      )
      .pipe(gulp.dest('views/activity'))
});
*/

gulp.task('online', ['css', 'lib', 'biz','cp', 'data'], function() {

});
// gulp.task('dist', 'rename');


var getDirName = function(base,filepath, done) {
  var results = [],
    dir = base+"/"+filepath;
    fs.readdir(dir, function(err, list) {
    if (err) return done(err);

    var pending = list.length;
    if (!pending) return done(null, results);
    list.forEach(function(file) {

      var absfile = path.resolve(dir, file);

      fs.stat(absfile, function(err, stat) {
        if (stat && stat.isDirectory()) {

          getDirName(dir,file, function(err, res) {
            results = results.concat(res);
            if (!--pending) done(null, results);
          });
        } else {
            if(filepath != ""){
                file = "/" + file;
            }
            var e = {dirPath:filepath,file:file};
            results.push(e);
            if (!--pending) done(null, results);
        }
      });
    });
  });
};

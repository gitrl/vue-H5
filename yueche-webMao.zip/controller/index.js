/* jshint node:true*/
"use strict";
var express = require('express');
var router = express.Router();
var path = require('path');
var Comm = require("../component/Comm");
var needle = require('needle');
var appid = "wx8e21b67f990d11f5";
var secret = "788f8a091af455b3d237b380afbbb910";
debugger;

router.get('/index',function(req, res){

    //Comm.post('test',{a:1}, req);
    res.render('activity/index',{msg:"111"});
    res.end();
});
router.get('/index2',function(req, res){

    res.render('activity/index2',{msg:"111"});
    res.end();
});
router.get('/index3',function(req, res){
	//console.log(Comm.g_band.result);
	res.render('activity/index3',{msg: Comm.g_band.result.branditems});
    res.end();
});
router.get('/getbandlist',function(req, res){

    var id = req.query.id;
    console.log(id);
    res.json(Comm.g_car[id]);
    res.end();
});
router.get('/index4',function(req, res){
    res.render('activity/index4');
    res.end();
});

router.get('/getsignpackage',function(req, res){
    //getaccesstoken
    var url  = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=" + appid + "&secret=" + secret;

    needle.get(url, function(err, response){

        if(response && 200 == response.statusCode){
            console.log(response.body);
          var result = JSON.parse(response.body);
          var access_token = result.access_token;

          $url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?type=jsapi&access_token=" + access_token;
          // needle.get(url, function(err, response){

          //   if(response && 200 == response.statusCode){
          //       var result = JSON.parse(response.body);
          //       var ticket = result.ticket;
          //       console.log(ticket);
          //       var date = new Date();
          //       var timestamp = date.getTime()/1000;//转换成秒；
          //       var nonceStr = createNonceStr;
          //       var signature = Comm.getSignature(ticket, timestamp, req.query.url, nonceStr);

          //       var signPackage = {
          //           "tic": curTicket,
          //           "appId" : appid,
          //           "nonceStr" : nonceStr,
          //           "timestamp" : timestamp,
          //           "url" : req.query.url,
          //           "signature" : signature
          //       }
          //       res.json(signPackage);
          //       res.end();

          //   }
          //   console.log("needle2");
          // });
        }
        console.log("needle1");
      });

    console.log("end");

});
router.post('/upload',function(req, res){
    console.log(req.body);
    console.log(req.files);
});

module.exports = router;



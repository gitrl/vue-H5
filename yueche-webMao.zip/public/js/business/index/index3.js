define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/vue/vue.min');

    var f = {
        init: function () {

            var vm = new Vue({
                el: '#app',
                data: {
                    showDetails: false,
                    hotList: [
                        {
                            title: '大众',
                            imgSrc: '/images/car/dazong.jpg',
                            id: "1"
                        },
                        {
                            title: '比亚迪',
                            imgSrc: '/images/car/byd.jpg',
                            id: "75"
                        },
                        {
                            title: '奔驰',
                            imgSrc: '/images/car/benchi.jpg',
                            id: "36"
                        },
                        {
                            title: '奥迪',
                            imgSrc: '/images/car/aodi.jpg',
                            id: "33"
                        },
                        {
                            title: '长安',
                            imgSrc: '/images/car/changan.jpg',
                            id: "76"
                        },
                        {
                            title: '吉利',
                            imgSrc: '/images/car/jili.jpg',
                            id: "25"
                        },
                        {
                            title: '雪弗兰',
                            imgSrc: '/images/car/xuefulai.jpg',
                            id: "71"
                        },
                        {
                            title: '福特',
                            imgSrc: '/images/car/fute.jpg',
                            id: "8"
                        },
                        {
                            title: '丰田',
                            imgSrc: '/images/car/fengtian.jpg',
                            id: "3"
                        },
                        {
                            title: '日产',
                            imgSrc: '/images/car/richan.jpg',
                            id: "63"
                        }
                    ],
                    typeList: [
                        // {
                        //     letter: 'A',
                        //     carList: [
                        //     ]
                        // },
                    ],
                    detailActive: -1,
                    detailsList: []
                },
                created: function(){
                    var bfirstletter = "A";
                    var typeList = [];
                    var typeItem = {
                            letter: 'A',
                            carList: []
                        };
                  typeList.push(typeItem);

                  for(key in g_band){
                        var item = g_band[key];
                        if(bfirstletter != item.bfirstletter){
                            bfirstletter = item.bfirstletter;
                            typeItem = {
                                letter: item.bfirstletter,
                                carList: []
                            };
                          typeList.push(typeItem);
                        }

                        var car = {carType:[]};
                        car["carName"] = item.name;
                        car["id"] = item.id;
                        typeItem.carList.push(car);
                        this.typeList = typeList;
                    }

                },
                methods: {
                    checkType:function(id,arr) {
                         this.detailActive = -1;
                         this.showDetails = true;
                         this.selBand(id);
                    },
                    getMobileOperatingSystem: function () {
                      var userAgent = navigator.userAgent || navigator.vendor || window.opera;
                      if (userAgent.match(/iPad/i) || userAgent.match(/iPhone/i) || userAgent.match(/iPod/i)) {
                        return 'iOS';
                      }
                      else {
                        return 'Android';
                      }
                    },
                    checkDetails:function(index, name, brand){
                        this.detailActive = index;
                        //alert(name+","+brand);
                        //alert(window.webkit.messageHandlers);
                        try{
                          if(this.getMobileOperatingSystem()=='iOS'){
                            window.webkit.messageHandlers.hasSelectCarStyle.postMessage({name: name,brand: brand});
                          }
                          else if(this.getMobileOperatingSystem()=='Android'){
                            window.just_android.saveCarModel(brand, name);
                          }
                        }
                        catch(err){
                            alert(err);
                        }
                    },
                    closeDetails:function(){
                        this.showDetails = false;
                    },
                    selBand: function (id) {
                        shan.ajax({
                            url : "/index/getbandlist",
                            data : {
                                id : id
                            },
                            success: function(json){
                                if(json){
                                    console.log(json);
                                    var detailsList = [];
                                    for(ikey in json.result.factoryitems){
                                        var factoryitem = json.result.factoryitems[ikey];
                                        for(jkey in factoryitem.seriesitems){
                                            var seriesitem = factoryitem.seriesitems[jkey];
                                            var detailitem = {
                                                brand: factoryitem.name,
                                                name: seriesitem.name
                                            };
                                            detailsList.push(detailitem);
                                        }
                                    }
                                    vm.detailsList = detailsList;
                                }
                                else{
                                    pop.alert("!");
                                }
                            }
                        });
                    },
                    selCar: function(letter){
                        window.location.href = "#"+letter;
                    }
                }
            })
        }

    };

    var run = function () {
        f.init();
    }

    //初始化函数
    exports.run = run;
});

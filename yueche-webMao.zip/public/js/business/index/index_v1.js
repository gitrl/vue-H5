define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/fastclick');
    require('lib/webview');

    var f = {
        formatBgHeight: function () {
            var viewHeight = document.body.scrollHeight;
            $('.m-body-scroll').css('max-height', (viewHeight - 176) + 'px');
            $('.m-body-scroll.tick-list').css('max-height', (viewHeight - 317) + 'px');
        },
        init: function () {
            var _self=this;
            $(function () {
                shan.tools.getTime();
                FastClick.attach(document.body);
                _self.formatBgHeight();
                shan.tools.statisticsPing("43000");
            });
            if(shan.tools.isMyApp() == 1){
                webView.callHandler("configH5AppVersion",{h5AppVersion: g_h5AppVersion}, function(){

                });
            }

        }
    };

    var run = function () {
        f.init();
    }

    //初始化函数
    exports.run = run;
});
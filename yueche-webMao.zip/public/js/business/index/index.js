define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/vue/vue.min');

    var f = {
        init: function () {
            var map = new AMap.Map('container', {
                resizeEnable: true,
                zoom:11,
                center: [116.397428, 39.90923]
            });
        },

    };

    var run = function () {
        f.init();
    }

    //初始化函数
    exports.run = run;
});

define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/fastclick');
    var ping=require('lib/ping');
    var f = {
        init: function () {
            var _self=this;
            $(function () {
                FastClick.attach(document.body);
                shan.tools.statisticsPing('130020');
                ping.pingInit({
                    container: $(".flex"),
                    el: $(".ping")
                });
            });
        },
        bindEvent : function(){

        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});

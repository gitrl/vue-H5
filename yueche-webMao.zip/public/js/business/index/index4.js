define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/vue/vue.min');

    var f = {
        init: function () {

            shan.ajax({
                url: '/index/getsignpackage',
                data: {
                    url: location.href
                },
                success: function (json) {
                    if (json.errCode == 0) {
                        if (typeof apiList != 'object') {
                            apiList = [
                                'checkJsApi',
                                'onMenuShareTimeline',
                                'onMenuShareAppMessage',
                                'onMenuShareQQ',
                                'onMenuShareWeibo',
                                'hideMenuItems',
                                'showMenuItems',
                                'hideAllNonBaseMenuItem',
                                'showAllNonBaseMenuItem',
                                'translateVoice',
                                'startRecord',
                                'stopRecord',
                                'onRecordEnd',
                                'playVoice',
                                'pauseVoice',
                                'stopVoice',
                                'uploadVoice',
                                'downloadVoice',
                                'chooseImage',
                                'previewImage',
                                'uploadImage',
                                'downloadImage',
                                'getNetworkType',
                                'openLocation',
                                'getLocation',
                                'hideOptionMenu',
                                'showOptionMenu',
                                'closeWindow',
                                'scanQRCode',
                                'chooseWXPay',
                                'openProductSpecificView',
                                'addCard',
                                'chooseCard',
                                'openCard'
                            ];
                        }
                        wx.config({
                            debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
                            appId: json.appId, // 必填，公众号的唯一标识
                            timestamp: json.timestamp, // 必填，生成签名的时间戳
                            nonceStr: json.nonceStr, // 必填，生成签名的随机串
                            signature: json.signature,// 必填，签名，见附录1
                            jsApiList: apiList // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
                        });
                        wx.ready(function () {

                        });
                    }
                }
            });

            var vm = new Vue({
                el: '#app',
                data: {},
                methods: {
                    recordStart: function(){
                        wx.startRecord();
                    },
                    recordEnd: function(){
                        wx.stopRecord({
                            success: function (res) {
                                var localId = res.localId;
                            }
                        });
                    }
                }
            });
        }
    };

    var run = function () {
        f.init();
    }

    //初始化函数
    exports.run = run;
});

define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/fastclick');
    require('lib/vue/vue');

    var f = {
        init: function () {
            $(function () {
                FastClick.attach(document.body);
            });
        },
        bindEvent: function () {
        }
    };


    Vue.component('goods-list', {
        template: '<a class="item" :class="{booked:myGoods.isBooked}" :href="myGoods.url">' +
        '<i class="item-icon"></i>' +
        '<div class="flex goods-info">' +
        '<div class="left">' +
        '<div class="goods-info-name" v-text="myGoods.goodsName"></div>' +
        '<div class="goods-info-date" v-text="myGoods.exchangeTimeStr"></div>' +
        '</div>' +
        '<div class="right" :class="{hidden:!myGoods.isBooked}">已使用</div>' +
        '</div>' +
        '<i class="yo-ico"></i>' +
        '</a>',
        props: ['myGoods'],
        data: function () {
            return {};
        },
        methods: {},
    });


    const vm = new Vue({
        el: '#app',
        data: {
            hasExchangeList: false,//是否拥有兑换记录
            isWaitingApi: false,//是否等待ajax回调
            goodsListData: [],//用户兑换列表
            urlBooking: '/sz/product/newdetail?',//商品详情页
            cardNo: '',//卡密
            phoneModel: '',//用户手机号
            codeModel: '',//验证码
            isSending: false,//是否处于1分钟验证码冷却期
            currentTimer: 60, //收到验证码后的等待时间
            timerId: "", //监听等待时间的id
            examWords: '获取验证码',//验证码按钮文字
        },
        computed: {},
        methods: {
            init: function () {
                if (!this.isWaitingApi) {
                    this.isWaitingApi = true;
                    shan.ajax({
                        version: 'V2',
                        data: {
                            url: '/exchangeCard/summary.htm',
                        },
                        type: 'POST',
                        success: function (_json) {
                            vm.isWaitingApi = false;
                            if (_json.SZ_HEAD.RESP_CODE != 'S0000') {
                                return;
                            }
                            else {
                                if (_json.SZ_BODY.exchangeList && _json.SZ_BODY.exchangeList.length > 0) {
                                    vm.formatGoodsList(_json);
                                }
                                else {
                                    vm.hasExchangeList = false;
                                }
                            }
                        }
                    });
                }
            },
            exchangeCode: function () {
                if (!this.isWaitingApi && this.cardNo != '') {
                    this.isWaitingApi = true;
                    var smsUrl = '';
                    shan.ajax({
                        data: {},
                        url: '/sz/user/getsmsurl_async',
                        success: function (_json) {
                            if (_json.SZ_HEAD.RESP_CODE == 'S0000') {
                                smsUrl = _json.SZ_BODY.DATA;
                                shan.ajax({
                                    version: 'V2',
                                    data: {
                                        url: '/exchangeCard/externalExchange.htm',
                                        cardNo: vm.cardNo,
                                        smsUrl: smsUrl,
                                        isSendSms: 1
                                    },
                                    type: 'POST',
                                    success: function (_json) {
                                        vm.isWaitingApi = false;
                                        vm.cardNo = '';
                                        vm.codeModel = '';
                                        if (_json.SZ_HEAD.RESP_CODE != 'S0000') {
                                            pop.message.show(_json.SZ_HEAD.RESP_MSG);
                                            return;
                                        }
                                        else {
                                            pop.alert2(_json.SZ_BODY.messageContent, _json.SZ_BODY.messageTitle);
                                            vm.examWords = '获取验证码';
                                            vm.isSending = false;
                                            vm.currentTimer = 60;
                                            clearInterval(vm.timerId);
                                            if (!_json.SZ_BODY.isExchangeFail && _json.SZ_BODY.exchangeList && _json.SZ_BODY.exchangeList.length > 0) {
                                                vm.formatGoodsList(_json);
                                            }
                                        }
                                    }
                                })
                            }
                            else {
                                vm.isWaitingApi = false;
                            }

                        }
                    });
                }
            },
            formatGoodsList: function (_json) {
                vm.hasExchangeList = true;
                vm.goodsListData = _json.SZ_BODY.exchangeList;
                for (var i = 0; i < vm.goodsListData.length; i++) {
                    if (vm.goodsListData[i].isReserve == '1') {
                        vm.goodsListData[i].isBooked = true;
                    }
                    else {
                        vm.goodsListData[i].isBooked = false;
                    }
                    vm.goodsListData[i].url = vm.urlBooking + 'goodsCode=' + vm.goodsListData[i].goodsCode + '&activityCode=' + vm.goodsListData[i].activityCode + '&orderCode=' + vm.goodsListData[i].orderCode+'&outside=1';
                }
            },
            checkPhone: function (phone) {
                if (/^1\d{10}/.test(phone)) {
                    return true;
                } else {
                    return false;
                }
            },
            getVerifyCode: function () {
                if (this.isSending) {
                    return;
                }
                var _result = this.checkPhone(this.phoneModel);
                if (_result) {
                    this.sendVerifyCode(this.phoneModel);
                }
                else {
                    pop.message.show('请输入正确的手机号');
                }
            },
            sendVerifyCode: function (phone) {
                if (phone && !this.isSending) {
                    this.isSending = true;
                    var loginDialog = this;
                    shan.ajax({
                        url: "/sz/index/smsverify",
                        data: {
                            phone: phone
                        },
                        success: function (json) {
                            loginDialog.isSending = false;
                            switch (json.SZ_HEAD.RESP_CODE) {
                                case "S0000":
                                    loginDialog.resetCodeTimer(loginDialog);
                                    $(loginDialog.$el).find("#loginVerifyCodeInput").focus();
                                    pop.message.show('验证码已成功发送至您手机中');
                                    break;
                                case "3":
                                    pop.message.show('抱歉，该手机登陆次数过多 请等30分钟后重试');
                                    break;
                                case "5":
                                    pop.message.show('抱歉，请刷新页面后重新输入验证码');
                                    break;
                                default:
                                    pop.message.show('发送失败请稍后再试');
                                    break;
                            }

                        }
                    });
                }
            },
            resetCodeTimer: function (loginDialog) {
                function refresh() {
                    loginDialog.currentTimer--;
                    if (loginDialog.currentTimer >= 0) {
                        loginDialog.examWords = loginDialog.currentTimer + 's 重新发送';
                        loginDialog.isSending = true;
                    } else {
                        loginDialog.examWords = '获取验证码';
                        loginDialog.isSending = false;
                        loginDialog.currentTimer = 60;
                        clearInterval(loginDialog.timerId);
                    }

                }

                loginDialog.timerId = setInterval(refresh, 1000);
            },
            checkVerifyCode: function (code) {
                if (/\d{6}/.test(code)) {
                    return true;
                } else {

                    return false;
                }
            },
            login: function () {
                if (!this.isWaitingApi) {
                    var _result = "";
                    _result = this.checkPhone(this.phoneModel);
                    if (!_result) {
                        pop.message.show('请输入正确的手机号');
                        return;
                    }
                    _result = this.checkVerifyCode(this.codeModel);
                    if (!_result) {
                        pop.message.show('验证码不正确');
                        return;
                    }
                    if (this.cardNo == '') {
                        pop.message.show('请输入兑换码');
                        return;
                    }
                    this.isWaitingApi = true;
                    shan.ajax({
                        url: '/sz/user/szlogin_async',
                        data: {
                            phone: this.phoneModel,
                            code: this.codeModel
                        },
                        success: function (json) {
                            if (json && json.SZ_HEAD && json.SZ_HEAD.RESP_CODE) {
                                if (json.SZ_HEAD.RESP_CODE == 'S0000') {
                                    vm.isWaitingApi = false;
                                    vm.exchangeCode();
                                } else {
                                    pop.message.show(json.SZ_HEAD.RESP_MSG);
                                }

                            }
                        }
                    });
                }
            },
        },
        created: function () {//创建实例后
        },
        mounted: function () {//创建dom后
        }

    });

    var run = function () {
        f.init();
        f.bindEvent();
    };

    //初始化函数
    exports.run = run;
});

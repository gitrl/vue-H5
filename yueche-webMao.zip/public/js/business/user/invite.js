define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    var share = require('lib/shan_share');
    require('lib/share/wxshare');
    require('lib/mustache');
    var channelCode = shan.tools.getUrlParam("channel");
    var activityCode = shan.tools.getUrlParam("activity");

    var f = {
        init: function () {
            var _self = this;
        },
        bindEvent: function () {
            shan.tools.statisticsPing("52005");
            var _self = this;
            $('#shareBtn li').click(function(){
                $('#shareBox').removeClass('hidden');
            });
            $('#shareBox').click(function(){
                $(this).addClass('hidden');
            });
            $('#goBack').click(function(){
                window.history.back();
            });

            $('#shareList li').on('touchend', function (e) {
                shan.tools.statisticsPing("52013",{sourceCode:g_key});
                share.shareTipsLayer.show();
                e.preventDefault();
            });

            share.wxShare({
                key: g_key,
                success: function (copy) {
                    share.shareSuccessCallback({
                        key: g_key,
                        channelCode : channelCode,
                        activityCode : activityCode,
                        GAIN_SUCC : function (list) {
                            share.inviteSuccessDialog.ele.find('.btn-list a:first-child').attr('href', copy.activityUrl);
                            share.inviteSuccessDialog.show(list);
                        }
                    });
                    share.shareTipsLayer.hide();
                    shan.tools.statisticsPing("52003",{sourceCode:g_key});
                }
            });

        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});

define(function(require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/vue/vue');

    var loginDialog = new Vue({
        el:"#szLoginDialog",
        data: {
            inputStatus : false, //手机输入框状态
            isSending : false, //当前是否有ajax请求
            phoneModel : "", //用户输入的手机号码
            currentTimer: 60, //收到验证码后的等待时间
            timerId : "", //监听等待时间的id
            isLogining: false, //是否正在登录
            alertMsgText: "", //用户提示信息
            isShowAlert : false, //是否展示用户提示区域
            codeModel: "" //验证码
        },
        methods: {
            showAlert: function(msg){
                if(msg == ""){
                    this.isShowAlert = false;
                    this.alertMsgText = "";
                }
                else{
                    this.isShowAlert = true;
                    this.alertMsgText = msg;
                }
            },
            getVerifyCode : function(){
                if(this.isSending){
                    return;
                }

                var _result = this.checkPhone(this.phoneModel);

                if(_result){
                    this.showAlert("");
                    this.inputStatus = false;
                    this.sendVerifyCode(this.phoneModel);
                }
                else{
                    this.inputStatus = true;
                    this.showAlert('请输入正确的手机号');
                }
            },
            checkPhone: function (phone) {
                
                if( /^1\d{10}/.test(phone) ){
                    return true;
                } else {
                    return false;
                }
            },
            sendVerifyCode: function (phone) {
                if (phone && !this.isSending) {
                    this.isSending = true;

                    shan.ajax({
                        url: "/sz/index/smsverifyp",
                        data: {
                            phone: phone
                        },
                        success: function(json){
                            loginDialog.isSending = false;
                            switch (json.SZ_HEAD.RESP_CODE) {
                                case "S0000":
                                    loginDialog.resetCodeTimer();
                                    $(loginDialog.$el).find("#loginVerifyCodeInput").focus();
                                    pop.message.show('验证码已成功发送至您手机中');
                                    break;
                                case "4":
                                    var $verifyPic = $(loginDialog.$el).find('#verifyPic');
                                    var img = new Image();
                                    img.src = "/verifypic.php?phone="+phone+"&t=1"+"&_="+new Date().getTime();
                                    $verifyPic.find('.img-code').html($(img));
                                    $verifyPic.show();
                                    
                                    $(loginDialog.$el).find("#loginGetVerifyCodeBtn").text('操作频繁，请输入图形码');
                                    loginDialog.isSending = true;
                                    $verifyPic.find('#loginImgVerifyInput').focus().off("input").on('input', function (e) {
                                        if (this.value.length == 4) {
                                            loginDialog.verifyPic(phone);
                                        }
                                    });
                                    break;
                                case "5":
                                    pop.alert('抱歉，请刷新页面后重新输入验证码', function(){
                                        window.location.href = "/sz/user/index";
                                    });
                                    break;
                                default:
                                    pop.message.show('发送失败请稍后再试');
                                    break;
                            }
                            
                        }
                    });
                }
            },
            resetCodeTimer: function(){
                
                function refresh() {
                    loginDialog.currentTimer--;
                    if (loginDialog.currentTimer >= 0) {
                        $(loginDialog.$el).find("#loginGetVerifyCodeBtn").text(loginDialog.currentTimer + 's 重新发送');
                        loginDialog.isSending = true;
                    }else {
                        $(loginDialog.$el).find("#loginGetVerifyCodeBtn").text('获取验证码');
                        loginDialog.isSending = false;
                        loginDialog.inputStatus = false;
                        clearInterval(loginDialog.timerId);
                    }
                    
                }
                loginDialog.timerId = setInterval(refresh,1000);
            },
            checkVerifyCode: function (code) {
                
                if( /\d{6}/.test( code ) ){
                    return true;
                } else {
                    
                    return false;
                }
            },
            login: function(){
                
                if(this.isLogining){
                    return;
                }
                var _result = "";

                _result = this.checkPhone(this.phoneModel);
                if(!_result){
                    this.showAlert('请输入正确的手机号');
                    return;
                }

                _result = this.checkVerifyCode(this.codeModel);
                if (!_result){
                    this.showAlert('验证码不正确');
                    return;
                };

                pop.message.show("正在登录中...");
                this.isLogining = true;
                
                shan.ajax({
                    url: '/sz/user/szlogin_async',
                    data : {
                        phone : this.phoneModel,
                        code: this.codeModel
                    },
                    success: function(json){
                        if (json && json.SZ_HEAD && json.SZ_HEAD.RESP_CODE) {
                            if (json.SZ_HEAD.RESP_CODE == 'S0000') {
                                pop.message.show("登录成功");
                                $(this.$el).find("#loginVerifyCodeInput").blur();
                                window.location.href = $("#afterLogin").val();
                            } else {
                                loginDialog.showAlert(json.SZ_HEAD.RESP_MSG);
                            }
                            loginDialog.isLogining = false;
                        }
                    }
                });
                
            },
            resetPic: function (phone) {
                var $verifyPic = $(this.$el).find('#verifyPic'),
                    src = "/verifypic.php?phone="+phone+"&t=1"+"&_="+new Date().getTime();
                $verifyPic.find('.img-code img').attr('src', src);
            },
            verifyPic: function (phone) {
                var $input = $(this.$el).find('#loginImgVerifyInput'),
                    pic = $input.val();

                shan.ajax({
                    url : "/verifypic.php",
                    data : {
                        phone : phone,
                        pic: pic,
                        t: 2
                    },
                    success: function(rtn){
                        loginDialog.isSending = false;
                        switch(rtn.err) {
                            case 0:
                                $input.blur();
                                pop.message.show("正在发送验证码。。。");
                                loginDialog.sendVerifyCode(phone);
                                loginDialog.showAlert("");
                                break;
                            case 1:
                                loginDialog.showAlert('抱歉，图形校验码输入错误');
                                break;
                            case 2:
                                loginDialog.showAlert('抱歉，该手机号校验图形码过多，请等30分钟后重试');
                                break;
                        }
                    }
                });
            }
        }
    });
    var run = function () {
        
    }
    //初始化函数
    exports.run = run;
});
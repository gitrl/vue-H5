/**
 * Created by wayyue05 on 2017/02/14.
 */
define(function (require, exports, module) {
    //var $ = require('jquery');
    require('lib/fastclick');
    require('lib/vue/vue.min');
    var shan = require('lib/shan_base');

    var no = shan.tools.getUrlParam("no");
    var f = {
        init: function () {
            //var _self=this;
            /*$(function () {
                FastClick.attach(document.body);
            });*/
            new Vue({
                el: '#content',
                data: {
                    no: no
                }
            });
        }
    };

    var run = function () {
        f.init();
    };

    //初始化函数
    exports.run = run;
});

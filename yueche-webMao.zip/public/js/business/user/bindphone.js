define(function(require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    require('lib/mustache');
    var pop = require('lib/dialog');

    var _options = {
        template: '',
        isSendingCode: false,
        timer: 10,
        currentTimer: 60,
        timerId: false,
        loading: false,
        phoneNum: false
    };

    var f = {
        checkPhone: function () {
            var _$input = _options.loginPhoneInput;
            var _val = _$input.val();
            if( /^1\d{10}/.test( _val ) ){
                _$input.parents(".item-input").removeClass( "error" );
                loginDialog.ele.find('#loginTips').hide();
                return _val;
            } else {
                _$input.parents(".item-input").addClass( "error" );
                loginDialog.ele.find('#loginTips').text('请输入正确的手机号').show();
                return false;
            }
        },
        checkVerifyCode: function () {
            var _$input = _options.loginVerifyCodeInput;
            var _val = _$input.val();
            if( _val != "" && /\d{6}/.test( _val ) ){
                _$input.parents(".item-input").removeClass( "error" );
                loginDialog.ele.find('#loginTips').hide();
                return _val;
            } else {
                _$input.parents(".item-input").addClass( "error" );
                loginDialog.ele.find('#loginTips').text('验证码不正确').show();
                return false;
            }
        },
        resetCodeTimer: function () {
            var btn = _options.loginGetVerifyCodeBtn;
            var _count = _options.currentTimer;
            function refresh() {
                _count--;
                if (_count >= 0) {
                    btn.html(_count + 's 重新发送');
                    btn.addClass('text-gray');
                }else {
                    btn.html('获取验证码');
                    btn.removeClass('text-gray');
                    clearInterval(_options.timerId);
                }
                
            }
            _options.timerId = setInterval(refresh,1000);
        },
        resetPic: function (phone) {
            var verifyPic = $('#verifyPic');
            _src = "/verifypic.php?phone="+phone+"&t=1"+"&_="+new Date().getTime();
            verifyPic.find('.img-code img').attr('src', _src);
        },
        verifyPic: function (phone) {
            var _self = this;
            var _$input = loginDialog.ele.find('#loginImgVerifyInput');
            var pic = _$input.val();
            shan.ajax({
                url : "/verifypic.php",
                data : {
                    phone : phone,
                    pic: pic,
                    t: 2
                },
                success: function(rtn){
                    switch(rtn.err) {
                        case 0:
                            _$input[0].blur();
                            pop.message.show("正在发送验证码。。。");
                            _self.sendVerifyCode(phone);
                            _options.tips.hide();
                            break;
                        case 1:
                            _options.tips.html('抱歉，图形校验码输入错误').show();
                            break;
                        case 2:
                            _options.tips.html('抱歉，该手机号校验图形码过多，请等30分钟后重试').show();
                            break;
                    }
                }
            });
        },
        sendVerifyCode: function (phone) {
            var _self = this;
            if (phone && !_options.isSendingCode) {
                shan.ajax({
                    url : "/sz/index/smsverifyp",
                    data : {
                        phone : phone
                    },
                    success: function(json){
                        switch (json.SZ_HEAD.RESP_CODE) {
                            case "S0000":
                                f.resetCodeTimer();
                                _options.phoneNum = phone;
                                pop.message.show('验证码已成功发送至您手机中');
                                _options.isSendingCode = true;
                                _options.loginVerifyCodeInput.focus();
                                break;
                            case "4":
                                var verifyPic = $('#verifyPic');
                                var img = new Image();
                                img.src = "/verifypic.php?phone="+phone+"&t=1"+"&_="+new Date().getTime();
                                verifyPic.find('.img-code').html($(img));
                                verifyPic.show();
                                verifyPic.find('.btn-text').off("click").on('click', function (e) {
                                    _self.resetPic(phone);
                                });
                                _options.loginGetVerifyCodeBtn.html('操作频繁，请输入图形码').addClass('text-gray');
                                verifyPic.find('#loginImgVerifyInput').focus().off("input").on('input', function (e) {
                                    if (this.value.length == 4) {
                                        _self.verifyPic(phone);
                                    }
                                });
                                break;
                            case "5":
                                pop.alert('抱歉，请刷新页面后重新输入验证码',function(){
                                    window.location.href = "/sz/user/index";
                                });
                                break;
                            default:
                                pop.message.show('发送失败请稍后再试');
                                break;
                        }
                        _options.isSendingCode = false;
                    }
                });
            }
        },
        userLogin: function (code) {
            var phone = _options.loginPhoneInput.val();
            shan.tools.statisticsPing(55010);
            if (code && phone) {
                shan.ajax({
                    url: '/sz/user/wxlogin_async',
                    data : {
                        phone : phone,
                        code: code
                    },
                    success: function(json){
                        if (json && json.SZ_HEAD && json.SZ_HEAD.RESP_CODE) {
                            if (json.SZ_HEAD.RESP_CODE == 'S0000') {
                                pop.message.show("绑定成功");
                                _options.loginVerifyCodeInput.blur();
                                shan.tools.statisticsPing(55012);
                                window.location.href = $("#afterBind").val();
                            } else {
                                _options.tips.html(json.SZ_HEAD.RESP_MSG).show();
                            }
                            _options.loginBtn.removeClass('yo-btn-disabled');
                        }
                    }
                });
            }
        }
    };

    var loginDialog = {
        ele: false,
        init: function (options) {
            var _self = this;
            _self.ele = $('#szLoginDialog');
            
            _options = $.extend({}, options, _options);

            _options.loginGetVerifyCodeBtn =  _self.ele.find('#loginGetVerifyCodeBtn');
            _options.tips = _self.ele.find('#loginTips');
            _options.loginBtn = _self.ele.find('#loginBtn');
            _options.loginVerifyCodeInput = _self.ele.find('#loginVerifyCodeInput');
            _options.loginPhoneInput = _self.ele.find('#loginPhoneInput');
            _options.verifyPic = _self.ele.find('#verifyPic');
            _options.resetPic = _self.ele.find('#resetPic');
            _self.bindEvent();
        },
        bindEvent: function (e) {
            var _self = this;
            _self.ele.find('.header .close').off("click").on('click', function (e) {
                _self.hide();
                e.preventDefault();
            });
            
            //获取验证码按钮绑定事件
            _options.loginGetVerifyCodeBtn.off("click").on('click', function (e) {
                var _target = e.target;
                if ($(_target).hasClass('text-gray')) return;
                var _phone = f.checkPhone();
                if (_phone) {
                    f.sendVerifyCode(_phone);
                }
                e.preventDefault();
            });
            _options.loginBtn.off("click").on('click', function (e) {

                if (typeof (_options.loginBtnClick) == 'function') {
                    _options.loginBtnClick();
                }

                if (_options.loginBtn.hasClass('yo-btn-disabled')) return;
                var _phone = f.checkPhone();
                if (!_phone) return;

                var _code = f.checkVerifyCode();
                if (!_code) return;

                pop.message.show("正在登录中...");
                _options.loginBtn.addClass('yo-btn-disabled');
                f.userLogin(_code);

                e.preventDefault();
            });
            //点击验证码刷新
            _options.resetPic.off("click").on('click', function (e) {
                f.resetPic(_options.loginPhoneInput.val());
                e.preventDefault();
            });
            //手机输入框失去焦点后自动校验
            _options.loginPhoneInput.off("blur").on('blur', function (e) {
                f.checkPhone();
            });
            
        },
        show: function (options) {
            var _self = this;
            //pop.mask.show();
            _self.init(options);

            if (options && typeof (options.show) == 'function') {
                options.show(_self);
            }

            _self.ele.show();
            _self.bindEvent();
            //初始化登录框
            _options.loginVerifyCodeInput.val("");
            _options.verifyPic.hide();
            _options.tips.hide();
            _options.loginGetVerifyCodeBtn.html("获取验证码").removeClass('text-gray');
        },
        hide: function () {
            var _self = this;
            //收起键盘
            _options.loginVerifyCodeInput.blur();
            _options.loginPhoneInput.blur();
            //pop.mask.hide();
            _self.ele.hide();
            
        }
    };

    var run = function () {
        loginDialog.init();
    }

    //初始化函数
    exports.run = run;

});
/**
 * Created by wayyue05 on 2016/12/27.
 */
define(function (require, exports, module) {
    var $ = require('jquery');
    require('lib/fastclick');
    require('lib/iscroll-probe');
    require('lib/vue/vue.min');
    var shan = require('lib/shan_base');

    var JS = (function () {
        var vm,
            dataArr = [],
            ajaxDataArr = [],
            page = 2;

        var myScroll,
            pullUp = $("#pullUp"),
            pullUpLabel = $(".pullUpLabel"),
            pullupTips = $(".pullup-tips"),
            list = $('#list'),
            loadingStep = 0;//加载状态0默认，1显示加载状态，2执行加载数据，只有当为0时才能再次加载，这是防止过快拉动刷新

        return {
            init: function () {
                this.inits(); //初始化
                this.bindEvents(); //绑定事件
            },

            //初始化
            inits: function () {
                var _self = this;
                $(function () {
                    FastClick.attach(document.body);
                });
                //渲染第一页的数据
                var initDataArr = JSON.parse(g_reportList);
                if(!initDataArr || initDataArr.length < 1){//如无订单
                    $('#report-none').removeClass('hidden');
                    $('#scroller').addClass('hidden');
                    return;
                }
                var initReportArr = _self.getData(initDataArr,dataArr);
                vm = new Vue({
                    el: '#list',
                    data: {
                        items: initReportArr
                    },
                    methods: {
                        checkOrder:function(index){
                            if(!this.items[index].ready && !this.items[index].reportShow){
                                return;
                            }
                            if(this.items[index].reportShow){
                                window.location.href = "/sz/user/problem_answer?no=9";
                                return;
                            }
                            if(this.items[index].isNewReport == '1'){
                                window.location.href = "/sz/report/index?orderCode=" + this.items[index].orderCode;
                            }else if(this.items[index].isNewReport == '2'){
                                window.location.href = "/sz-health-report.php?orderCode=" + this.items[index].orderCode;
                            }
                        }
                    }
                });
            },

            //绑定事件
            bindEvents: function () {
                var _self = this;
                pullUp.hide();
                myScroll = new IScroll("#wrapper", {
                    scrollbars: 'custom',
                    mouseWheel: true,
                    interactiveScrollbars: true,
                    shrinkScrollbars: 'scale',
                    fadeScrollbars: true,
                    probeType: 2,
                    bindToWrapper: true,
                    tap: true,
                    click: true
                });

                //手指向上拉动
                myScroll.on("scroll", function () {
                    list.css('margin-top',0);
                    if (loadingStep == 0 && !(pullUp.hasClass('refresh') || pullUp.hasClass('loading'))) {
                        if (this.y < (this.maxScrollY + 60)) {//上拉加载更多
                            pullupTips.hide();
                            pullUp.addClass("refresh").show();
                            pullUpLabel.text("加载中，请稍后...");
                            loadingStep = 1;
                            myScroll.refresh();
                        }
                    }
                });

                //手指放开刷新
                myScroll.on("scrollEnd",function(){
                    if(loadingStep == 1 && pullUp.hasClass("refresh")){//上拉刷新操作
                        pullUp.removeClass("refresh").addClass("loading");
                        pullUpLabel.text("正在加载...");
                        loadingStep = 2;
                        _self.pullUpAction();
                    }
                });

                $(document).on('touchmove', function (e) {
                    e.preventDefault();
                }, false);
            },

            //下拉刷新
            pullUpAction: function(){
                var _self = this;
                setTimeout(function(){
                    //ajax请求
                    shan.ajax({
                        url: '/sz/user/reportlist_async',
                        async : true,
                        data: {
                            page: page
                        },
                        success: function(json){
                            if(typeof json != 'undefined' && json.SZ_HEAD.RESP_CODE == 'S0000' && json.SZ_BODY.DATA.length >= 1){
                                var getDataArr = json.SZ_BODY.DATA;
                                var ajaxData = _self.getData(getDataArr,ajaxDataArr);//获取数据
                                vm.items = vm.items.concat(ajaxData);
                                pullUp.attr('class','').hide();
                                pullupTips.show();
                                list.css('margin-top','-0.5rem');
                                ajaxDataArr = [];
                                page++;
                            }else{
                                pullupTips.text("没有更多报告了");
                                pullUp.hide();
                                pullupTips.show();
                            }
                        }
                    });
                    myScroll.refresh();
                    loadingStep = 0;
                },100);
            },

            //获取数据
            getData: function(initArr,dataArr){
                for(var i=0,len=initArr.length;i<len;i++){
                    dataArr[i]=function(num){
                        return initArr[num];
                    }(i);
                    if(dataArr[i].ready){
                        dataArr[i].reportTitle = '报告已生成';
                        dataArr[i].reportTips = '';
                        dataArr[i].reportStatus = '查看报告';
                    }else if(dataArr[i].reportShow){
                        dataArr[i].reportTitle = '报告暂未出';
                        dataArr[i].reportTips = '报告会在体检后5-7个工作日出具';
                        dataArr[i].reportStatus = '查看体检前注意事项';
                    }else{
                        dataArr[i].reportTitle = '报告暂未出';
                        dataArr[i].reportTips = '报告会在体检后5-7个工作日出具';
                        dataArr[i].reportStatus = '报告生成中';
                    }
                    dataArr[i].orderCode = dataArr[i].ORDER_D.orderCode;
                    dataArr[i].reportPerson = dataArr[i].ORDER_D.examineeName;
                    dataArr[i].reportDate = dataArr[i].ORDER_D.reserveTime;
                    dataArr[i].reportName = dataArr[i].ORDER_D.goodsName;
                    dataArr[i].reportAddress = dataArr[i].ORDER_D.institName;
                    dataArr[i].isNewReport = dataArr[i].ORDER_D.isNewReport;
                    dataArr[i].goodsCode = dataArr[i].ORDER_D.goodsCode;
                    dataArr[i].creating = !dataArr[i].ready;
                    dataArr[i].success = dataArr[i].ready;
                }
                return dataArr;
            }
        }
    })();

    $(function () {
        JS.init();
    });

});

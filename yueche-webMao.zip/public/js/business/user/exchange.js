define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/fastclick');
    require('lib/vue/vue');

    var f = {
        init: function () {
            $(function () {
                FastClick.attach(document.body);
            });
        },
        bindEvent: function () {
        }
    };


    Vue.component('goods-list', {
        template: '<a class="item" :class="{booked:myGoods.isBooked}" :href="myGoods.url">' +
        '<i class="item-icon"></i>' +
        '<div class="flex goods-info">' +
        '<div class="left">' +
        '<div class="goods-info-name" v-text="myGoods.goodsName"></div>' +
        '<div class="goods-info-date" v-text="myGoods.exchangeTimeStr"></div>' +
        '</div>' +
        '<div class="right" :class="{hidden:!myGoods.isBooked}">已使用</div>' +
        '</div>' +
        '<i class="yo-ico"></i>' +
        '</a>',
        props: ['myGoods'],
        data: function () {
            return {};
        },
        methods: {},
    });


    const vm = new Vue({
        el: '#app',
        data: {
            hasExchangeList: false,//是否拥有兑换记录
            isWaitingApi: false,//是否等待ajax回调
            goodsListData: [],//用户兑换列表
            urlBooking: '/sz/product/newdetail?',//商品详情页
            cardNo: '',//卡密
        },
        computed: {},
        methods: {
            init: function () {
                if (!this.isWaitingApi) {
                    this.isWaitingApi = true;
                    shan.ajax({
                        version: 'V2',
                        data: {
                            url: '/exchangeCard/summary.htm',
                        },
                        type: 'POST',
                        success: function (_json) {
                            vm.isWaitingApi = false;
                            if (_json.SZ_HEAD.RESP_CODE != 'S0000') {
                                window.location.replace('/sz/user/index');
                                return;
                            }
                            else {
                                if (_json.SZ_BODY.exchangeList && _json.SZ_BODY.exchangeList.length > 0) {
                                    vm.formatGoodsList(_json);
                                }
                                else {
                                    vm.hasExchangeList = false;
                                }
                            }
                        }
                    });
                }
            },
            exchangeCode: function () {
                if (!this.isWaitingApi && this.cardNo != '') {
                    this.isWaitingApi = true;
                    shan.ajax({
                        version: 'V2',
                        data: {
                            url: '/exchangeCard/exchange.htm',
                            cardNo: this.cardNo
                        },
                        type:'POST',
                        success: function (_json) {
                            vm.isWaitingApi = false;
                            vm.cardNo='';
                            if (_json.SZ_HEAD.RESP_CODE != 'S0000') {
                                window.location.replace('/sz/user/index');
                                return;
                            }
                            else {
                                pop.alert2(_json.SZ_BODY.messageContent, _json.SZ_BODY.messageTitle);
                                if (!_json.SZ_BODY.isExchangeFail && _json.SZ_BODY.exchangeList && _json.SZ_BODY.exchangeList.length > 0) {
                                    vm.formatGoodsList(_json);
                                }
                            }
                        }
                    })
                }
            },
            formatGoodsList: function (_json) {
                vm.hasExchangeList = true;
                vm.goodsListData = _json.SZ_BODY.exchangeList;
                for (var i = 0; i < vm.goodsListData.length; i++) {
                    if (vm.goodsListData[i].isReserve == '1') {
                        vm.goodsListData[i].isBooked = true;
                    }
                    else {
                        vm.goodsListData[i].isBooked = false;
                    }
                    vm.goodsListData[i].url = vm.urlBooking + 'goodsCode=' + vm.goodsListData[i].goodsCode + '&activityCode=' + vm.goodsListData[i].activityCode + '&orderCode=' + vm.goodsListData[i].orderCode;
                }
            }
        },
        created: function () {//创建实例后
        },
        mounted: function () {//创建dom后
            this.init();
        }

    });

    var run = function () {
        f.init();
        f.bindEvent();
    };

    //初始化函数
    exports.run = run;
});

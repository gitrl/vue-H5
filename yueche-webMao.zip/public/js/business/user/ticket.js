define(function (require, exports, module) {
    var $ = require('jquery');
    require('lib/fastclick');
    require('lib/vue/vue.min');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');

    var f = {
        status: {
            isApiLoading: false
        },
        formatCss: function () {
            var ticketWidth = 3.75 - 0.2 * 2;
            $('.red-packet-ticket-list li').css('height', parseInt(ticketWidth * 0.351 * 100, 10) / 100 + 0.05 + 'rem');
        },
        szCodeExchange: function () {
            var _self = this,
                _szCode = $.trim($('#szCode').val()),
                _data = {};
            if (_szCode == '') {
                pop.alert("未输入口令");
                return false;
            }
            _data.szCode = _szCode;
            _self.status.isApiLoading = true;
            shan.ajax({
                url: '/sz/cooperate/exchangeapi',
                data: _data,
                type: 'post',
                success: function (_json) {
                    _self.status.isApiLoading = false;
                    console.log(_json);
                    if (_json.SZ_HEAD.RESP_CODE != 'S0000') {
                        pop.message.show(_json.SZ_HEAD.RESP_MSG);
                    }
                    else {
                        if (_json.SZ_BODY.EXCHANGE_STATUS == 'EXCHANGE_SUCC') {
                            //todo
                            pop.message.show('兑换成功', 2);
                            setTimeout(function () {
                                window.location.reload();
                            }, 2000);
                        }
                        else {
                            pop.message.show(_json.SZ_BODY.EXCHANGE_MSG);
                        }
                    }
                }
            });


        },
        init: function () {
            var _self = this;
            $(function () {
                FastClick.attach(document.body);
                /*_self.formatCss();*/
            });
            var couponList = [];
            if(typeof g_couponList != 'undefined'){
                couponList = JSON.parse(g_couponList);
            }
            var vm = new Vue({
                el: '#app',
                data: {
                    couponList: couponList
                }
            });

        },
        bindEvent: function () {
            var _self = this;
            $('#showRule').click(function () {
                $('#mask').removeClass('hidden');
                $('#ruleDialog').removeClass('hidden');
            });
            $('.pDialogClose,#mask').click(function () {
                $('#mask').addClass('hidden');
                $('#ruleDialog').addClass('hidden');
            });
            $('#goBack').click(function () {
                window.history.back();
            });
            $('#exchangeBtn').click(function () {
                if (!_self.status.isApiLoading) {
                    _self.szCodeExchange();
                }
                else {
                    pop.alert('网络信号慢，请稍等！');
                }
            });
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});

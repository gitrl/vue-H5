define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/fastclick');
    require('lib/vue/vue.min');

    var f = {
        init: function () {
            if(g_isLogin == 1 && g_isNeedBind != 1){
                f.showInvite();
            }
            $(function () {
                FastClick.attach(document.body);
            });

            var count = 0;
            if(typeof g_news != "undefined" && g_news != ''){
                var news = JSON.parse(g_news);
                if(news.SZ_HEAD.RESP_CODE == 'S0000'){
                    count = news.SZ_BODY.NON_NOTIFIED_COUNT;
                }
            }

            /*alert(g_news.SZ_BODY.NON_NOTIFIED_COUNT);*/
            var vm = new Vue({
                el: '#list',
                data: {
                    notified_count: count
                }
            });

        },
        showInvite : function(){
            // shan.ajax({
            //     data:{
            //         url : "/coupon/is_show_invite.htm",
            //     },
            //     success : function(json){
            //         if(json && json.SZ_HEAD.RESP_CODE == 'S0000'){
            //             if(json.SZ_BODY.isShow && json.SZ_BODY.isShow == 1){
            //                 if(json.SZ_BODY.activityCode){
            //                     $("#btn-invite").attr("href", "/sz/user/invite/channel/"+ json.SZ_BODY.channelCode +"/activity/"+json.SZ_BODY.activityCode+"?DATA=52015")
            //                         .removeClass("hidden");
            //                 }
            //                 else{
            //                     $("#btn-invite").attr("href", "/sz/user/invite/channel/"+ json.SZ_BODY.channelCode +"?DATA=52015")
            //                         .removeClass("hidden");
            //                 }
                            
            //             }
            //         }
            //         else{
            //             pop.alert(json.SZ_HEAD.RESP_MSG);
            //         }
            //     }
            // });
        },
        bindEvent: function () {
            $(".btn-login").on("click", function(e){
                shan.tools.login({
                    success: function(phone){
                        //f.showInvite();
                        $(".btn-login").addClass("hidden");
                        $(".btn-logout").removeClass("hidden");
                    }
                });
                e.preventDefault();
            });

            $(".btn-logout").on("click", function(e){
                shan.ajax({
                    url : "/sz/user/szlogout_async",
                    success : function(json){
                        g_isLogin = 0;
                        window.location.reload();
                    }
                });
                e.preventDefault();
            });

            $('#index').click(function(){
                shan.tools.statisticsPing('130000');
            });
            $('#activity').click(function(){
                shan.tools.statisticsPing('130001');
            });
            $('#report').click(function(){
                shan.tools.statisticsPing('130002');
            });
            $('#user').click(function(){
                shan.tools.statisticsPing('130003');
            });
            $('#ask').click(function(){
                shan.tools.statisticsPing('33025');
            });
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});

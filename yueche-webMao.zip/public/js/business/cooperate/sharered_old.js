define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    //var share = require('lib/shan_share');
    require('lib/mustache');
    //require('lib/share/wxshare');
    var _key = shan.tools.getUrlParam("key");
    require('lib/fastclick');
    
    var isFirstInput = false;
    var isFirstShowCity = false;
    //提示分享位置层
    var gainSection = pop.layer({
        ele: $('#gainSection')
    });

    //领取成功层
    var gainSuccess = pop.layer({
        ele: $('#gainSuccess'),
        mask: false,
        onShow: function (layer, arguments) {
            renderTicket(arguments);
        },
        bindEvent: function (layer) {
            $('#ruleDialogHandle').on('touchend', function (e) {
                ruleDialog.show();
                e.preventDefault();
            });
        }
    });

    //渲染抵扣券
    function renderTicket(list) {
        for (var i = list.length - 1; i >= 0; i--) {
            list[i].className = function () {
                if (this.benefitType == 'FILIAL') {
                    return 'text-red';
                } else if (this.benefitType == 'HEALTH') {
                    return 'text-orange';
                }
            };
            list[i].FILIAL = function () {
                if (this.benefitType == 'FILIAL') {
                    return true;
                }
                return false;
            };
        }

        var rendered = Mustache.render($('#ticket-template').html(), {LIST: list});
        gainSuccess.ele.find('.red-packet-ticket-list').html(rendered);

        var ticketWidth = 3.75 - 0.3 * 2;
        $('.red-packet-ticket-list li').css('height', parseInt(ticketWidth * 0.351 * 100, 10) / 100 + 0.05 + 'rem');

        $('#userAccount').text(gainPacketForm.phoneInput.val());
    }

    //使用规则弹窗
    var ruleDialog = pop.layer({
        ele: $('#ruleDialog')
    });

    var gainPacketForm = {
        ele: $('#gainPacketForm'),
        phoneInput: $('input[name="phone"]'),
        validate: function () {
            var _self = this;
            var _rtn = true;
            //check phone
            if (!/^1\d{10}/.test(_self.phoneInput.val())) {
                shan.tools.statisticsPing("54121");
                _rtn = false;
                _self.phoneInput.addClass('text-red');
            } else {
                _self.phoneInput.removeClass('text-red');
            }
            return _rtn;
        },
        submit: function () {
            var _self = this;
            shan.tools.statisticsPing("54118", {sourceCode: $('input[name="sourceMemberCode"]').val()});

            //validate phone
            if (!_self.validate()) return;
            //gain_coupon
            shan.ajax({
                url: '/sz/cooperate/gaincoupon',
                data: {
                    sourceMemberCode: $('input[name="sourceMemberCode"]').val(),
                    phone: $('input[name="phone"]').val()
                },
                success: function (json) {
                    if (json && json.SZ_HEAD && json.SZ_HEAD.RESP_CODE == "S0000" && json.SZ_BODY && json.SZ_BODY.GAIN_STATUS) {
                        var _gain_status = json.SZ_BODY.GAIN_STATUS;
                        if (_gain_status == 'GAIN_SUCC') {
                            gainSection.hide();
                            shan.tools.statisticsPing("54124");
                            gainSuccess.show(json.SZ_BODY.COUPON_LIST_D);
                            setTimeout(function(){//领取成功—页面自动跳转
                                shan.tools.statisticsPing("52028");
                                shan.tools.statisticsPing("54127");
                                window.location.href = $('#toActivityIndexBtn').attr('href');
                            },8000);
                        } else {
                            shan.tools.statisticsPing("54122");
                            pop.alert(json.SZ_BODY.GAIN_MSG);
                        }
                        //埋点
                        shan.tools.statisticsPing("52001", {sourceCode: $('input[name="sourceMemberCode"]').val()});
                    }
                    else {
                        shan.tools.statisticsPing("54123");
                        pop.alert(json.SZ_HEAD.RESP_MSG, function () {
                            window.location.href = "/sz/activity/index";
                            return;
                        });
                    }
                }
            });
        },
        init: function () {
            var _self = this;

            _self.ele[0].onsubmit = function (e) {
                _self.submit();
                return false;
            };
        }
    };

    ////微信分享
    //function wxShare(options) {
    //    //根据key获取分享的渠道文案
    //    share.getShareCopy(options.key, function (copy) {
    //        if (copy.receivePath) {
    //            $('#activityImg').attr('src', copy.receivePath);
    //        }
    //
    //        if (copy.activityUrl) {
    //            $('#toActivityIndexBtn').attr('href', copy.activityUrl);
    //            //shan.tools.statisticsPing("52017");
    //        }
    //
    //        share.configWx(options, copy);
    //    });
    //}

    var f = {
        init: function () {
            shan.tools.statisticsPing("54115");
            FastClick.attach(document.body);
            gainPacketForm.init();
            gainSuccess.init();
            ruleDialog.init();
            //wxShare({
            //    key: _key,
            //    success: function (copy) {
            //        //shan.tools.statisticsPing("52001", {sourceCode: _key});
            //    }
            //});

            
            $(".tel-input").click(function(e) {
                if(!isFirstInput){
                    shan.tools.statisticsPing("54117");
                    isFirstShowCity = true;
                }
                $(".tel-input").unbind();
            });
            $("body").bind("touchend", function(e){
                if(!isFirstShowCity && $("#gainSection").offset().top < -100){
                    shan.tools.statisticsPing("54119");
                    isFirstShowCity = true;
                }
            });
            
        },
        bindEvent: function () {
            shan.tools.statisticsPing("52006");
            //用户输入手机号码时，滚动到页面底部
            setTimeout(function () {
                window.scrollTo(0, document.body.scrollHeight);
            }, 100);

            $('#toActivityIndexBtn').click(function () {
                shan.tools.statisticsPing("54126");
                shan.tools.statisticsPing("52017");
            });


        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});
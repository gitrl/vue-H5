define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    require('lib/fastclick');
    var f = {
        code:'',
        init: function () {
            var _self = this;
            $(function () {
                FastClick.attach(document.body);
            });
        },
        bindEvent: function () {
            var _self = this;
            $('#nextBtn').click(function(){
                if(!$(this).hasClass('disabled')){
                    window.location.href='/sz/cooperate/reprogress2/type/'+_self.code+'?DATA=120002';
                }
            });
            $('#userType').on('click','li',function(){
                if(!$(this).hasClass('item-on')){
                    $('#nextBtn').removeClass('disabled');
                    $(this).addClass('item-on').siblings().removeClass('item-on');
                    _self.code=$(this).data('code');
                }
            });
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});

define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/fastclick');
    var cityinstit = require('lib/cityinstit');
    var COMBOINFO = {
        "GDS110010001": {
            "sname":"孝心套餐",
            "name": "关爱父母孝心套餐",
            "title": "基础体检套餐",
            "szPrice":235,
            "activityPrice":0
        },
        "GDS110010002": {
            "sname":"孝心升级",
            "name": "关爱父母孝心升级",
            "title": "中老年基础体检套餐",
            "szPrice":334,
            "activityPrice":99
        },
        "GDS110010003" :{
            "sname":"标准套餐",
            "name": "关爱父母标准套餐",
            "title": "高性价比必查套餐",
            "szPrice":598,
            "activityPrice":398
        },
        "GDS110010004" :{
            "sname":"高级套餐",
            "name": "关爱父母高级套餐",
            "title": "升级多种肿瘤筛查",
            "szPrice":796,
            "activityPrice":596
        },
        "GDS110010005" :{
            "sname":"豪华套餐",
            "name": "关爱父母豪华套餐",
            "title": "适合中老年的全面健康检查",
            "szPrice":1698,
            "activityPrice":1498
        },
        "GDS110010102" :{
            "sname":"肿瘤专项",
            "name": "肿瘤专项套餐",
            "title": "高压人群常见癌症必查",
            "szPrice":586,
            "activityPrice":386
        },
        "GDS110010103" :{
            "sname":"妇科专项",
            "name": "妇科专项(HPV检测)",
            "title": "为已婚女性定制的体检套餐",
            "szPrice":599,
            "activityPrice":399
        },
        "GDS110010101" :{
            "sname":"办公族年度",
            "name": "办公族年度套餐",
            "szPrice":495,
            "activityPrice":395
        },
        "GDS110010104" :{
            "sname":"高级无忧",
            "name": "高级无忧套餐",
            "szPrice":618,
            "activityPrice":518
        },
        "GDS110010105" :{
            "sname":"尊享全面",
            "name": "尊享全面套餐",
            "szPrice":1298,
            "activityPrice":1198
        }
    };
    var f = {
        imgComboAreaHeight: 0,
        onChoose: function (opt) {
            //自定义选中机构后的行为
            console.log(opt);
        },
        orderBooking: function (_str) {
            var _action = "/sz/order/confirm";
            _action += '?goodsCode=' + _str;
            _action += '&source=' + $('#source').val();
            $('#orderBooking').attr('action', _action).submit();
        },
        formatBottomInfo: function (goodsCode) {

            var _info = COMBOINFO[goodsCode];
            $('#pkgName').html(_info.name);
            $('#pkgSzPrice').html('善诊价：￥' + _info.szPrice);
            $('#pkgActivityPrice').html('口令价：￥' + _info.activityPrice);

        },
        init: function () {
            var _self = this;
            $(function () {
                if (!localStorage.getItem('isPostback')) {
                    $('#firstTop').find('.icon-dot').removeClass('hidden');
                }
                FastClick.attach(document.body);
                cityinstit.linkCss();
                $('#goodsCode').val('GDS110010003');
                _self.imgComboAreaHeight = $('#imgComboArea').outerHeight(true);
                $('.dataAdd').hide();
            });
        },
        bindEvent: function () {
            var _self = this;
            $('.imgCombo li').click(function () {
                if (!$(this).children('.pkg-item').hasClass('item-on')) {
                    var _combo = $(this).attr('id').substring(3),
                        _id = 'combo' + _combo,
                        _tipsid = 'tips' + _combo;
                    $('.imgCombo li .pkg-item').removeClass('item-on');
                    $(this).children('.pkg-item').addClass('item-on');
                    $('#goodsCode').val($(this).data('code'));
                    $('#comboBox').children('div').addClass('hidden');
                    $('#' + _id).removeClass('hidden');
                    _self.formatBottomInfo($('#goodsCode').val());
                    $('#secondTop').find('.item').removeClass('item-on');
                    $('#' + _tipsid).addClass('item-on');
                    //埋点
                    switch (_combo){
                        case 'Standard':
                            shan.tools.statisticsPing("41002");
                            break;
                        case 'Advanced':
                            shan.tools.statisticsPing("41003");
                            break;
                        case 'Luxury':
                            shan.tools.statisticsPing("41004");
                            break;
                        case 'LiteUpgrade':
                            shan.tools.statisticsPing("41001");
                            break;
                        default :
                            break;
                    };
                }
            });
            $('#secondTop li').click(function () {
                if (!$(this).hasClass('item-on')) {
                    var _combo = $(this).attr('id').substring(4),
                        _id = 'combo' + _combo,
                        _imgsid = 'img' + _combo;
                    $(this).addClass('item-on').siblings('li').removeClass('item-on');
                    $('#goodsCode').val($(this).data('code'));
                    $('#comboBox').children('div').addClass('hidden');
                    $('#' + _id).removeClass('hidden');
                    _self.formatBottomInfo($('#goodsCode').val());
                    $('#imgComboArea').find('.pkg-item').removeClass('item-on');
                    $('#' + _imgsid).children('.pkg-item').addClass('item-on');
                    $('#comboMain').stop(true).animate({
                        scrollTop: +_self.imgComboAreaHeight + 5,
                    }, 300);
                    //埋点
                    switch (_combo){
                        case 'Standard':
                            shan.tools.statisticsPing("41006");
                            break;
                        case 'Advanced':
                            shan.tools.statisticsPing("41007");
                            break;
                        case 'Luxury':
                            shan.tools.statisticsPing("41008");
                            break;
                        case 'LiteUpgrade':
                            shan.tools.statisticsPing("41005");
                            break;
                        default :
                            break;
                    };

                }
            });
            $('[data-role="getCityInstit"]').click(function () {
                shan.tools.statisticsPing("40001");
                cityinstit.run({goodsCode: $('#goodsCode').val(), onChoose: _self.onChoose});
            });
            $('#btnBooking').click(function () {
                _self.orderBooking($('#goodsCode').val());
            });
            $('#comboMain').scroll(function () {
                if ($('#comboMain').scrollTop() >= _self.imgComboAreaHeight) {
                    $('#firstTop').fadeOut();
                    $('#secondTop').fadeIn();
                }
                else {
                    $('#firstTop').fadeIn();
                    $('#secondTop').fadeOut();
                }
            });
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});

define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    require('lib/fastclick');
    var TYPE = shan.tools.getUrlParam('type');
    var f = {
        chooseData: {
            jzbs: 0,
            sg: 0,
            bgs: 0,
            tsgzhj: 0,
            yld: 0,
            cqxy: 0,
            jchj: 0,
            xhxdzp: 0,
            xgygzys: 0,
            swmh: 0,
            tlyzxj: 0,
            cqks: 0,
            pnbs: 0,
            gjtt: 0
        },
        getStrStatus: function (_data) {
            var _self = this,
                _status = '';
            try {
                if (_data) {
                    for (x in _data) {
                        _status += _data[x];
                    }
                }
            }
            catch (e) {
                _status = '';
            }
            return _status;
        },
        init: function () {
            var _self = this;
            $(function () {
                FastClick.attach(document.body);

            });
        },
        bindEvent: function () {
            var _self = this;
            $('#chooseList').on('click', 'li', function () {
                if ($(this).hasClass('item-on')) {
                    $(this).removeClass('item-on');
                    _self.chooseData[$(this).data('name')] = 0;
                }
                else {
                    $(this).addClass('item-on');
                    _self.chooseData[$(this).data('name')] = 1;
                }
            });

            $('#nextBtn').click(function () {
                var _status = _self.getStrStatus(_self.chooseData);
                window.location.href = '/sz/cooperate/reprogress3/type/' + TYPE + '/status/' + _status+'?DATA=120003';
            });
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});

define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    var share = require('lib/shan_share');
    require('lib/share/wxshare');
    require('lib/fastclick');
    require('lib/jquery.tmpl');
    var TYPE = shan.tools.getUrlParam('type');
    var STATUS = shan.tools.getUrlParam('status');
    var SHARE = shan.tools.getUrlParam('share');
    var STATUSARRAY = STATUS.split('');
    var OPTIONS = {
        shareTitle: null,
        params: location.pathname.substring(location.pathname.indexOf('/type/')),
        imgUrl: 'http://'+window.location.host+'/static/images/cooperate/recommend/share_img.png',
        success: function () {
            share.shareTipsLayer.hide();
            $('.yo-mask').remove();
            pop.alert('分享成功！');
        },
        shareContent: '善诊，您的健康管理专家。轻松四步，帮您了解您和家人的身体状况。'
    };


    function configWx(options) {
        var controller = new wxController();
        controller.init(
            ['onMenuShareTimeline', 'onMenuShareAppMessage'],
            function () {
                controller.configShareTimeline({
                    title: options.shareTitle || "福利来了！送给爸妈的免费体检，快来领取吧！", // 分享标题
                    link: 'http://'+window.location.host+'/sz/cooperate/recommendresult/share/shared' + options.params, // 分享链接
                    imgUrl: options.imgUrl || "http://"+window.location.host+"/static/images/redPacket/share.jpg", // 分享图标
                    success: function () {
                        if (typeof(options.success) == 'function') {
                            options.success();
                        }
                        shan.tools.statisticsPing("120020");
                    },
                    cancel: function () {
                        // 用户取消分享后执行的回调函数

                    }
                });
                controller.configShareAppMessage({
                    title: options.shareTitle || "福利来了！送给爸妈的免费体检，快来领取吧！", // 分享标题
                    desc: options.shareContent || "价值300元的体检抵扣券，可预约全国160多个城市的医院和体检机构", // 分享描述
                    link: 'http://'+window.location.host+'/sz/cooperate/recommendresult/share/shared' + options.params, // 分享链接
                    imgUrl: options.imgUrl || "http://"+window.location.host+"/static/images/redPacket/share.jpg", // 分享图标
                    type: '', // 分享类型,music、video或link，不填默认为link
                    dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
                    success: function () {
                        // 用户确认分享后执行的回调函数
                        if (typeof(options.success) == 'function') {
                            options.success();
                        }
                        shan.tools.statisticsPing("120019");
                    },
                    cancel: function () {
                        // 用户取消分享后执行的回调函数

                    }
                });
            });
    }

    var f = {
        healthData: {
            xn: '',
            fb: '',
            nk: '',
            az: '',
            gg: '',
            gj: ''
        },
        chooseData: {
            jzbs: 0,
            sg: 0,
            bgs: 0,
            tsgzhj: 0,
            yld: 0,
            cqxy: 0,
            jchj: 0,
            xhxdzp: 0,
            xgygzys: 0,
            swmh: 0,
            tlyzxj: 0,
            cqks: 0,
            pnbs: 0,
            gjtt: 0
        },
        libList: ['jzbs', 'sg', 'bgs', 'tsgzhj', 'yld', 'cqxy', 'jchj', 'xhxdzp', 'xgygzys', 'swmh', 'tlyzxj', 'cqks', 'pnbs', 'gjtt'],
        lib: {
            libScore: {
                xn: [6, 5, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0],
                fb: [1, 0, 0, 2, 0, 4, 0, 0, 0, 0, 0, 2, 0, 0],
                nk: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0],
                az: [4, 0, 1, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                gg: [0, 0, 1, 0, 0, 0, 0, 0, 0, 4, 8, 0, 0, 0],
                gj: [0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 3]
            },
            libTypeScore: {
                xn: [0, 6, 6, 0, 0],
                fb: [0, 1, 0, 1, 0],
                nk: [0, 1, 0, 0, 0],
                az: [0, 0, 0, 0, 0],
                gg: [0, 2, 2, 0, 0],
                gj: [0, 0, 0, 0, 0]
            },
            libScoreLevel: {
                xn: {low: 10, middle: 16, high: 21},
                fb: {low: 1, middle: 5, high: 10},
                nk: {low: 0, middle: 1, high: 3},
                az: {low: 1, middle: 6, high: 8},
                gg: {low: 5, middle: 7, high: 15},
                gj: {low: 1, middle: 2, high: 5}
            },
            libGoods: {
                xn: {
                    low: ['A2', 'A3', 'A4', 'B1', 'B2', 'B3', 'B4', 'C1', 'C2', 'C3', 'C4'],
                    middle: ['A2', 'A3', 'A4', 'B1', 'B2', 'B4', 'C1', 'C2', 'C3', 'C4'],
                    high: ['A4', 'C4']
                },
                fb: {
                    low: ['A2', 'A3', 'A4', 'B1', 'B2', 'B3', 'B4', 'C1', 'C2', 'C3', 'C4'],
                    middle: ['A2', 'A3', 'A4', 'B1', 'B2', 'B3', 'B4', 'C1', 'C2', 'C3', 'C4'],
                    high: ['A3', 'A4', 'C4']
                },
                nk: {
                    low: ['A2', 'A3', 'A4', 'B1', 'B2', 'B3', 'B4', 'C1', 'C2', 'C3', 'C4'],
                    middle: ['A2', 'A3', 'A4', 'B1', 'B2', 'B3', 'B4', 'C3', 'C4'],
                    high: ['A3', 'A4', 'B3', 'B4', 'C3', 'C4']
                },
                az: {
                    low: ['A2', 'A3', 'A4', 'B1', 'B2', 'B3', 'B4', 'C1', 'C2', 'C3', 'C4'],
                    middle: ['A2', 'A3', 'A4', 'B1', 'B2', 'B3', 'B4', 'C2', 'C3', 'C4'],
                    high: ['A4', 'B3', 'B4', 'C4']
                },
                gg: {
                    low: ['A2', 'A3', 'A4', 'B1', 'B2', 'B3', 'B4', 'C1', 'C2', 'C3', 'C4'],
                    middle: ['A2', 'A3', 'A4', 'B1', 'B2', 'B4', 'C1', 'C2', 'C3', 'C4'],
                    high: ['A3', 'A4', 'B1', 'B2', 'B4', 'C4']
                },
                gj: {
                    low: ['A2', 'A3', 'A4', 'B1', 'B2', 'B3', 'B4', 'C1', 'C2', 'C3', 'C4'],
                    middle: ['A2', 'A3', 'A4', 'B4', 'C1', 'C2', 'C3', 'C4'],
                    high: ['A3', 'A4', 'C2', 'C4']
                }
            },
            libGoodsCode: {
                A2: {
                    goodsCode: 'GDS110010003',
                    goodsName: '关爱父母标准套餐',
                    goodsRemark: '您的健康一般般哦。善诊建议您进行全面体检，了解自己的健康状况，不给任何风险因素危害您健康的机会。',
                    goodsDesc: '基础检查升级 高性价比选择',
                    goodsOriginPrice: 598,
                    goodsActivePrice: 398,
                    url: '/sz/product/newdetail?goodsCode=GDS110010003&price=398&activityCode=ACT518712462&orderFrom=1&tag=1',
                    pingCode: '120006'
                },
                A3: {
                    goodsCode: 'GDS110010004',
                    goodsName: '关爱父母高级套餐',
                    goodsRemark: '您的健康不太好了哦，多项指标向您发出预警。善诊推荐您进行深度体检，防患于未然！',
                    goodsDesc: '高龄父母首选 风险项深度查',
                    goodsOriginPrice: 796,
                    goodsActivePrice: 596,
                    url: '/sz/product/newdetail?goodsCode=GDS110010004&price=596&activityCode=ACT518712462&orderFrom=1&tag=1',
                    pingCode: '120007'
                },
                A4: {
                    goodsCode: 'GDS110010005',
                    goodsName: '关爱父母豪华全面套餐',
                    goodsRemark: '您的健康要哭了。善诊强烈建议您进行全面深度检查！',
                    goodsDesc: '全面肿瘤筛查 关爱心脑血管',
                    goodsOriginPrice: 1698,
                    goodsActivePrice: 1398,
                    url: '/sz/product/newdetail?goodsCode=GDS110010005&price=1398&activityCode=ACT518712462&orderFrom=1&tag=1',
                    pingCode: '120008'

                },
                B1: {
                    goodsCode: 'GDS110010101',
                    goodsName: '办公族年度套餐',
                    goodsRemark: '您的健康状况总体较好。工作再忙，也要记得爱自己哦。善诊提醒您，年度体检不可少，身体健康需关照。',
                    goodsDesc: '基础检查升级 高性价比选择',
                    goodsOriginPrice: 595,
                    goodsActivePrice: 395,
                    url: '/sz/product/newdetail?goodsCode=GDS110010101&price=395&activityCode=ACT518712462&orderFrom=1&tag=2',
                    pingCode: '120009'
                },
                B2: {
                    goodsCode: 'GDS110010104',
                    goodsName: '高级无忧套餐',
                    goodsRemark: '',
                    goodsDesc: '更全面的基础体检套餐',
                    goodsOriginPrice: 718,
                    goodsActivePrice: 518,
                    url: '/sz/product/newdetail?goodsCode=GDS110010104&price=518&activityCode=ACT518712462&orderFrom=1&tag=2',
                    pingCode: '120010'
                },
                B3: {
                    goodsCode: 'GDS110010102',
                    goodsName: '肿瘤专项套餐',
                    goodsRemark: '您的健康整体良好。生活工作压力大？善诊推荐您进行全面肿瘤筛查，消除健康隐患！',
                    goodsDesc: '高压人群必查 对肿瘤说No！',
                    goodsOriginPrice: 586,
                    goodsActivePrice: 386,
                    url: '/sz/product/newdetail?goodsCode=GDS110010102&price=386&activityCode=ACT518712462&orderFrom=1&tag=2',
                    pingCode: '120011'
                },
                B4: {
                    goodsCode: 'GDS110010105',
                    goodsName: '尊享全面套餐',
                    goodsRemark: '您的健康不是很好呀。身体是革命的本钱，善诊提醒您该体检啦！',
                    goodsDesc: '深度检查 不忽视任何隐患',
                    goodsOriginPrice: 1398,
                    goodsActivePrice: 1198,
                    url: '/sz/product/newdetail?goodsCode=GDS110010105&price=1198&activityCode=ACT518712462&orderFrom=1&tag=2',
                    pingCode: '120012'
                },
                C1: {
                    goodsCode: 'GDS110010011',
                    goodsName: '医院标准套餐',
                    goodsRemark: '',
                    goodsDesc: '常规标准检查 掌控你的健康',
                    goodsOriginPrice: 596,
                    goodsActivePrice: 396,
                    url: '/sz/product/newdetail?goodsCode=GDS110010011&price=396&activityCode=ACT518712462&orderFrom=1&tag=3',
                    pingCode: '120013'
                },
                C2: {
                    goodsCode: 'GDS110010012',
                    goodsName: '医院关爱加强套餐',
                    goodsRemark: '',
                    goodsDesc: '关节疼痛 肿瘤风险 早排查',
                    goodsOriginPrice: 798,
                    goodsActivePrice: 598,
                    url: '/sz/product/newdetail?goodsCode=GDS110010012&price=598&activityCode=ACT518712462&orderFrom=1&tag=3',
                    pingCode: '120014'
                },
                C3: {
                    goodsCode: 'GDS110010013',
                    goodsName: '医院关爱精选高级套餐',
                    goodsRemark: '',
                    goodsDesc: '重要脏器 重点呵护',
                    goodsOriginPrice: 1198,
                    goodsActivePrice: 998,
                    url: '/sz/product/newdetail?goodsCode=GDS110010013&price=998&activityCode=ACT518712462&orderFrom=1&tag=3',
                    pingCode: '120015'
                },
                C4: {
                    goodsCode: 'GDS110010014',
                    goodsName: '医院关爱高端豪华套餐',
                    goodsRemark: '您的健康好难过呀。答应善诊要时刻记得关心它，好吗？快去做个深度全面检查吧！',
                    goodsDesc: '多种隐患 仅需这一个对策',
                    goodsOriginPrice: 2198,
                    goodsActivePrice: 1998,
                    url: '/sz/product/newdetail?goodsCode=GDS110010014&price=1998&activityCode=ACT518712462&orderFrom=1&tag=3',
                    pingCode: '120016'
                }
            },
            libAge: {
                young: {
                    low: 0,
                    middle: 5,
                    high: 8
                },
                old: {
                    low: 0,
                    middle: 3,
                    high: 5
                }
            },
            libAgeLevel: {
                low: 50,
                middle: 65,
                high: 75
            },
            libClassName: {
                low: '',
                middle: 'err',
                high: 'err high'
            }
        },
        fomateDom: function (_age, _goodsArr) {
            var _self = this, i, x, goodsData = [];
            $('#healthData').children('li').each(function () {
                $(this).addClass(_self.lib.libClassName[_self.healthData[$(this).data('name')]]);
                $(this).find('.progress i').addClass('ani');
            });
            $('#age').text(_age).addClass('fade-in-up');
            for (x in _self.lib.libAgeLevel) {
                if (_age <= _self.lib.libAgeLevel[x]) {
                    $('#ageBox').addClass(_self.lib.libClassName[x]);
                    $('#ageBoxCeil').addClass('rotate_45')
                    break;
                }
            }

            if (_goodsArr.length > 0) {
                for (i = 0; i < _goodsArr.length; i++) {
                    goodsData.push(_self.lib.libGoodsCode[_goodsArr[i]]);
                }
                $('#szComment').html(goodsData[0].goodsRemark).addClass('fade-in-up');
                $('#recommendGoodsList').html($('#dRecommendGoodsList').tmpl(goodsData));
                if (SHARE == 'shared') {
                    shan.tools.statisticsPing("120021");
                    $('#shareImg').removeClass('hidden');
                }
                else {
                    $('#recommendGoods').removeClass('hidden');
                    $('#moreGoodsBtn').removeClass('hidden');
                }

            }
            else {
                $('#szComment').html('您的健康非常棒！要继续加油哦！健康的身体也需要您的细心呵护，善诊建议您每年至少进行一次常规体检。').addClass('fade-in-up');
                if (SHARE == 'shared') {
                    shan.tools.statisticsPing("120021");
                    $('#shareImg').removeClass('hidden');
                }
                else {
                    $('#shareBtn').removeClass('hidden');
                }

            }


            //分享参数设置
            OPTIONS.shareTitle = '我的身体年龄是' + _age + ' |你也快来测测看';


        },
        getGoodsArray: function () {
            var _self = this, x, i, j, _temp = ['A2', 'A3', 'A4', 'B1', 'B2', 'B3', 'B4', 'C1', 'C2', 'C3', 'C4'], _temp2 = [], _tempresult = [], _temp3 = [];
            for (x in _self.healthData) {
                for (i = 0; i < _temp.length; i++) {
                    for (j = 0; j < _self.lib.libGoods[x][_self.healthData[x]].length; j++) {
                        if (_temp[i] === _self.lib.libGoods[x][_self.healthData[x]][j]) {
                            _temp3.push(_temp[i]);
                            break;
                        }
                    }
                }
                _temp = $.map(_temp3, function (n) {
                    return n;
                });
                ;
                _temp3 = [];
            }
            _temp.sort();
            //当测试者为高龄，仅保留A, C相关元素；当测试者非高龄，保留B, C相关元素
            //当输出集合中存在三个以上元素时，仅保留A（或B）相关元素中数字最小者及其后一项，以及C相关元素中数字最小者
            if (_temp.length < 11) {

                _temp2 = $.map(_temp, function (n) {
                    if (n.indexOf('C') >= 0) {
                        return n;
                    }
                });
                _temp2 = [_temp2[0]];

                if (TYPE == '1' || TYPE == '2') {//高龄
                    _temp = $.grep(_temp, function (n, i) {
                        return (n.indexOf('A') >= 0);
                    });
                }
                else if (TYPE == '3' || TYPE == '4') {
                    _temp = $.grep(_temp, function (n, i) {
                        return (n.indexOf('B') >= 0);
                    });
                }
                else {
                    _tempresult = _temp2;
                }
                if (_tempresult.length == 0) {
                    if (_temp.length >= 2) {
                        _tempresult = [_temp[0], _temp[1], _temp2[0]];
                    }
                    else {
                        _tempresult = _temp.concat(_temp2);
                    }
                }
            }
            return _tempresult;
        },
        setChooseData: function (_data) {
            var _self = this,
                _temp = [];
            try {
                if (_data) {
                    _data = _data + '';
                    _temp = _data.split('');
                    for (var i = 0; i < _temp.length; i++) {
                        _self.chooseData[_self.libList[i]] = _temp[i];
                    }
                }
            }
            catch (e) {
                console.log(e);
            }
        },
        getStrStatus: function (_data) {
            var _self = this,
                _status = '';
            try {
                if (_data) {
                    for (x in _data) {
                        _status += _data[x];
                    }
                }
            }
            catch (e) {
                _status = '';
            }
            return _status;
        },
        setHealthData: function () {
            var _self = this, i, j, val, x, y;
            for (x in _self.healthData) {
                val = 0;
                for (i = 0; i < _self.lib.libScore[x].length; i++) {
                    val += parseInt(STATUSARRAY[i]) * _self.lib.libScore[x][i];
                }
                val += parseInt(_self.lib.libTypeScore[x][TYPE]);
                for (y in _self.lib.libScoreLevel[x]) {
                    if (val <= _self.lib.libScoreLevel[x][y]) {
                        _self.healthData[x] = y;
                        break;
                    }
                }
            }

        },
        getAge: function () {
            var _self = this, x, _temp = 0,_yOrO='young';
            if (TYPE == '1' || TYPE == '2') {
                _temp = 45;
                _yOrO='old';
            }
            else {
                _temp = 25;
            }
            for (x in _self.healthData) {
                _temp += parseInt(_self.lib.libAge[_yOrO][_self.healthData[x]]);
            }
            return _temp;
        },
        init: function () {
            var _self = this;
            $(function () {
                FastClick.attach(document.body);
                _self.setChooseData(STATUS);
                _self.setHealthData();
                _self.fomateDom(_self.getAge(), _self.getGoodsArray());
                if (shan.tools.isWeixin()) {
                    configWx(OPTIONS);
                }
            });
        },
        bindEvent: function () {
            var _self = this;
            $('#shareBtn').click(function () {
                shan.tools.statisticsPing("120018");
                share.shareTipsLayer.show();
            });
            $('#recommendGoodsList').on('click', 'li', function () {
                shan.tools.statisticsPing($(this).data('ping'));
            });
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});

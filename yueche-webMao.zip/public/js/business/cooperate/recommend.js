define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    require('lib/fastclick');
    var f = {
        init: function () {
            var _self = this;
            shan.tools.statisticsPing("120000");
            $(function () {
                FastClick.attach(document.body);
            });
        },
        bindEvent: function () {
            var _self = this;
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});

define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/fastclick');
    require('lib/jquery.tmpl');
    require('lib/vue/vue');
    //var share = require('lib/shan_share');
    //require('lib/share/wxshare');

    function syncChannelCode(channelCode, activityCode) {
        shan.ajax({
            url: '/sz/cooperate/syncChannel',
            data: {
                key: g_key,
                channelCode: channelCode,
                activityCode: activityCode
            },
            success: function (_json) {
                if (_json && _json.SZ_HEAD && _json.SZ_HEAD.RESP_CODE == "S0000") {
                    g_key = _json.SZ_BODY.DATA;
                    //分享获券
                    //share.wxShare({
                    //    key: g_key,
                    //    success: function (copy) {
                    //        share.shareSuccessCallback({
                    //            key: g_key,
                    //            channelCode: channelCode,
                    //            activityCode: activityCode,
                    //            GAIN_SUCC: function (list) {
                    //                share.inviteSuccessDialog.ele.find('.btn-list a:first-child').attr('href', copy.activityUrl);
                    //                share.inviteSuccessDialog.show(list);
                    //            }
                    //        });
                    //        share.shareTipsLayer.hide();
                    //        shan.tools.statisticsPing("54026", {sourceCode: g_key});
                    //        $('#shareMask').addClass('hidden');
                    //    }
                    //});
                }
            }
        });
    }

    var f = {
            status: {
                isLogin: g_isLogin,
                isApiLoading: false,
                timer: 60,
                currentTimer: 60,
                isCanSendPhoneCode: true,
                $sendPhoneCodeBtn: $('#getPhoneVerifyCode'),
                CHANNEL_CODE: '',
                activityCode: shan.tools.getUrlParam('activityCode')
            },
            formatBgHeight: function () {
                var viewHeight = document.body.scrollHeight;
                document.getElementById('bgImg').style.height = viewHeight + 'px';
                $('.m-body').css('max-height', (viewHeight - 100) + 'px');
            }
            ,
            formatTicketListCss: function () {
                var ticketWidth = 3.75 * 0.9 - 0.1 * 2;
                $('.red-packet-ticket-list li').css('height', parseInt(ticketWidth * 0.351 * 100, 10) / 100 + 0.05 + 'rem');

                $('.available-ticket-item').css('height', parseInt((3.75 - 0.44 - 0.15) * 0.323 * 100, 10) / 100 + 'rem');
            }
            ,
            phoneCheck: function () {
                var _$input = $('#contactPhone'),
                    _val = $.trim(_$input.val());
                if (/^1\d{10}/.test(_val)) {
                    return _val;
                } else {
                    return false;
                }
            }
            ,
            resetCodeTimer: function () {
                var _self = this,
                    _count = _self.status.currentTimer;
                _self.status.currentTimer = --_count;
                if (--_count <= 0) {
                    _self.status.$sendPhoneCodeBtn.removeClass("disabled").html("获取验证码");
                    _self.status.isCanSendPhoneCode = true;
                }
                else {
                    _self.status.$sendPhoneCodeBtn.html(_count + "s 重新发送");
                    window.setTimeout(function () {
                        _self.resetCodeTimer();
                    }, 1000);
                }
            }
            ,
            sendVerifyCode: function (phone) {
                var _self = this;
                if (phone && _self.status.isCanSendPhoneCode) {
                    _self.status.isCanSendPhoneCode = false;
                    _self.status.$sendPhoneCodeBtn.addClass('disabled');
                    _self.status.currentTimer = _self.status.timer;
                    _self.resetCodeTimer();
                    shan.ajax({
                        url: '/sz/index/smsverify',
                        data: {
                            phone: phone
                        },
                        success: function (_json) {
                            if (_json.SZ_HEAD.RESP_CODE === "S0000") {
                                pop.alert("验证码已成功发送至您手机中");
                            }
                            else if (_json.SZ_HEAD.RESP_CODE === "2") {
                                pop.alert("抱歉，该手机号未注册");
                            } else if (_json.SZ_HEAD.RESP_CODE === "3") {
                                pop.alert("抱歉，该手机登录次数过多 请等30分钟后重试");
                            } else if (_json.SZ_HEAD.RESP_CODE === "5") {
                                pop.alert("抱歉，请刷新页面后重新输入验证码");
                            }
                            else {
                                pop.alert("发送失败请稍后再试");
                            }
                        }
                    });
                }

            }
            ,
            verifyCodeCheck: function () {
                var _$input = $("#phoneVerifyCode"),
                    _val = _$input.val();
                if (/\d{6}/.test(_val)) {
                    return _val;
                }
                else {
                    return false;
                }
            }
            ,
            szCodeExchange: function () {
                var vm = new Vue({
                    el: '#ticketList',
                    data: {
                        couponList: []
                    }
                });
                var _self = this,
                    _szCode = $.trim($('#szCode').val()),
                    _data = {};
                _data.isLogin = _self.status.isLogin;
                if (_self.status.isLogin == '0') {
                    var _phone = _self.phoneCheck(),
                        _code = _self.verifyCodeCheck();
                    if (!_phone) {
                        pop.alert("请输入正确的手机号码");
                        return false;
                    }
                    if (!_code) {
                        pop.alert("验证码输入错误");
                        return false;
                    }
                    _data.phoneVerifyCode = _code;
                }
                _data.contactPhone = _phone;
                if (_szCode == '') {
                    pop.alert("未输入口令");
                    return false;
                }
                _data.szCode = _szCode;
                _self.status.isApiLoading = true;
                shan.ajax({
                    url: '/sz/cooperate/exchangeapi',
                    data: _data,
                    type: 'post',
                    success: function (_json) {
                        _self.status.isApiLoading = false;
                        if (_json.SZ_HEAD.RESP_CODE != 'S0000') {
                            shan.tools.statisticsPing("350107");
                            $('#mErrMsg').html(_json.SZ_HEAD.RESP_MSG);
                        }
                        else {
                            shan.tools.statisticsPing("350106");
                            if (_json.SZ_BODY.EXCHANGE_STATUS == 'EXCHANGE_SUCC') {
                                //todo
                                shan.tools.statisticsPing("54022");
                                $('.m-body').addClass('hidden');
                                $('#ticketList').parents('.m-body').removeClass('hidden');
                                /*$('#ticketList').empty().append($('#dmyTicketList').tmpl(_json.SZ_BODY.COUPON_LIST_D));*/
                                vm.couponList = _json.SZ_BODY.COUPON_LIST_D;
                                /*_self.formatTicketListCss();*/
                                if (_self.status.isLogin == '0') {
                                    $('#myTicketAccount').html('口令券已放入' + _data.contactPhone + '账户中');
                                }

                            }
                            else {
                                //if (_json.SZ_BODY.SHOW_SHARE_COUPON == '1' && shan.tools.isWeixin() == 1) {
                                //    shan.tools.statisticsPing("54024");
                                //    $('#shareShow').removeClass('hidden');
                                //    $('#shareShowInfo').html(_json.SZ_BODY.EXCHANGE_MSG + '<br>分享给朋友将再获得一次免费体检！');
                                //    $('#mForm').addClass('hidden');
                                //    $('#szCodeBox').addClass('hidden');
                                //    $('#mErrMsg').addClass('hidden');
                                //    $('#exchangeBtn').parent().addClass('hidden');
                                //    $('#myRules').addClass('hidden');
                                //    $('#myAccount').addClass('hidden');
                                //    var activityCode = _json.SZ_BODY.ACTIVITY_CODE || "";
                                //    var channelCode = _json.SZ_BODY.CHANNEL_CODE || "";
                                //    syncChannelCode(channelCode, activityCode);//记录渠道源
                                //}
                                //else {
                                    $('#mErrMsg').html(_json.SZ_BODY.EXCHANGE_MSG);
                                //}
                            }
                        }
                    }
                });


            },
            init: function () {
                var _self = this,
                    _url = '/sz/cooperate/modelindex?activityCode=' + _self.status.activityCode;
                $(function () {
                    FastClick.attach(document.body);
                    _self.formatBgHeight();
                    shan.tools.statisticsPing("54020");
                    $('.goIndex').attr('href', _url);
                });
            }
            ,
            bindEvent: function () {
                var _self = this;
                //获取验证码
                $('#getPhoneVerifyCode').click(function () {
                    if (!$(this).attr('disabled')) {
                        var _phone = _self.phoneCheck();
                        if (_phone) {
                            _self.sendVerifyCode(_phone);
                        }
                        else {
                            pop.alert("请输入正确的手机号码");
                        }
                    }
                });
                $('#exchangeBtn').click(function () {
                    if (!_self.status.isApiLoading) {
                        _self.szCodeExchange();
                        shan.tools.statisticsPing("54021");
                    }
                    else {
                        pop.alert('网络信号慢，请稍等！');
                    }
                });

                $('#shareBtn a').click(function () {
                    $('#shareMask').removeClass('hidden');
                    shan.tools.statisticsPing("54025");
                });

                $('#shareMask').click(function () {
                    $(this).addClass('hidden');
                });

                //兑换成功返回首页
                $('#goIndex').click(function () {
                    shan.tools.statisticsPing("54023");
                });

                $("#szCode").click(function(){
                    shan.tools.statisticsPing("350101");
                });

                $("#contactPhone").click(function(){
                    shan.tools.statisticsPing("350102");
                });

                $("#getPhoneVerifyCode").click(function(){
                    shan.tools.statisticsPing("350103");
                });

                $("#phoneVerifyCode").click(function(){
                    shan.tools.statisticsPing("350104");
                });

                $("#exchangeBtn").click(function(){
                    shan.tools.statisticsPing("350105");
                });
            }
        }
        ;
    var run = function () {
        f.init();
        f.bindEvent();
    }
    //初始化函数
    exports.run = run;
});


define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop =require('lib/dialog');
    require('lib/fastclick');

    var JS = (function () {
        var $mask = $('#mask'),
            $tips_dialog = $('#tips_dialog');

        var isWeixin = shan.tools.isWeixin();
        return {
            init: function () {
                this.beginning(); //初始化
                this.bindEvents(); //绑定事件
            },

            //初始化
            beginning: function () {
                var _self = this;
                $(function () {
                    FastClick.attach(document.body);
                });
                _self.getTestVersion();
            },

            //绑定事件
            bindEvents: function () {
                var _self = this;
                //点击活动说明按钮
                $('#tips_btn').on('click',function(e){
                    $mask.add($tips_dialog).removeClass('hidden');
                });
                //点击关闭按钮
                $('#close_btn').on('click',function(e){
                    $mask.add($tips_dialog).addClass('hidden');
                })


            },

            getTestVersion: function(){
                if (g_source == 2) {
                    this.testVersion = 2;
                }else if (g_source == 1) {
                    this.testVersion = 1;
                }else{
                    this.testVersion = 0;
                }
            }
        }
    })();

    $(function () {
        JS.init();
    });


});
define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/share/wxshare');
    require('lib/fastclick');
    require('lib/vue/vue.min');
    var tag = shan.tools.getUrlParam("tag");
    
    var f = {
        init: function () {
            var _self = this,
                _activityCode,
                _url = '/sz/cooperate/modelexchange?activityCode=';
            
            $(function () {
                FastClick.attach(document.body);
                _activityCode = shan.tools.getUrlParam('activityCode');
                _url += _activityCode;
                $('#gotoExchangeBtn').attr('href', _url);
                setTimeout(function(){
                    $('#gotoExchangeBtn').addClass('swing');
                },200);
                shan.tools.statisticsPing(54030,{sourceCode:_activityCode});

                var vm = new Vue({
                    el: '#app',
                    data: {
                        oldText: '父母套餐',
                        youngText: '配偶套餐',
                        showGoodsName: true,
                        showGoodsSubtitle: true,
                        showPrice: true,
                        commandStyle: {marginTop: '0.1rem'}
                    },
                    created: function(){
                        if(_activityCode == 'ACT096252673' || _activityCode == 'ACT651692318' || _activityCode == 'ACT056939532'){
                            this.youngText = '给自己';
                            this.showGoodsName = false;
                            this.showGoodsSubtitle = false;
                            this.showPrice = false;
                            this.commandStyle = {marginTop: '1rem'};
                        }
                        if(_activityCode == 'ACT096252673'){
                            this.oldText = '给母亲';
                        }
                        if(_activityCode == 'ACT651692318' || _activityCode == 'ACT056939532'){
                            this.oldText = '给父母';
                        }
                        if(_activityCode == 'ACT629107147'){
                            this.oldText = '给爸妈';
                            this.youngText = '给自己';
                        }
                    }
                });

            });
        },
        bindEvent: function () {
            var $comboOld = $('#comboOld'),
                $comboYoungster = $('#comboYoungster'),
                $comboPublic = $('#comboPublic'),
                $oldBtn = $('#oldBtn'),
                $youngBtn = $('#youngBtn'),
                $publicBtn = $('#publicBtn');

            var _self = this;
            //专车接送
            $('#special_car_banner').on('click',function(e){
                window.location.href = '/sz/cooperate/special_car?orderFrom=2'
            });

            $oldBtn.click(function () {
                $(this).addClass('item-on');
                $youngBtn.removeClass('item-on');
                $publicBtn.removeClass('item-on');

                $comboOld.removeClass('hidden');
                $comboYoungster.addClass('hidden');
                $comboPublic.addClass('hidden');
                shan.tools.statisticsPing("54030");
            });

            $youngBtn.click(function () {
                $(this).addClass('item-on');
                $oldBtn.removeClass('item-on');
                $publicBtn.removeClass('item-on');

                $comboYoungster.removeClass('hidden');
                $comboPublic.addClass('hidden');
                $comboOld.addClass('hidden');

                shan.tools.statisticsPing("112");
                $('.c_pointYoung').addClass('hidden');
            });

            $publicBtn.click(function () {
                $(this).addClass('item-on');
                $oldBtn.removeClass('item-on');
                $youngBtn.removeClass('item-on');

                $comboPublic.removeClass('hidden');
                $comboYoungster.addClass('hidden');
                $comboOld.addClass('hidden');

                shan.tools.statisticsPing("113");
                $('.c_pointPublic').addClass('hidden');
            });

            if(tag == 2 ){
                $youngBtn.click();
            }
            else if(tag == 3){
                $publicBtn.click();
            }

            //配置微信分享
            var controller = new wxController();
            controller.init(
                ['onMenuShareTimeline', 'onMenuShareAppMessage'],
                function () {
                    controller.configShareTimeline({
                        title: "限时购买优惠体检|定期检查，把健康带回家！", // 分享标题
                        link: window.location.href, // 分享链接
                        imgUrl: "https://"+window.location.host+"/static/images/redPacket/sharefree2.png", // 分享图标
                        success: function () {
                        },
                        cancel: function () {
                        }
                    });
                    controller.configShareAppMessage({
                        title: "限时购买优惠体检|定期检查，把健康带回家！", // 分享标题
                        desc:  "全国160个城市可用，覆盖450家专业机构，三甲医院。", // 分享描述
                        link: window.location.href, // 分享链接
                        imgUrl: "https://"+window.location.host+"/static/images/redPacket/sharefree2.png", // 分享图标
                        type: '', // 分享类型,music、video或link，不填默认为link
                        dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
                        success: function () {
                        },
                        cancel: function () {
                        }
                    });
                }
            );
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});

/**
 * Created by wangqiao on 2016/12/15.
 * 获取口令
 */
define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    require('lib/fastclick');


    var f = {
        init: function () {
        },
        bindEvent: function () {
            //点击兑换体检券按钮
            $('#get_btn').on('click', function (e) {
                shan.tools.statisticsPing("360007");
                window.location.href = 'http://'+window.location.host+'/sz/cooperate/modelexchange?activityCode=ACT747336450';
            });
        }
    };
    var run = function () {
        f.init();
        f.bindEvent();
    }
    //初始化函数
    exports.run = run;

});
define(function (require, exports, module) {
    var $ = require('jquery');
    require('lib/jquery.fullPage.min.js');
    require('lib/fastclick');

    var f = {
        init: function () {
            var _self = this;
            $(function () {
                FastClick.attach(document.body);
                $('#szWrapper').fullpage({
                    afterLoad: function (anchorLind, index) {
                    }
                });
            });
        },
        bindEvent: function () {
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});
define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    //var share = require('lib/shan_share');
    require('lib/mustache');
    //require('lib/share/wxshare');
    /*require('lib/rem');*/
    var _key = shan.tools.getUrlParam("key");
    require('lib/fastclick');

    //定义立即执行函数
    var JS = (function(){
        var $getBtn = $('#get-btn'),
            $hb_header = $('.J_hb_header'),
            $suc_header = $('.J_suc_header'),
            $suc_content = $('.J_suc_content'),
            $sz_hb_modal = $('.J_sz_hb_modal'),
            $hb_form = $('.J_hb_form'),
            $telInput = $('#telInput'),
            $getNowBtn = $('#get-now-btn'),
            $telError = $('.J_tel_error'),
            $useNow = $('#useNow'),
            $cardTips = $('#card-tips'),
            $ruleDialog = $('#ruleDialog'),
            $errorTips = $('.J_error_tips'),
            $errorTip = $('.J_error_tip'),
            $errorConfirm = $('.J_error_confirm');

        var repMobile = /^1\d{10}$/;//验证手机号码的正则表达式

        var topDistance = 0,
            isFirstSHowCards = false,
            isFirstShowCitys = false,
            isFirstSuccessCards = false;

        return {
            init: function () {
                this.clickEvents(); //绑定事件
                this.getCard(); //领取优惠券
                //this.weixinShare(); //微信分享
            },

            //绑定事件
            clickEvents: function () {
                var self = this;
                //埋点：页面展示
                shan.tools.statisticsPing("54115");

                //点击首页领取按钮
                $getBtn.on('click',function (e) {
                    //埋点：用户尝试输入手机号
                    shan.tools.statisticsPing("54117");
                    $sz_hb_modal.show().css('display','flex');
                    self.disableScroll();
                });
                //点击遮罩层
                $sz_hb_modal.on('click',function (e) {
                    $sz_hb_modal.hide();
                    self.ableScroll();
                });
                //点击表格，阻止冒泡
                $hb_form.on('click',function (e) {
                    e.stopPropagation();
                });
                //监控手机输入
                $telInput.on('keyup',function (e) {
                    var $telVal = $(this).val();
                    $telError.hide();
                    if( !repMobile.test($telVal)){
                        $getNowBtn.removeClass('bg-red');
                        return false;
                    }
                    $getNowBtn.addClass('bg-red');
                });
                //点击使用须知
                $cardTips.on('click',function (e) {
                    $ruleDialog.show().css('display','flex');
                    self.disableScroll();
                });
                //点击关闭按钮/知道了
                $('.J_close').on('click',function (e) {
                    $ruleDialog.hide();
                    self.ableScroll();
                });
                //点击错误信息的确定按钮
                $errorConfirm.on('click',function (e) {
                    $sz_hb_modal.hide();
                    self.ableScroll();
                });
                //滚动首页
                $("body").on("touchend", function(e){
                    topDistance = $(window).scrollTop();
                    //埋点：套餐详情展示
                    if( !isFirstSHowCards && topDistance > 270){
                        shan.tools.statisticsPing("54119");
                        isFirstSHowCards = true;
                    }
                    //埋点：支持城市展示
                    if( !isFirstShowCitys && topDistance > 700){
                        shan.tools.statisticsPing("54120");
                        isFirstSHowCards = true;
                    }
                });
                //点击立即使用
                $useNow.on('click',function (e) {
                    shan.tools.statisticsPing("54126");
                });
            },

            //领取优惠券
            getCard:function () {
                var self = this;
                //点击弹层的立即领取按钮
                $getNowBtn.on('click',function (e) {
                    //埋点：用户点击立即领取
                    shan.tools.statisticsPing("54118");

                    var $telVal = $telInput.val();
                    var _this = $(this);
                    if( !repMobile.test($telVal)){
                        $telError.show();
                        _this.removeClass('bg-red');
                        //埋点：输入了错误的手机号
                        shan.tools.statisticsPing("54121");
                        return false;
                    }
                    //请求后端接口...
                    shan.ajax({
                        url: '/sz/cooperate/gaincoupon',
                        data: {
                            sourceMemberCode: $('input[name="sourceMemberCode"]').val(),
                            phone: $telVal
                        },
                        success: function (json) {
                            if (json && json.SZ_HEAD && json.SZ_HEAD.RESP_CODE == "S0000" && json.SZ_BODY && json.SZ_BODY.GAIN_STATUS) {
                                var _gain_status = json.SZ_BODY.GAIN_STATUS;
                                if (_gain_status == 'GAIN_SUCC') { //获取券成功
                                    //渲染券列表
                                    var getListTpl = self.mustacheRender( json.SZ_BODY.COUPON_LIST_D );
                                    $('#getCardList').html(getListTpl);
                                    //填充手机号
                                    $('#userAccount').text($telVal);
                                    $hb_header.add($sz_hb_modal).hide();
                                    $suc_header.add($suc_content).show();
                                    self.ableScroll();
                                    shan.tools.statisticsPing("54124");//埋点：领取券成功页面展示
                                    $("body").on("touchend", function(e){
                                        topDistance = $(window).scrollTop();
                                        if( !isFirstSuccessCards && topDistance > 720){
                                            shan.tools.statisticsPing("54125");//埋点：套餐详情展示
                                            isFirstSuccessCards = true;
                                        }
                                    });
                                    //领取成功,8秒后自动跳转
                                    setTimeout(function(){
                                        window.location.href = $useNow.attr('href');
                                        shan.tools.statisticsPing("54127");//埋点：跳转
                                    },8000);

                                } else { //弹出其它信息
                                    if(_gain_status == 'HAS_UPPER_LIMIT'){
                                        shan.tools.statisticsPing("54122");//埋点：领券超过上限
                                    }
                                    $hb_form.hide();
                                    $errorTip.text(json.SZ_BODY.GAIN_MSG);
                                    $errorConfirm.attr('href','javascript:void(0);');
                                    $errorTips.show();
                                }
                            } else { //获取券信息失败，回到首页
                                shan.tools.statisticsPing("54123");//埋点：程序性错误
                                $hb_form.hide();
                                $errorTip.text(json.SZ_HEAD.RESP_MSG);
                                $errorConfirm.attr('href','/sz/activity/index');
                                $errorTips.show();
                            }
                        }
                    })
                });
            },

            ////微信分享
            //weixinShare:function () {
            //    var options = {
            //        key: _key,
            //        success: function (copy) {
            //            //shan.tools.statisticsPing("52001", {sourceCode: _key});
            //        }
            //    };
            //    //根据key获取分享的渠道文案
            //    share.getShareCopy(options.key, function (copy) {
            //
            //        /*if (copy.receivePath) {
            //            $hb_header.css("background-image","url(" + copy.receivePath + ")");
            //        }*/
            //        if (copy.activityUrl) {
            //            $useNow.attr('href', copy.activityUrl);
            //        }
            //        share.configWx(options, copy);
            //    });
            //},

            //模板渲染
            mustacheRender:function (list) {
                var ticketTpl = $('#ticket-template').html();
                Mustache.parse(ticketTpl);
                for (var i = list.length - 1; i >= 0; i--) {
                    if( list[i].benefitType == 'FILIAL'){
                        list[i].className = 'text-red';
                        list[i].bgColor = 'sz-bg-red';
                        list[i].couponIcon = "/static/images/redPacket/icon_gift.png";
                    } else if( list[i].benefitType == 'HEALTH'){
                        list[i].className = 'text-orange';
                        list[i].bgColor = 'sz-bg-orange';
                        list[i].couponIcon = "/static/images/redPacket/icon_health.png";
                    }
                }
                return Mustache.render(ticketTpl, {LIST: list});
            },

            //禁止滚动
            disableScroll:function () {
                $("html").add($('body')).css({"height":"100%","overflow":"hidden"});
            },
            //允许滚动
            ableScroll:function () {
                $("html").add($('body')).css({"height":"auto","overflow":"auto"});
            }
        }
    })();

    //调用立即执行函数
    $(function(){
        JS.init();
    });
});
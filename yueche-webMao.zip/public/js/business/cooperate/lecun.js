define(function (require, exports, module) {
    var $ = require('jquery');
    require('lib/fastclick');
    var shan = require('lib/shan_base');

    var f = {
        init : function(){
            FastClick.attach(document.body);
            shan.tools.statisticsPing("250198");
            $('#qr_code').on('click',function(e){
                shan.tools.statisticsPing("250199");
            });
        }
    };

    var run = function () {
        f.init();
    };

    //初始化函数
    exports.run = run;
});
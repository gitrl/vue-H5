define(function (require, exports, module) {
    var $ = require('jquery');
    require('lib/jquery.fullPage.min.js');
    require('lib/fastclick');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/share/wxshare');
    require('lib/vue/vue');
    var INDEX = 1;
    var input_ping=false;

    function share_wx(_id, _index) {
        $('#mask').removeClass('hidden');
        if (_id == 'shareBtn') {
            //shan.tools.statisticsPing('370008');
        }
        else if (_id == 'shareIcon') {
            shan.tools.statisticsPing('32107');
            //switch (_index) {
            //    case 1:
            //        //shan.tools.statisticsPing('370001');
            //        break;
            //    case 2:
            //        //shan.tools.statisticsPing('370002');
            //        break;
            //    case 3:
            //        //shan.tools.statisticsPing('370003');
            //        break;
            //    case 4:
            //        //shan.tools.statisticsPing('370004');
            //        break;
            //    case 5:
            //        //shan.tools.statisticsPing('370005');
            //        break;
            //    case 6:
            //        //shan.tools.statisticsPing('370006');
            //        break;
            //    case 7:
            //        //shan.tools.statisticsPing('370007');
            //        break;
            //    default:
            //        //shan.tools.statisticsPing('370001');
            //        break;
            //}
        }

    }

    var f = {
        init: function () {
            var _self = this;
            $(function () {
                shan.tools.statisticsPing('32102');
                FastClick.attach(document.body);
                try {
                    g_company = JSON.parse(g_company);
                    console.log(g_company);
                }
                catch (e) {
                    console.log(e)
                }
                //配置微信分享
                var controller = new wxController();
                controller.init(
                    ['onMenuShareTimeline', 'onMenuShareAppMessage'],
                    function () {
                        controller.configShareTimeline({
                            title: g_company.shareTitle, // 分享标题
                            link: window.location.origin + '/sz/cooperate/active_company_report/saleChannelCode/' + g_saleChannelCode + '/contactPhone/' + g_contactPhone, // 分享链接
                            imgUrl: g_company.logourl3,// 分享图标
                            success: function () {
                                shan.tools.statisticsPing('32109');
                            },
                            cancel: function () {
                            }
                        });
                        controller.configShareAppMessage({
                            title: g_company.shareTitle, // 分享标题
                            desc: g_company.shareContent, // 分享描述
                            link: window.location.origin + '/sz/cooperate/active_company_report/saleChannelCode/' + g_saleChannelCode + '/contactPhone/' + g_contactPhone, // 分享链接
                            imgUrl: g_company.logourl3,  // 分享图标
                            type: '', // 分享类型,music、video或link，不填默认为link
                            dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
                            success: function () {
                                shan.tools.statisticsPing('32108');
                            },
                            cancel: function () {
                            }
                        });
                    }
                );

                var loginDialog = new Vue({
                    el: "#szLoginDialog",
                    data: {
                        log1:g_company.logourl1,
                        log2:g_company.logourl2,
                        inputStatus: false, //手机输入框状态
                        isSending: false, //当前是否有ajax请求
                        phoneModel: "", //用户输入的手机号码
                        currentTimer: 60, //收到验证码后的等待时间
                        timerId: "", //监听等待时间的id
                        isLogining: false, //是否正在登录
                        //alertMsgText: "", //用户提示信息
                        //isShowAlert : false, //是否展示用户提示区域
                        codeModel: "" //验证码
                    },
                    methods: {
                        showAlert: function (msg) {
                            if (msg != "") {
                                pop.message.show(msg);
                            }
                        },
                        getVerifyCode: function () {
                            if (this.isSending) {
                                return;
                            }

                            var _result = this.checkPhone(this.phoneModel);

                            if (_result) {
                                this.showAlert("");
                                this.inputStatus = false;
                                this.sendVerifyCode(this.phoneModel);
                            }
                            else {
                                this.inputStatus = true;
                                this.showAlert('请输入正确的手机号');
                            }
                        },
                        checkPhone: function (phone) {

                            if (/^1\d{10}/.test(phone)) {
                                return true;
                            } else {
                                return false;
                            }
                        },
                        sendVerifyCode: function (phone) {
                            if (phone && !this.isSending) {
                                this.isSending = true;
                                //shan.tools.statisticsPing("370102");
                                shan.ajax({
                                    url: "/sz/index/smsverifyp",
                                    data: {
                                        phone: phone
                                    },
                                    success: function (json) {
                                        loginDialog.isSending = false;
                                        switch (json.SZ_HEAD.RESP_CODE) {
                                            case "S0000":
                                                loginDialog.resetCodeTimer();
                                                $(loginDialog.$el).find("#loginVerifyCodeInput").focus();
                                                pop.message.show('验证码已成功发送至您手机中');
                                                break;
                                            case "4":
                                                var $verifyPic = $(loginDialog.$el).find('#verifyPic');
                                                var img = new Image();
                                                img.src = "/verifypic.php?phone=" + phone + "&t=1" + "&_=" + new Date().getTime();
                                                $verifyPic.find('.img-code').html($(img));
                                                $verifyPic.show();

                                                $(loginDialog.$el).find("#loginGetVerifyCodeBtn").text('请输入图形码');
                                                loginDialog.isSending = true;
                                                $verifyPic.find('#loginImgVerifyInput').focus().off("input").on('input', function (e) {
                                                    if (this.value.length == 4) {
                                                        loginDialog.verifyPic(phone);
                                                    }
                                                });
                                                break;
                                            case "5":
                                                pop.alert('抱歉，请刷新页面后重新输入验证码', function(){
                                                    window.location.href = "/sz/user/index";
                                                });
                                                break;
                                            default:
                                                pop.message.show('发送失败请稍后再试');
                                                break;
                                        }

                                    }
                                });
                            }
                        },
                        resetCodeTimer: function () {

                            function refresh() {
                                loginDialog.currentTimer--;
                                if (loginDialog.currentTimer >= 0) {
                                    $(loginDialog.$el).find("#loginGetVerifyCodeBtn").text(loginDialog.currentTimer + 's 重新发送');
                                    loginDialog.isSending = true;
                                } else {
                                    $(loginDialog.$el).find("#loginGetVerifyCodeBtn").text('获取验证码');
                                    loginDialog.isSending = false;
                                    loginDialog.inputStatus = false;
                                    clearInterval(loginDialog.timerId);
                                }

                            }

                            loginDialog.timerId = setInterval(refresh, 1000);
                        },
                        checkVerifyCode: function (code) {

                            if (/\d{6}/.test(code)) {
                                return true;
                            } else {

                                return false;
                            }
                        },
                        login: function () {
                            shan.tools.statisticsPing('32104');
                            var _self = this;
                            if (this.isLogining) {
                                return;
                            }
                            var _result = "";

                            _result = this.checkPhone(this.phoneModel);
                            if (!_result) {
                                this.showAlert('请输入正确的手机号');
                                return;
                            }

                            _result = this.checkVerifyCode(this.codeModel);
                            if (!_result) {
                                this.showAlert('验证码不正确');
                                return;
                            }
                            ;

                            //pop.message.show("正在登录中...");
                            this.isLogining = true;
                            //shan.tools.statisticsPing("370103");

                            shan.ajax({
                                url: '/sz/biz/szlogin_async',
                                data: {
                                    phone: this.phoneModel,
                                    code: this.codeModel
                                },
                                success: function (json) {
                                    console.log(json);
                                    if (json && json.SZ_HEAD && json.SZ_HEAD.RESP_CODE) {
                                        if (json.SZ_HEAD.RESP_CODE == 'S0000') {
                                            //pop.message.show("登录成功");
                                            $(this.$el).find("#loginVerifyCodeInput").blur();
                                            //window.location.href = $("#afterLogin").val();
                                            shan.ajax({
                                                version: 'V2',
                                                data: {
                                                    url: '/share/queryReportInfo.htm',
                                                    contactPhone: _self.phoneModel
                                                },
                                                type: 'POST',
                                                success: function (_json) {
                                                    console.log(_json);
                                                    if (typeof _json != 'undefined' && _json.SZ_HEAD.RESP_CODE == 'S0000') {
                                                        if (_json.SZ_BODY.personalReportStatusBo.isRightChannel == '1' && _json.SZ_BODY.personalReportStatusBo.isHasReport == '1' && _json.SZ_BODY.personalReportStatusBo.saleChannelCode != '') {
                                                            window.location.href = '/sz/cooperate/active_company_report/saleChannelCode/' + _json.SZ_BODY.personalReportStatusBo.saleChannelCode + '/contactPhone/' + _self.phoneModel;
                                                        }
                                                        else {
                                                            if(_json.SZ_BODY.personalReportStatusBo.isRightChannel == '0'){
                                                                    $('#goUrl').attr('href',_json.SZ_BODY.personalReportStatusBo.wrongSaleChannelUrl);
                                                            }
                                                            else if(_json.SZ_BODY.personalReportStatusBo.isRightChannel == '1'&&_json.SZ_BODY.personalReportStatusBo.isHasReport=='0'){
                                                                $('#goUrl').attr('href',_json.SZ_BODY.personalReportStatusBo.noReportUrl);
                                                            }
                                                            shan.tools.statisticsPing('32105');
                                                            $('#mask2').removeClass('hidden');
                                                        }
                                                    }
                                                    else {
                                                        pop.message.show('系统繁忙，请稍后再试');
                                                    }
                                                }
                                            })
                                        } else {
                                            loginDialog.showAlert(json.SZ_HEAD.RESP_MSG);
                                        }
                                        loginDialog.isLogining = false;
                                    }
                                }
                            });

                        },
                        resetPic: function (phone) {
                            var $verifyPic = $(this.$el).find('#verifyPic'),
                                src = "/verifypic.php?phone=" + phone + "&t=1" + "&_=" + new Date().getTime();
                            $verifyPic.find('.img-code img').attr('src', src);
                        },
                        verifyPic: function (phone) {
                            var $input = $(this.$el).find('#loginImgVerifyInput'),
                                pic = $input.val();

                            shan.ajax({
                                url: "/verifypic.php",
                                data: {
                                    phone: phone,
                                    pic: pic,
                                    t: 2
                                },
                                success: function (rtn) {
                                    loginDialog.isSending = false;
                                    switch (rtn.err) {
                                        case 0:
                                            $input.blur();
                                            pop.message.show("正在发送验证码...");
                                            loginDialog.sendVerifyCode(phone);
                                            loginDialog.showAlert("");
                                            break;
                                        case 1:
                                            loginDialog.showAlert('抱歉，图形校验码输入错误');
                                            break;
                                        case 2:
                                            loginDialog.showAlert('抱歉，该手机号校验图形码过多，请等30分钟后重试');
                                            break;
                                    }
                                }
                            });
                        }
                    },
                    mounted: function () {
                        $('#szWrapper').fullpage({
                            afterLoad: function (anchorLind, index) {
                                //INDEX = index;
                                //if(INDEX==7){
                                //    shan.tools.statisticsPing('370010');
                                //}
                            }
                        });
                        $('#mask').click(function () {
                            $(this).addClass('hidden');
                        });
                        $('#shareIcon').click(function () {
                            share_wx('shareIcon', INDEX);
                        });
                        $('#loginPhoneInput').focus(function(){
                            if(!input_ping){
                                input_ping=true;
                                shan.tools.statisticsPing('32103');
                            }
                        });
                    }
                });

            });
        },
        bindEvent: function () {
            $('.noReport_close,.noReport_cancel').click(function(){
                $('#mask2').addClass('hidden');
            });
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});
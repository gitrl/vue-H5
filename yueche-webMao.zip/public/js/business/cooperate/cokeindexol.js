define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/fastclick');
    var cityinstit = require('lib/cityinstit');
    var COMBOINFO = require('data/comboinfo').data;
    var f = {
        imgComboAreaHeight: 0,
        onChoose: function (opt) {
            //自定义选中机构后的行为
            console.log(opt);
        },
        orderBooking: function (_str) {
            var _action = "/sz/order/confirm";
            _action += '?goodsCode=' + _str;
            _action += '&source=' + $('#source').val();
            $('#orderBooking').attr('action', _action).submit();
        },
        formatBottomInfo: function (goodsCode) {

            var _info = COMBOINFO[goodsCode];
            $('#pkgName').html(_info.name);
            $('#pkgSzPrice').html('善诊价：￥' + _info.szPrice);
            $('#pkgActivityPrice').html('口令价：￥' + _info.activityPrice);

        },
        isLocalStorageSupported:function(){
            var testKey = 'isPostback',
                storage = window.localStorage;
            try {
                storage.setItem(testKey, true);
                return true;
            } catch (error) {
                return false;
            }
        },
        init: function () {
            var _self = this;
            $(function () {
                FastClick.attach(document.body);
                cityinstit.linkCss();
                $('#goodsCode').val('GDS110010103');
                _self.imgComboAreaHeight = $('#imgComboArea').outerHeight(true);
                _self.isLocalStorageSupported();

            });
        },
        bindEvent: function () {
            var _self = this;
            $('.imgCombo li').click(function () {
                if (!$(this).children('.pkg-item').hasClass('item-on')) {
                    var _combo = $(this).attr('id').substring(3),
                        _id = 'combo' + _combo,
                        _tipsid = 'tips' + _combo;
                    $('.imgCombo li .pkg-item').removeClass('item-on');
                    $(this).children('.pkg-item').addClass('item-on');
                    $('#goodsCode').val($(this).data('code'));
                    $('#comboBox').children('div').addClass('hidden');
                    $('#' + _id).removeClass('hidden');
                    _self.formatBottomInfo($('#goodsCode').val());
                    $('#secondTop').find('.item').removeClass('item-on');
                    $('#' + _tipsid).addClass('item-on');
                    //埋点
                    switch (_combo) {
                        case 'Olzl':
                            shan.tools.statisticsPing("42001");
                            break;
                        case 'Olfk':
                            shan.tools.statisticsPing("42002");
                            break;
                        case 'Olbgz':
                            shan.tools.statisticsPing("42003");
                            break;
                        case 'Olgj':
                            shan.tools.statisticsPing("42004");
                            break;
                        case 'Olzxqm':
                            shan.tools.statisticsPing("42005");
                            break;
                        default :
                            break;
                    }
                    ;
                }
            });
            $('#secondTop li').click(function () {
                if (!$(this).hasClass('item-on')) {
                    var _combo = $(this).attr('id').substring(4),
                        _id = 'combo' + _combo,
                        _imgsid = 'img' + _combo;
                    $(this).addClass('item-on').siblings('li').removeClass('item-on');
                    $('#goodsCode').val($(this).data('code'));
                    $('#comboBox').children('div').addClass('hidden');
                    $('#' + _id).removeClass('hidden');
                    _self.formatBottomInfo($('#goodsCode').val());
                    $('#imgComboArea').find('.pkg-item').removeClass('item-on');
                    $('#' + _imgsid).children('.pkg-item').addClass('item-on');
                    $('#comboMain').stop(true).animate({
                        scrollTop: +_self.imgComboAreaHeight + 5,
                    }, 300);
                    //埋点
                    switch (_combo) {
                        case 'Olzl':
                            shan.tools.statisticsPing("42006");
                            break;
                        case 'Olfk':
                            shan.tools.statisticsPing("42007");
                            break;
                        case 'Olbgz':
                            shan.tools.statisticsPing("42008");
                            break;
                        case 'Olgj':
                            shan.tools.statisticsPing("42009");
                            break;
                        case 'Olzxqm':
                            shan.tools.statisticsPing("42010");
                            break;
                        default :
                            break;
                    }
                    ;

                }
            });
            $('[data-role="getCityInstit"]').click(function () {
                shan.tools.statisticsPing("40001");
                cityinstit.run({goodsCode: $('#goodsCode').val(), onChoose: _self.onChoose});
            });
            $('#btnBooking').click(function () {
                _self.orderBooking($('#goodsCode').val());
            });
            $('#comboMain').scroll(function () {
                if ($('#comboMain').scrollTop() >= _self.imgComboAreaHeight) {
                    $('#firstTop').fadeOut();
                    $('#secondTop').fadeIn();
                }
                else {
                    $('#firstTop').fadeIn();
                    $('#secondTop').fadeOut();
                }
            });
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});


define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop =require('lib/dialog');
    require('lib/fastclick');
    require('lib/share/wxshare');


    var orderCode = shan.tools.getUrlParam("orderCode");
    var phase = shan.tools.getUrlParam("phase");
    var orderFrom = shan.tools.getUrlParam("orderFrom");

    var $customized_btn = $('#customized_btn '),
        $customized_input = $('#customized_input'),
        $message = $('#message'),
        $check_btn = $('#check_btn'),
    /*$give_up_btn = $('#give_up_btn'),*/
        $share_mask = $('#share_mask');

    var commandReg = /^[\u4E00-\u9FA5]{6,12}$/;
    var isWeixin = shan.tools.isWeixin();

    var phaseState = '';
    var key = '';
    var options = {
        key: key,
        orderFrom: orderFrom,
        success: function(){
            if(parseInt(this.orderFrom) == 1){//主站
                window.location.href = '/sz/index/index';
            }else if(parseInt(this.orderFrom) == 2){//活动框架
                $('#share_mask').addClass('hidden');
                $('#mask,.check-dialog').removeClass('hidden');
            }
        }
    };
    function configShare(options){
        var controller = new wxController();
        controller.init(
            ['onMenuShareTimeline','onMenuShareAppMessage'],
            function () {
                controller.configShareTimeline({
                    title: "送你一张定制体检券，可以免费体检1次，全国通用", // 分享标题
                    desc: "体检券价值300元，输入我的专属口令即可兑换，手慢无",
                    link: "http://"+window.location.host+"/sz/cooperate/getcommand?key="+ options.key, // 分享链接
                    imgUrl: "http://m.shanzhen.me/static/images/cooperate/command/command_share.png", // 分享图标
                    success: function () {
                        options.success();
                        shan.tools.statisticsPing("360005");
                    },
                    cancel: function () {
                        // 用户取消分享后执行的回调函数
                        //shan.tools.statisticsPing("54109",{sourceCode:g_activityCode || ""});
                    }
                });
                controller.configShareAppMessage({
                    title: "送你一张定制体检券，可以免费体检1次，全国通用", // 分享标题
                    desc: "体检券价值300元，输入我的专属口令即可兑换，手慢无", // 分享描述
                    link: "http://"+window.location.host+"/sz/cooperate/getcommand?key="+ options.key, // 分享链接
                    imgUrl: "http://m.shanzhen.me/static/images/cooperate/command/command_share.png", // 分享图标
                    type: '', // 分享类型,music、video或link，不填默认为link
                    dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
                    success: function () {
                        // 用户确认分享后执行的回调函数
                        options.success();
                        shan.tools.statisticsPing("360005");
                    },
                    cancel: function () {
                        // 用户取消分享后执行的回调函数

                    }
                });
            });
    }

    var f ={
        init: function(){
            $(function () {
                FastClick.attach(document.body);
            });
            shan.tools.statisticsPing("360000");
            if(isWeixin != 1){
                $check_btn.text('查看兑换方法');
            }

            /*if(phase == 1 && isWeixin == 1 && orderCode != 552806423041){
             $give_up_btn.removeClass('hidden');
             }*/
            if(phase == 1){
                phase = 'PLACE_PHASE';
                phaseState = '下单完成时';
            }else if(phase == 2){
                phase = 'RESERVE_PHASE';
                phaseState = '预约完成时';
            }
        },

        bindEvent: function(){
            //输入框获取光标时
            $customized_input.on('focus',function(e){
                if(!$message.hasClass('error-message')){
                    return;
                }
                $message.removeClass('error-message').text('请输入6~12个汉字');
            });

            //点击弹窗关闭按钮
            $('.J_close').on('click',function(e){
                $('#mask,#change_dialog,.check-dialog').addClass('hidden');
            });

            //点击放弃生成
            /*$give_up_btn.on('click',function(e){
             window.location.href = '/sz/order/appointment?orderCode='+ orderCode;
             });*/

            //点击查看兑换方法按钮/分享按钮
            $check_btn.on('click',function(e){
                if(isWeixin == 1){
                    $share_mask.removeClass('hidden');
                    shan.tools.statisticsPing("360003");
                    return;
                }
                $('#mask,#change_dialog').removeClass('hidden');
                shan.tools.statisticsPing("360004");
            });


            //点击蒙版
            $share_mask.on('click',function(e){
                $(this).addClass('hidden');
            });
        },

        createCommand: function(){
            //点击生成口令按钮
            $customized_btn.on('click',function(e){
                var $customized_input_value = $customized_input.val().trim();
                shan.tools.statisticsPing("360001");
                if($customized_input_value.length < 6 || $customized_input_value.length > 12){
                    shan.tools.statisticsPing("360012");
                    $message.addClass('error-message').text('口令字数不符，请重新输入');
                    return;
                }
                if(!commandReg.test($customized_input_value)){
                    $message.addClass('error-message').text('仅支持汉字，不能包含其他字符');
                    shan.tools.statisticsPing("360011");
                    return;
                }
                //请求后端接口...
                shan.ajax({
                    url: '/sz/cooperate/createcommand',
                    data:{
                        orderCode: orderCode,
                        activityKeyWord: $customized_input_value,
                        phase: phase
                    },
                    success: function(json){
                        if(typeof json != 'undefined' && json.SZ_HEAD.RESP_CODE == 'S0000'){
                            $('#command_words').text($customized_input_value);
                            $('#dead_date').text(json.SZ_BODY.EXPIRE_DATE);
                            $('#customized_content').addClass('hidden');
                            $('#finish_content').removeClass('hidden');
                            options.key = json.SZ_BODY.key;
                            configShare(options);
                            shan.tools.statisticsPing("360002");
                        }else if(json.SZ_HEAD.RESP_CODE == 'O9001'){
                            $message.addClass('error-message').text('您在'+ phaseState +'已经生成过口令');
                            shan.tools.statisticsPing("360015");
                        }else if(json.SZ_HEAD.RESP_CODE == 'O9003'){
                            $message.addClass('error-message').text('该口令已被用过，请重新设置个性化口令');
                            shan.tools.statisticsPing("360014");
                        }else if(json.SZ_HEAD.RESP_CODE == 'O9008'){
                            $message.addClass('error-message').text('抱歉，渠道定制口令数已达上限');
                            shan.tools.statisticsPing("360016");
                        }else{
                            //$message.addClass('error-message').text(json.SZ_HEAD.RESP_MSG);
                            pop.alert('系统异常');
                        }
                    }
                });

            });
        }


    };
    var run = function () {
        f.init();
        f.bindEvent();
        f.createCommand();
    };

    //初始化函数
    exports.run = run;
});
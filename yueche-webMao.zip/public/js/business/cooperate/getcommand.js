/**
 * Created by wangqiao on 2016/12/15.
 * 获取口令
 */
define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop =require('lib/dialog');
    require('lib/fastclick');

    var key = shan.tools.getUrlParam('key');
    var isWeixin = shan.tools.isWeixin();

    var JS = (function () {
        return {
            init: function () {
                this.inits(); //初始化
                this.bindEvents(); //绑定事件
            },
            //初始化
            inits: function () {
                var _self = this;
                $(function () {
                    FastClick.attach(document.body);
                });
                shan.tools.statisticsPing("360006");
                shan.ajax({
                    url: '/sz/cooperate/getcommanddetail',
                    data: {
                        key: key
                    },
                    success: function(json){
                        if(typeof json != 'undefined' && json.SZ_HEAD.RESP_CODE == 'S0000'){
                            //1.替换头像
                            //2.填充昵称/手机号
                            //3.获取口令
                            //4.过期时间
                            var serviceObject = json.SZ_BODY.CUSTOM_KEY_WORD;
                            $('#command_words').text(serviceObject.keyWord);
                            $('#dead_date').text(serviceObject.keyWordExpireDate);
                            if(isWeixin == 1 && serviceObject.nickName != undefined){
                                $('#nickname').text(serviceObject.nickName);
                                $('#head_img').attr('src',serviceObject.headImgUrl);
                            }else{
                                $('#nickname').text(_self.replacePhone(serviceObject.phone));
                            }
                        }else{
                            pop.alert('系统异常');
                        }
                    }
                });
            },

            //绑定事件
            bindEvents: function () {
                //点击兑换体检券按钮
                $('#get_btn').on('click',function(e){
                    shan.tools.statisticsPing("360007");
                    window.location.href = '/sz/cooperate/modelexchange?activityCode=ACT747336450';
                });
            },

            replacePhone:function(phone){
                return phone.slice(0,4) + 'xxxx' + phone.slice(-2);
            }
        }
    })();

    $(function () {
        JS.init();
    });


});
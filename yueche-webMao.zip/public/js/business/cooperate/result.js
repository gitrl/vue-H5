define(function (require, exports, module) {
//    var $ = require('jquery');
    var shan = require('lib/shan_base');
    require('lib/vue/vue.min');
//    require('lib/share/wxshare');
//    require('lib/mustache');
//    var pop = require('lib/dialog');
//    var share = require('lib/shan_share');
    var _status = shan.tools.getUrlParam("status");
    var orderCode = shan.tools.getUrlParam("orderCode");
//    var _viewQrCodeLayer = false;

    var f = {
        init : function(){
            
            //页面展示埋点
            shan.tools.statisticsPing("54100");
            new Vue({
                el: '#content',
                data: {
                    status: 1,
                    inWechat: false,
                    outWechat: false,
                    ifCommand: false,
                    checked: false,
                    tob_checked: false,
                    orderFrom: 0,
                    noCommandObject: {
                        'check-order-btn': false,
                        'no-command-btn': false
                    }
                },
                methods: {
                    //跳转到定制口令
                    toCommand: function(){
                        window.location.href = "/sz/cooperate/command?orderCode=" + orderCode + "&phase=1" + "&orderFrom=2";
                        shan.tools.statisticsPing("54101",{sourceCode:g_activityCode});
                    },
                    //查看预约方法
                    checkOrder: function(){
                        if(this.orderFrom == 3){
                            this.tob_checked = true;
                            return;
                        }
                        this.checked = true;
                    },
                    closeDialog: function(){
                        this.checked = false;
                        this.tob_checked = false;
                    }
                },
                created: function(){
                    
                    this.ifCommand = g_ifCommand || false;
                    this.noCommandObject= {'check-order-btn': this.ifCommand, 'no-command-btn': !this.ifCommand};
                    if(_status == 1 || _status == 3){
                        if(shan.tools.isWeixin() == 1){
                            this.inWechat = true;
                        }else{
                            this.outWechat = true;
                        }
                    }
                    this.status = _status;
                    this.orderFrom = g_orderFrom || 0;
                }
            });


        },
        bindEvent: function() {
            /*if(_status == 1){ //支付成功
                if(shan.tools.isWeixin() == 1){
                    shan.tools.statisticsPing("54011", {sourceCode:g_activityCode || ""});
                }*/

                // share.wxShare({
                //     key: g_key,
                //     success: function (copy) {
                //         share.shareSuccessCallback({
                //             key : g_key,
                //             channelCode : g_channelCode,
                //             activityCode : g_activityCode,
                //             GAIN_SUCC : function (list) {
                //                 share.inviteSuccessDialog.ele.find('.btn-list a:first-child').attr('href', copy.activityUrl);
                //                 share.inviteSuccessDialog.show(list);
                //             }
                //         });
                //         share.shareTipsLayer.hide();
                //         // 54013	活动框架—下单成功—分享成功回调
                //         shan.tools.statisticsPing("54013",{sourceCode:g_key});
                //     }
                // });

                /*$('#openShareDialog').bind('click', function (e) {
                    //share.shareTipsLayer.show();
                    //54012	活动框架—下单成功—点击立即分享
                    shan.tools.statisticsPing(54012);
                    shan.tools.statisticsPing("54101",{sourceCode:g_activityCode});
                    window.location.href = "/sz/cooperate/command?orderCode=" + orderCode + "&phase=1";
                    e.preventDefault();
                });*/

                /*$('#toReserve').on('click', function () {
                    //54014	活动框架—下单成功—点击预约
                    shan.ajax({
                        data : {
                            url : "/order/detail.htm",
                            orderCode : orderCode
                        },
                        success : function(_json){
                            if(_json.SZ_HEAD.RESP_CODE == 'S0000'){

                                if(_json.SZ_BODY.GOODS_D.goodsCode == "GDS110010001") //免费用户
                                {
                                    if(g_showType && g_showType == "2"){
                                        $("#c_shareApp").show();
                                    }
                                    else{
                                        $("#c_shareErwei").show();
                                    }

                                }
                                else{
                                    if(shan.tools.isWeixin() == 0){
                                        $("#c_erweiDesc").text("请在微信中关注“善诊”进行预约");
                                    }
                                    $("#c_shareErwei").show();

                                }

                                $("body").click(function(){
                                    shan.tools.statisticsPing("54103",{sourceCode:g_activityCode});
                                });
                            }

                        }
                    });

                    shan.tools.statisticsPing(54014);
                });*/

                /*$(".c_close").click(function(e){
                    $("#c_shareApp").hide();
                    $("#c_shareErwei").hide();
                    shan.tools.statisticsPing("54104",{sourceCode:g_activityCode});
                    $("body").unbind("click");
                    e.preventDefault();
                });*/

           /* }*/
        }
    };

    var run = function () {
        f.init();
        //f.bindEvent();
    };

    //初始化函数
    exports.run = run;
});
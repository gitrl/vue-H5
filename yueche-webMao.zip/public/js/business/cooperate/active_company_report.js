define(function (require, exports, module) {
    var $ = require('jquery');
    require('lib/jquery.fullPage.min.js');
    require('lib/fastclick');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/share/wxshare');
    require('lib/vue/vue');
    var INDEX = 1;

    function share_wx(_id, _index) {
        $('#mask').removeClass('hidden');
        if (_id == 'shareBtn') {
            //shan.tools.statisticsPing('370008');
        }
        else if (_id == 'shareIcon') {
            shan.tools.statisticsPing('32107');
            //switch (_index) {
            //    case 1:
            //        //shan.tools.statisticsPing('370001');
            //        break;
            //    case 2:
            //        //shan.tools.statisticsPing('370002');
            //        break;
            //    case 3:
            //        //shan.tools.statisticsPing('370003');
            //        break;
            //    case 4:
            //        //shan.tools.statisticsPing('370004');
            //        break;
            //    case 5:
            //        //shan.tools.statisticsPing('370005');
            //        break;
            //    case 6:
            //        //shan.tools.statisticsPing('370006');
            //        break;
            //    case 7:
            //        //shan.tools.statisticsPing('370007');
            //        break;
            //    default:
            //        //shan.tools.statisticsPing('370001');
            //        break;
            //}
        }

    }

    function gcd(m, n) {//辗转相除法 求最大公约数
        var u = +m, v = +n, t = v;
        while (v != 0) {
            t = u % v;
            u = v;
            v = t;
        }
        return u
    }

    var f = {
        init: function () {
            var _self = this;
            $(function () {
                shan.tools.statisticsPing('32100');
                FastClick.attach(document.body);
                try {
                    g_company = JSON.parse(g_company);
                    g_person = JSON.parse(g_person);
                    console.log(g_company);
                    console.log(g_person);
                }
                catch (e) {
                    console.log(e)
                }

                //配置微信分享
                var controller = new wxController();
                controller.init(
                    ['onMenuShareTimeline', 'onMenuShareAppMessage'],
                    function () {
                        controller.configShareTimeline({
                            title: g_company.shareTitle, // 分享标题
                            link: window.location.href, // 分享链接
                            imgUrl: g_company.logourl3, // 分享图标
                            success: function () {
                                //shan.tools.statisticsPing('370012');
                            },
                            cancel: function () {
                            }
                        });
                        controller.configShareAppMessage({
                            title: g_company.shareTitle, // 分享标题
                            desc: g_company.shareContent, // 分享描述
                            link: window.location.href, // 分享链接
                            imgUrl: g_company.logourl3, // 分享图标
                            type: '', // 分享类型,music、video或link，不填默认为link
                            dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
                            success: function () {
                                //shan.tools.statisticsPing('370011');
                            },
                            cancel: function () {
                            }
                        });
                    }
                );


                var vm = new Vue({
                    el: '#vue',
                    data: {
                        log1:g_company.logourl1,
                        log2:g_company.logourl2,
                        loginUrl:'/sz/cooperate/active_company_login/saleChannelCode/'+g_saleChannelCode+'/contactPhone/'+g_contactPhone,
                        cityNum: g_company.institCityNum,//城市数量
                        peoplesNum: g_company.examineeReportNum,//体检人数
                        maleNum: g_company.maleNum,//男生数量
                        femaleNum: g_company.femaleNum,//女生数量
                        companyName: g_company.companyName,//公司名字
                        FBMI: [g_company.lowBmiFemaleNum, g_company.midBmiFemaleNum, g_company.highBmiMaleNum],//女性BMI数据
                        MBMI: [g_company.lowBmiMaleNum, g_company.midBmiMaleNum, g_company.highBmiFemaleNum],//男性BMI数据
                        abnormalRatio: (parseInt(g_company.exceptionNum) / parseInt(g_company.itemNum)).toFixed(2),//全公司异常项占比
                        isShowPerson: false,//是否展示个人信息
                        isShowPersonBMI: true,
                        isShowPersonEye: true,
                        isShowPersonBlood: true,
                        personHeight: 0,//单位cm
                        personWeight: 0,//单位公斤
                        personSex: 'male',//male,female
                        //personEye: 'normal',//high,low,normal
                        EyeStatus: 0,
                        personSystolicPressure: 0,//收缩压
                        personDiastolicPressure: 0,//舒张压
                        personGlucose: 0,//血糖
                        personTC: 0,//总胆固醇
                        personTG: 0,//甘油三酯
                        personHDL: 0,//高密度脂蛋白
                        personLDL: 0,//低密度脂蛋白

                        BMILib: [185, 239],
                        HeightLib: [165, 175],
                        WeightLib: [54, 67],
                        BMIWordsStatusLib: ['过轻', '正常', '超重'],
                        BMIMaleWordsLib: ['太瘦啦，要多吃肉！', '帅哥，保持的不错嘛！', '妈妈说要多运动~'],
                        BMIMaleImgLib: {
                            m_low_thin: '/static/images/biz/h5_v2/m_low_thin.png',
                            m_low_normal: '/static/images/biz/h5_v2/m_low_normal.png',
                            m_low_fat: '/static/images/biz/h5_v2/m_low_fat.png',
                            m_middle_thin: '/static/images/biz/h5_v2/m_middle_thin.png',
                            m_middle_normal: '/static/images/biz/h5_v2/m_middle_normal.png',
                            m_middle_fat: '/static/images/biz/h5_v2/m_middle_fat.png',
                            m_high_thin: '/static/images/biz/h5_v2/m_high_thin.png',
                            m_high_normal: '/static/images/biz/h5_v2/m_high_normal.png',
                            m_high_fat: '/static/images/biz/h5_v2/m_high_fat.png'
                        },
                        BMIFemaleWordsLib: ['苗条虽好，可不要太瘦了哦~', '健康自信的姑娘最美！', '是时候迈开腿，管住嘴啦~'],
                        BMIFemaleImgLib: {
                            f_low_thin: '/static/images/biz/h5_v2/f_low_thin.png',
                            f_low_normal: '/static/images/biz/h5_v2/f_low_normal.png',
                            f_low_fat: '/static/images/biz/h5_v2/f_low_fat.png',
                            f_middle_thin: '/static/images/biz/h5_v2/f_middle_thin.png',
                            f_middle_normal: '/static/images/biz/h5_v2/f_middle_normal.png',
                            f_middle_fat: '/static/images/biz/h5_v2/f_middle_fat.png',
                            f_high_thin: '/static/images/biz/h5_v2/f_high_thin.png',
                            f_high_normal: '/static/images/biz/h5_v2/f_high_normal.png',
                            f_high_fat: '/static/images/biz/h5_v2/f_high_fat.png'
                        },
                        EyeWordsStatusLib: ['正常', '轻度', '重度'],
                        EyeWordsLib: ['看我火眼金睛', '戴上眼镜世界更清晰', '该给你的心灵窗户换块玻璃啦~'],
                        bodyStatusLib: ['偏低', '正常', '偏高'],
                        pressureImgLib: {
                            low: '/static/images/biz/h5_v2/pressure_low.png',
                            normal: '/static/images/biz/h5_v2/pressure_normal.png',
                            high: '/static/images/biz/h5_v2/pressure_high.png'
                        },
                        pressureWordsLib: {
                            low: '血压低 要多锻炼哦~',
                            normal: '年轻就是好 血压没烦恼！',
                            high: '保持微笑是最好的降压药~'
                        },
                        glucoseImgLib: {
                            low: '/static/images/biz/h5_v2/glucose_low.png',
                            normal: '/static/images/biz/h5_v2/glucose_normal.png',
                            high: '/static/images/biz/h5_v2/glucose_high.png'
                        },
                        glucoseWordsLib: {
                            low: '血糖低 请用力给我撒糖！',
                            normal: '血糖正常 吃嘛嘛香~',
                            high: '每天的我都是甜甜的~'
                        },
                        bloodFatWordsLib: {
                            low: '我是难得一见的低血脂！',
                            normal: '血脂正常哦 血管清爽不油腻~',
                            high: '血脂有点高 多吃蔬菜多运动~'
                        },
                        bloodFatImgLib: {
                            low: '/static/images/biz/h5_v2/fat_low.png',
                            normal: '/static/images/biz/h5_v2/fat_normal.png',
                            high: '/static/images/biz/h5_v2/fat_high.png'
                        }
                    },
                    methods: {},
                    computed: {
                        personBloodFatWords: function () {
                            if (this.personTG >= 5.65 || this.personTC >= 5.2 || this.personLDL >= 4.14 || this.personHDL >= 2) {
                                return this.bloodFatWordsLib.high;
                            }
                            else if (this.personTC > 3 && this.personTC < 5.2 && this.personTG > 2.83 && this.personTG < 5.65 && this.personHDL > 0.7 && this.personHDL < 2 && this.personLDL < 4.14) {
                                return this.bloodFatWordsLib.normal;
                            }
                            else {
                                return this.bloodFatWordsLib.low;
                            }
                        },
                        personBloodFatTCImg: function () {
                            var _tmp;
                            if (this.personTC >= 5.2) {
                                _tmp = this.bloodFatImgLib.high;
                            }
                            else if (this.personTC > 3 && this.personTC < 5.2) {
                                _tmp = this.bloodFatImgLib.normal;
                            }
                            else {
                                _tmp = this.bloodFatImgLib.low;
                            }
                            return _tmp;
                        },
                        personBloodFatTGImg: function () {
                            var _tmp;
                            if (this.personTG >= 5.65) {
                                _tmp = this.bloodFatImgLib.high;
                            }
                            else if (this.personTG > 2.83 && this.personTG < 5.65) {
                                _tmp = this.bloodFatImgLib.normal;
                            }
                            else {
                                _tmp = this.bloodFatImgLib.low;
                            }
                            return _tmp;
                        },
                        personBloodFatHDLImg: function () {
                            var _tmp;
                            if (this.personHDL >= 2) {
                                _tmp = this.bloodFatImgLib.high;
                            }
                            else if (this.personHDL > 0.7 && this.personHDL < 2) {
                                _tmp = this.bloodFatImgLib.normal;
                            }
                            else {
                                _tmp = this.bloodFatImgLib.low;
                            }
                            return _tmp;
                        },
                        personBloodFatLDLImg: function () {
                            var _tmp;
                            if (this.personLDL >= 4.14) {
                                _tmp = this.bloodFatImgLib.high;
                            }
                            else {
                                _tmp = this.bloodFatImgLib.normal;
                            }
                            return _tmp;
                        },
                        personPressureWords: function () {
                            if (this.personSystolicPressure >= 140 && this.personDiastolicPressure >= 90) {
                                return this.pressureWordsLib.high;
                            }
                            else if (this.personSystolicPressure < 140 && this.personSystolicPressure > 90 && this.personDiastolicPressure > 60) {
                                return this.pressureWordsLib.normal;
                            }
                            else if (this.personSystolicPressure <= 90 || this.personDiastolicPressure <= 60) {
                                return this.pressureWordsLib.low;
                            }
                            else {
                                return this.pressureWordsLib.normal;
                            }
                        },
                        personPressureImg: function () {
                            if (this.personSystolicPressure >= 140 && this.personDiastolicPressure >= 90) {
                                return this.pressureImgLib.high;
                            }
                            else if (this.personSystolicPressure < 140 && this.personSystolicPressure > 90 && this.personDiastolicPressure > 60) {
                                return this.pressureImgLib.normal;
                            }
                            else if (this.personSystolicPressure <= 90 || this.personDiastolicPressure <= 60) {
                                return this.pressureImgLib.low;
                            }
                            else {
                                return this.pressureImgLib.normal;
                            }
                        },
                        personGlucoseWords: function () {
                            if (this.personGlucose >= 6.9) {
                                return this.glucoseWordsLib.high;
                            }
                            else if (this.personGlucose > 3.9 && this.personGlucose < 6.9) {
                                return this.glucoseWordsLib.normal;
                            }
                            else {
                                return this.glucoseWordsLib.low;
                            }
                        },
                        personGlucoseImg: function () {
                            if (this.personGlucose >= 6.9) {
                                return this.glucoseImgLib.high;
                            }
                            else if (this.personGlucose > 3.9 && this.personGlucose < 6.9) {
                                return this.glucoseImgLib.normal;
                            }
                            else {
                                return this.glucoseImgLib.low;
                            }
                        },
                        personEyeStatusWords: function () {
                            return this.EyeWordsStatusLib[this.EyeStatus];
                        },
                        personEyeWords: function () {
                            return this.EyeWordsLib[this.EyeStatus];
                        },
                        personBMI: function () {
                            return ((this.personWeight * 10000) / (this.personHeight * this.personHeight)).toFixed(1);
                        },
                        personEye: function () {
                            var _tmp;
                            if (this.personSex == 'male') {
                                switch (this.EyeStatus) {
                                    case 0:
                                        _tmp = '/static/images/biz/h5_v2/m_eye_normal.png';
                                        break;
                                    case 1:
                                        _tmp = '/static/images/biz/h5_v2/m_eye_little.png';
                                        break;
                                    case 2:
                                        _tmp = '/static/images/biz/h5_v2/m_eye_much.png';
                                        break;
                                    default:
                                        _tmp = '/static/images/biz/h5_v2/m_eye_normal.png';
                                        break;

                                }
                            }
                            else {
                                switch (this.EyeStatus) {
                                    case 0:
                                        _tmp = '/static/images/biz/h5_v2/f_eye_normal.png';
                                        break;
                                    case 1:
                                        _tmp = '/static/images/biz/h5_v2/f_eye_little.png';
                                        break;
                                    case 2:
                                        _tmp = '/static/images/biz/h5_v2/f_eye_much.png';
                                        break;
                                    default:
                                        _tmp = '/static/images/biz/h5_v2/f_eye_normal.png';
                                        break;

                                }
                            }
                            return _tmp;
                        },
                        maleRatio: function () {
                            var tmp, tmpMale, tmpFemale, tmpGcd;
                            if (this.maleNum < 10 && this.femaleNum < 10) {
                                tmpFemale = this.femaleNum;
                                tmpMale = this.maleNum;
                            }
                            else {
                                if (this.maleNum < this.femaleNum) {
                                    tmp = (parseInt(this.maleNum) / parseInt(this.femaleNum)).toFixed(1);
                                    tmpMale = tmp * 10;
                                    tmpFemale = 10;
                                }
                                else {
                                    tmp = (parseInt(this.femaleNum) / parseInt(this.maleNum)).toFixed(1);
                                    tmpFemale = tmp * 10;
                                    tmpMale = 10;
                                }
                            }
                            tmpGcd = gcd(tmpMale, tmpFemale);
                            tmpMale = tmpMale / tmpGcd;
                            return tmpMale;
                        },
                        femaleRatio: function () {
                            var tmp, tmpMale, tmpFemale, tmpGcd;
                            if (this.maleNum < 10 && this.femaleNum < 10) {
                                tmpFemale = this.femaleNum;
                                tmpMale = this.maleNum;
                            }
                            else {
                                if (this.maleNum < this.femaleNum) {
                                    tmp = (parseInt(this.maleNum) / parseInt(this.femaleNum)).toFixed(1);
                                    tmpMale = tmp * 10;
                                    tmpFemale = 10;
                                }
                                else {
                                    tmp = (parseInt(this.femaleNum) / parseInt(this.maleNum)).toFixed(1);
                                    tmpFemale = tmp * 10;
                                    tmpMale = 10;
                                }
                            }
                            tmpGcd = gcd(tmpMale, tmpFemale);
                            tmpFemale = tmpFemale / tmpGcd;
                            return tmpFemale;
                        },
                        isFemaleMore: function () {
                            return this.maleRatio < this.femaleRatio ? true : false;
                        },
                        isMaleMore: function () {
                            return this.maleRatio > this.femaleRatio ? true : false;
                        },
                        ratioWords: function () {
                            if (this.maleRatio < this.femaleRatio) {
                                return '美女多于帅哥';
                            }
                            else if (this.maleRatio > this.femaleRatio) {
                                return '帅哥多于美女';
                            }
                            else {
                                return '男女搭配干活不累';
                            }
                        },
                        femaleBMILowRatio: function () {
                            var num = parseInt(this.FBMI[0]),
                                base = 0, i;
                            for (i = 0; i < this.FBMI.length; i++) {
                                base += parseInt(this.FBMI[i]);
                            }
                            return (num / base * 100).toFixed(1) + '%';
                        },
                        femaleBMIMiddleRatio: function () {
                            var num = parseInt(this.FBMI[1]),
                                base = 0, i;
                            for (i = 0; i < this.FBMI.length; i++) {
                                base += parseInt(this.FBMI[i]);
                            }
                            return (num / base * 100).toFixed(1) + '%';
                        },
                        femaleBMIHighRatio: function () {
                            var num = parseInt(this.FBMI[2]),
                                base = 0, i;
                            for (i = 0; i < this.FBMI.length; i++) {
                                base += parseInt(this.FBMI[i]);
                            }
                            return (num / base * 100).toFixed(1) + '%';
                        },
                        femaleBMIGoodRatio: function () {
                            var num = parseInt(this.FBMI[0]) + parseInt(this.FBMI[1]),
                                base = 0, i;
                            for (i = 0; i < this.FBMI.length; i++) {
                                base += parseInt(this.FBMI[i]);
                            }
                            return (num / base * 100).toFixed(1) + '%';
                        },
                        maleBMILowRatio: function () {
                            var num = parseInt(this.MBMI[0]),
                                base = 0, i;
                            for (i = 0; i < this.MBMI.length; i++) {
                                base += parseInt(this.MBMI[i]);
                            }
                            return (num / base * 100).toFixed(1) + '%';
                        },
                        maleBMIMiddleRatio: function () {
                            var num = parseInt(this.MBMI[1]),
                                base = 0, i;
                            for (i = 0; i < this.MBMI.length; i++) {
                                base += parseInt(this.MBMI[i]);
                            }
                            return (num / base * 100).toFixed(1) + '%';
                        },
                        maleBMIHighRatio: function () {
                            var num = parseInt(this.MBMI[2]),
                                base = 0, i;
                            for (i = 0; i < this.MBMI.length; i++) {
                                base += parseInt(this.MBMI[i]);
                            }
                            return (num / base * 100).toFixed(1) + '%';
                        },
                        maleBMIGoodRatio: function () {
                            var num = parseInt(this.MBMI[0]) + parseInt(this.MBMI[1]),
                                base = 0, i;
                            for (i = 0; i < this.MBMI.length; i++) {
                                base += parseInt(this.MBMI[i]);
                            }
                            return (num / base * 100).toFixed(1) + '%';
                        },
                        personImg: function () {
                            var _imgSrc = '';
                            if (this.personSex == 'male') {
                                if (parseFloat(this.personHeight) < parseFloat(this.BMILib[0])) {
                                    if (parseFloat(this.personWeight) < parseFloat(this.WeightLib[0])) {
                                        _imgSrc = this.BMIMaleImgLib.m_low_thin;
                                    }
                                    else if (parseFloat(this.personWeight) <= parseFloat(this.WeightLib[1]) && parseFloat(this.personWeight) >= parseFloat(this.WeightLib[0])) {
                                        _imgSrc = this.BMIMaleImgLib.m_low_normal;
                                    }
                                    else {
                                        _imgSrc = this.BMIMaleImgLib.m_low_fat;
                                    }
                                }
                                else if (parseFloat(this.personHeight) >= parseFloat(this.BMILib[0]) && parseFloat(this.personHeight) <= parseFloat(this.BMILib[1])) {
                                    if (parseFloat(this.personWeight) < parseFloat(this.WeightLib[0])) {
                                        _imgSrc = this.BMIMaleImgLib.m_middle_thin;

                                    }
                                    else if (parseFloat(this.personWeight) <= parseFloat(this.WeightLib[1]) && parseFloat(this.personWeight) >= parseFloat(this.WeightLib[0])) {
                                        _imgSrc = this.BMIMaleImgLib.m_middle_normal;
                                    }
                                    else {
                                        _imgSrc = this.BMIMaleImgLib.m_middle_fat;
                                    }
                                }
                                else {
                                    if (parseFloat(this.personWeight) < parseFloat(this.WeightLib[0])) {
                                        _imgSrc = this.BMIMaleImgLib.m_high_thin;
                                    }
                                    else if (parseFloat(this.personWeight) <= parseFloat(this.WeightLib[1]) && parseFloat(this.personWeight) >= parseFloat(this.WeightLib[0])) {
                                        _imgSrc = this.BMIMaleImgLib.m_high_normal;
                                    }
                                    else {
                                        _imgSrc = this.BMIMaleImgLib.m_high_fat;
                                    }
                                }
                            }
                            else {
                                if (parseFloat(this.personHeight) < parseFloat(this.BMILib[0])) {
                                    if (parseFloat(this.personWeight) < parseFloat(this.WeightLib[0])) {
                                        _imgSrc = this.BMIFemaleImgLib.f_low_thin;
                                    }
                                    else if (parseFloat(this.personWeight) <= parseFloat(this.WeightLib[1]) && parseFloat(this.personWeight) >= parseFloat(this.WeightLib[0])) {
                                        _imgSrc = this.BMIFemaleImgLib.f_low_normal;
                                    }
                                    else {
                                        _imgSrc = this.BMIFemaleImgLib.f_low_fat;
                                    }
                                }
                                else if (parseFloat(this.personHeight) >= parseFloat(this.BMILib[0]) && parseFloat(this.personHeight) <= parseFloat(this.BMILib[1])) {
                                    if (parseFloat(this.personWeight) < parseFloat(this.WeightLib[0])) {
                                        _imgSrc = this.BMIFemaleImgLib.f_middle_thin;
                                    }
                                    else if (parseFloat(this.personWeight) <= parseFloat(this.WeightLib[1]) && parseFloat(this.personWeight) >= parseFloat(this.WeightLib[0])) {
                                        _imgSrc = this.BMIFemaleImgLib.f_middle_normal;
                                    }
                                    else {
                                        _imgSrc = this.BMIFemaleImgLib.f_middle_fat;
                                    }
                                }
                                else {
                                    if (parseFloat(this.personWeight) < parseFloat(this.WeightLib[0])) {
                                        _imgSrc = this.BMIFemaleImgLib.f_high_thin;
                                    }
                                    else if (parseFloat(this.personWeight) <= parseFloat(this.WeightLib[1]) && parseFloat(this.personWeight) >= parseFloat(this.WeightLib[0])) {
                                        _imgSrc = this.BMIFemaleImgLib.f_high_normal;
                                    }
                                    else {
                                        _imgSrc = this.BMIFemaleImgLib.f_high_fat;
                                    }
                                }
                            }
                            return _imgSrc;
                        },
                        personBMIWords: function () {
                            var _tmp = '';
                            if (this.personSex == 'male') {
                                if ((this.personBMI * 10) < this.BMILib[0]) {
                                    _tmp = this.BMIMaleWordsLib[0];
                                }
                                else if ((this.personBMI * 10) >= this.BMILib[0] && (this.personBMI * 10) < this.BMILib[1]) {
                                    _tmp = this.BMIMaleWordsLib[1];
                                }
                                else {
                                    _tmp = this.BMIMaleWordsLib[2];
                                }
                            }
                            else {
                                if ((this.personBMI * 10) < this.BMILib[0]) {
                                    _tmp = this.BMIFemaleWordsLib[0];
                                }
                                else if ((this.personBMI * 10) >= this.BMILib[0] && (this.personBMI * 10) < this.BMILib[1]) {
                                    _tmp = this.BMIFemaleWordsLib[1];
                                }
                                else {
                                    _tmp = this.BMIFemaleWordsLib[2];
                                }
                            }
                            return _tmp;
                        },
                        personBMIStatus: function () {
                            var _tmp = '';

                            if ((this.personBMI * 10) < this.BMILib[0]) {
                                _tmp = this.BMIWordsStatusLib[0];
                            }
                            else if ((this.personBMI * 10) >= this.BMILib[0] && (this.personBMI * 10) < this.BMILib[1]) {
                                _tmp = this.BMIWordsStatusLib[1];
                            }
                            else {
                                _tmp = this.BMIWordsStatusLib[2];
                            }

                            return _tmp;
                        },
                    },
                    created: function () {
                        this.isShowPerson = g_person != '' ? true : false;
                        if (this.isShowPerson) {
                            this.personHeight = g_person.height;//单位cm
                            this.personWeight = g_person.weight;//单位公斤
                            this.personSex = g_person.sex;//male,female
                            if (this.personHeight === '' || this.personWeight === '' || this.personSex === '') {
                                this.isShowPersonBMI = false;
                            }
                            //this.personEye = 'high';//high,low,normal
                            if (g_person.leftVisionStatus === '' || g_person.rightVisionStatus === '') {
                                this.EyeStatus = '';
                            }
                            else {
                                this.EyeStatus = Math.min(parseInt(g_person.leftVisionStatus), parseInt(g_person.rightVisionStatus));
                            }

                            if (this.EyeStatus === '' || this.personSex === '') {
                                this.isShowPersonEye = false;
                            }
                            this.personSystolicPressure = g_person.systolicPressure;//收缩压
                            this.personDiastolicPressure = g_person.diastolicPressure;//舒张压
                            this.personGlucose = g_person.bloodSugerNum;//血糖
                            this.personTC = g_person.tCNum;//总胆固醇
                            this.personTG = g_person.TGNum;//甘油三酯
                            this.personHDL = g_person.HDLCNum;//高密度脂蛋白
                            this.personLDL = g_person.LDLCNum;//低密度脂蛋白
                            if (this.personSystolicPressure === '' || this.personDiastolicPressure === '' || this.personGlucose === '' || this.personTC === '' || this.personTG === '' || this.personHDL === '' || this.personLDL === '') {

                            }
                        }
                        else {
                            this.isShowPersonBMI = false;
                            this.isShowPersonEye = false;
                            this.isShowPersonBlood = false;
                            this.personHeight = 0;//单位cm
                            this.personWeight = 0;//单位公斤
                            this.personSex = 'male';//male,female
                            //this.personEye = 'normal';//high,low,normal
                            this.EyeStatus = 0;
                            this.personSystolicPressure = 0;//收缩压
                            this.personDiastolicPressure = 0;//舒张压
                            this.personGlucose = 0;//血糖
                            this.personTC = 0;//总胆固醇
                            this.personTG = 0;//甘油三酯
                            this.personHDL = 0;//高密度脂蛋白
                            this.personLDL = 0;//低密度脂蛋白
                        }


                    },
                    mounted: function () {
                        $('#szWrapper').fullpage({
                            afterLoad: function (anchorLind, index) {
                                INDEX = index;
                                if(INDEX==5){
                                    shan.tools.statisticsPing('321061');
                                }
                                else if(INDEX==6){
                                    shan.tools.statisticsPing('321062');
                                }
                                else if(INDEX==7){
                                    shan.tools.statisticsPing('321063');
                                }

                            }
                        });
                        $('#mask').click(function () {
                            $(this).addClass('hidden');
                        });
                        $('#shareIcon').click(function () {
                            share_wx('shareIcon', INDEX);
                        });
                        $('#shareBtn').click(function () {
                            share_wx('shareBtn', INDEX);
                        });
                        $('.creat_new_page').click(function(){
                            shan.tools.statisticsPing('32101');
                        });
                    }
                })

            });
        },
        bindEvent: function () {

        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});
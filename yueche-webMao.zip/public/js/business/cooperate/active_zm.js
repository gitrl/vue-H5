define(function (require, exports, module) {
    var $ = require('jquery');
    require('lib/jquery.fullPage.min.js');
    require('lib/fastclick');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/share/wxshare');
    var INDEX = 1;

    function share_wx(_id, _index) {
        $('#mask').removeClass('hidden');
        if (_id == 'shareBtn') {
            shan.tools.statisticsPing('370008');
        }
        else if (_id == 'shareIcon') {
            switch (_index) {
                case 1:
                    shan.tools.statisticsPing('370001');
                    break;
                case 2:
                    shan.tools.statisticsPing('370002');
                    break;
                case 3:
                    shan.tools.statisticsPing('370003');
                    break;
                case 4:
                    shan.tools.statisticsPing('370004');
                    break;
                case 5:
                    shan.tools.statisticsPing('370005');
                    break;
                case 6:
                    shan.tools.statisticsPing('370006');
                    break;
                case 7:
                    shan.tools.statisticsPing('370007');
                    break;
                default:
                    shan.tools.statisticsPing('370001');
                    break;
            }
        }

    }

    var f = {
        init: function () {
            var _self = this;
            $(function () {
                shan.tools.statisticsPing('370009');
                FastClick.attach(document.body);
                $('#szWrapper').fullpage({
                    afterLoad: function (anchorLind, index) {
                        INDEX = index;
                        if(INDEX==7){
                            shan.tools.statisticsPing('370010');
                        }
                    }
                });

                //配置微信分享
                var controller = new wxController();
                controller.init(
                    ['onMenuShareTimeline', 'onMenuShareAppMessage'],
                    function () {
                        controller.configShareTimeline({
                            title: "来看看众盟的健康秘密", // 分享标题
                            link: window.location.href, // 分享链接
                            imgUrl: "http://"+window.location.host+"/static/images/cooperate/h5/sharefree.jpg", // 分享图标
                            success: function () {
                                shan.tools.statisticsPing('370012');
                            },
                            cancel: function () {
                            }
                        });
                        controller.configShareAppMessage({
                            title: "来看看众盟的健康秘密", // 分享标题
                            desc: "6个城市104人参加体检，看看我们发现了众盟的什么秘密？", // 分享描述
                            link: window.location.href, // 分享链接
                            imgUrl: "http://"+window.location.host+"/static/images/cooperate/h5/sharefree.jpg", // 分享图标
                            type: '', // 分享类型,music、video或link，不填默认为link
                            dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
                            success: function () {
                                shan.tools.statisticsPing('370011');
                            },
                            cancel: function () {
                            }
                        });
                    }
                );
            });
        },
        bindEvent: function () {
            $('#mask').click(function () {
                $(this).addClass('hidden');
            });
            $('#shareIcon').click(function () {
                share_wx('shareIcon', INDEX);
            });
            $('#shareBtn').click(function () {
                share_wx('shareBtn', INDEX);
            });
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});
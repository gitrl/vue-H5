define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    require('lib/fastclick');
    require('business/suggtob/suggest_share');

    var JS = (function () {
        var status = window.initStatus || '',
            dataSelectArr = $('li[data-select]');

        var $progress_title = $('#progress_title');
        return {
            init: function () {
                this.inits(); //初始化
                this.bindEvents(); //绑定事件
            },

            //初始化
            inits: function () {
                $(function () {
                    FastClick.attach(document.body);
                });
            },

            //绑定事件
            bindEvents: function () {
                var _self = this;
                //选项
                $('#choose-box').on('click','li',function (e) {
                    var index = parseInt($(this).index());
                    if($(this).hasClass('checked')){
                        $(this).removeClass('checked').attr('data-select','0');
                        return;
                    }
                    $(this).addClass('checked').attr('data-select','1');
                    switch (index){
                        case 0:
                            $progress_title.html('痛风为嘌呤代谢紊乱所致，通常具有家族遗传倾向。可通过<span>尿酸检查</span>进行初步诊断。');
                            break;
                        case 1:
                            $progress_title.html('关节红肿疼痛为炎症表现，通常与痛风或类风湿关节炎有关，对应检查<span>尿酸</span>及<span>类风湿因子</span>。');
                            break;
                        default:
                            $progress_title.html('针对Ta的<span>关节</span>情况，请选出所有符合的描述？');
                            break;
                    }

                });
                //下一步
                $('#next-btn').on('click',function (e) {
                    shan.tools.statisticsPing("31001003");
                    if(status.length!=4){
                        status = '000000';
                    }else{
                        status += _self.getStatus();
                    }
                    window.location.href = '/sz/suggtob/suggest_3?status='+ status;
                });
            },

            //获取status
            getStatus: function () {
                var result = [];
                for(var i=0,len=dataSelectArr.length;i<len;i++){
                    result[i] = dataSelectArr[i].getAttribute('data-select');
                }
                return result.join('');
            }
        }
    })();

    $(function () {
        JS.init();
    });


});
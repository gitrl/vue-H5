define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    require('lib/fastclick');
    require('business/suggtob/suggest_share');

    var JS = (function () {
        var status = window.initStatus || '',
            dataSelectArr = $('li[data-select]');

        var $progress_title = $('#progress_title');
        return {
            init: function () {
                this.inits(); //初始化
                this.bindEvents(); //绑定事件
            },

            //初始化
            inits: function () {
                $(function () {
                    FastClick.attach(document.body);
                });
            },

            //绑定事件
            bindEvents: function () {
                var _self = this;
                //选项
                $('#choose-box').on('click','li',function (e) {
                    var index = parseInt($(this).index());
                    if($(this).hasClass('checked')){
                        $(this).removeClass('checked').attr('data-select','0');
                        return;
                    }
                    $(this).addClass('checked').attr('data-select','1');
                    switch (index){
                        case 0:
                            $progress_title.html('长期吸烟或二手烟，与气管炎，多种肺部疾病直接相关，同时大大增加癌症风险，应进行<span>胸片</span>检查。');
                            break;
                        case 1:
                            $progress_title.html('生活环境雾霾严重，工作环境粉尘大，直接影响呼吸系统及肺部功能，应进行<span>胸片</span>检查。');
                            break;
                        case 2:
                            $progress_title.html('长期咳嗽，咳痰，甚至有胸痛症状，通常为气道炎症及肺部病变的表现，应进行<span>胸片</span>及<span>肺功能</span>检查。');
                            break;
                        default:
                            $progress_title.html('针对Ta的<span>肺部</span>状况，请选出所有符合的描述？');
                            break;
                    }
                });
                //下一步
                $('#next-btn').on('click',function (e) {
                    shan.tools.statisticsPing("31001005");
                    if(status.length != 9){
                        status = '000000000000';
                    }else{
                        status += _self.getStatus();
                    }
                    window.location.href = '/sz/suggtob/suggest_5?status='+ status;
                });
            },

            //获取status
            getStatus: function () {
                var result = [];
                for(var i=0,len=dataSelectArr.length;i<len;i++){
                    result[i] = dataSelectArr[i].getAttribute('data-select');
                }
                return result.join('');
            }
        }
    })();

    $(function () {
        JS.init();
    });
});
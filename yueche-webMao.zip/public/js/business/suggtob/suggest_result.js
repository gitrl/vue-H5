define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/fastclick');
    require('lib/jquery.tmpl');
    var STATUS = shan.tools.getUrlParam('status');
    var STATUSARRAY = STATUS.split('');
    require('business/suggtob/suggest_share');


    var f = {
        pingStatus: {
            xn: false,
            fb: false,
            zl: false,
            gj: false
        },
        myChooseDataInfo: {
            xn: {score: 0, descArr: [], desc: '', item: [], title: '', group: 'xn', goodsList: [], goodsListStr: ''},
            fb: {score: 0, descArr: [], desc: '', item: [], title: '', group: 'fb', goodsList: [], goodsListStr: ''},
            zl: {score: 0, descArr: [], desc: '', item: [], title: '', group: 'zl', goodsList: [], goodsListStr: ''},
            gj: {score: 0, descArr: [], desc: '', item: [], title: '', group: 'gj', goodsList: [], goodsListStr: ''}
        },
        myChooseDataInfoTmpl: [],
        chooseData: {
            tfbs: {key: 'gj', val: '痛风家族史', status: 0, score: 1},
            gjzt: {key: 'gj', val: '关节肿痛', status: 0, score: 3},
            sg: {key: 'xn', val: '高血糖', status: 0, score: 1},
            xzbs: {key: 'xn', val: '心脏病史', status: 0, score: 2},
            ty: {key: 'xn', val: '头晕', status: 0, score: 6},
            cqxy: {key: 'fb', val: '吸烟', status: 0, score: 1},
            ywd: {key: 'fb', val: '烟尘、雾霾', status: 0, score: 1},
            cqks: {key: 'fb', val: '咳嗽', status: 0, score: 4},
            gl: {key: 'zl', val: '高龄', status: 0, score: 1},
            cqyj: {key: 'zl', val: '饮酒/饮食不规律', status: 0, score: 1},
            qfyd: {key: 'zl', val: '缺乏运动', status: 0, score: 1},
            tzycxj: {key: 'zl', val: '体重下降', status: 0, score: 5},
            jzaz: {key: 'zl', val: '癌症家族史', status: 0, score: 5},
            xnxg: {key: 'xn', val: '重点检查项目', status: 0, score: 2},
            fb: {key: 'fb', val: '重点检查项目', status: 0, score: 1},
            zl: {key: 'zl', val: '重点检查项目', status: 0, score: 1},
            gj: {key: 'gj', val: '重点检查项目', status: 0, score: 1}
        },
        libList: ['tfbs', 'gjzt', 'sg', 'xzbs', 'ty', 'cqxy', 'ywd', 'cqks', 'gl', 'cqyj', 'qfyd', 'tzycxj', 'jzaz', 'xnxg', 'fb', 'zl', 'gj'],
        lib: {
            libScoreLevel: {
                xn: [{
                    score: '1',
                    name: '糖化血红蛋白',
                    desc: ['糖化血红蛋白'],
                    goodsList: ['A2', 'A3', 'A4']
                }, {
                    score: '5',
                    name: '血流变检测及眼底检查',
                    desc: ['糖化血红蛋白', '血脂四项', '血流变检测', '眼底检查'],
                    goodsList: ['A3', 'A4']
                }, {
                    score: '11',
                    name: '心肌酶谱及经颅多普勒',
                    desc: ['糖化血红蛋白', '血脂四项', '血流变检测', '眼底检查', '心肌酶谱', '经颅多普勒'],
                    goodsList: ['A4']
                }],
                fb: [{
                    score: '3',
                    name: '胸片',
                    desc: ['胸片'],
                    goodsList: ['A2', 'A3', 'A4']
                }, {
                    score: '7',
                    name: '胸片及肺功能',
                    desc: ['胸片', '肺功能'],
                    goodsList: ['A3', 'A4']
                }],
                zl: [{
                    score: '4',
                    name: '肿瘤CEA,AFP筛查',
                    desc: ['甲胎蛋白检测', '癌胚抗原检测'],
                    goodsList: ['A1', 'A2', 'A3', 'A4']
                }, {
                    score: '14',
                    name: '肿瘤标志物检查',
                    desc: ['甲胎蛋白检测', '癌胚抗原检测', '肿瘤标志物全面筛查'],
                    goodsList: ['A3', 'A4']
                }],
                gj: [{
                    score: '2',
                    name: '尿酸检查',
                    desc: ['尿酸检查'],
                    goodsList: ['A2', 'A3', 'A4']
                }, {
                    score: '5',
                    name: '类风湿因子检测',
                    desc: ['尿酸检查', '类风湿因子检测'],
                    goodsList: ['A3', 'A4']
                }]
            },
            libDesc: {
                '糖化血红蛋白': '反映近2-3个月的血糖变化情况，筛查糖尿病，评价糖尿病控制程度，预测微血管并发症',
                '血脂四项': '检查脑血管疾病、动脉硬化、心肌梗塞和冠心病',
                '血流变检测': '血粘度检测，用于高血压、动脉硬化、脑中风、糖尿病及血脂异常等的检查',
                '眼底检查': '可检测动脉硬化及眼底疾病',
                '心肌酶谱': '用于心肌梗死、心肌炎、心肌损伤、溶血性贫血、肝炎等的辅助诊断',
                '经颅多普勒': '对脑血管疾病进行动态检测，了解颅内及颅外各血管、脑动脉环血管及其分支的血流情况，判断有无硬化、狭窄、缺血、畸形等病变',
                '胸片': '针对长期吸烟人群，检查肺癌、肺炎等肺部疾病',
                '肺功能': '用于诊断老年高发肺部疾病如慢性支气管炎、COPD的诊断及病情判断',
                '甲胎蛋白检测': '用于肝癌、肝硬化、胃癌、睾丸癌的诊断',
                '癌胚抗原检测': '广泛的肿瘤标志物，用于乳腺癌、胰腺癌、肺癌、直肠癌、结肠癌的诊断',
                '肿瘤标志物全面筛查': '多种针对性肿瘤标志物检查，如前列腺癌标志物，糖类抗原CA153',
                '尿酸检查': '用于诊断痛风、白血病、肾肿瘤等',
                '类风湿因子检测': '诊断类风湿关节炎的重要指标'
            },
            libGoodsCode: {
                A0: {
                    goodsCode: 'GDS432607373',
                    goodsName: '基础体检套餐',
                    img: '/static/images/cooperate/recommend/bg_GDS432607373.png',
                    goodsOriginPrice: 235,
                    goodsActivePrice: 0,
                    url: '/sz/product/newdetail?goodsCode=GDS432607373&price=0&DATA=54031&activityCode=ACT402081909&orderFrom=3&tag=1&istob=1',
                    desc: ''
                },
                A1: {
                    goodsCode: 'GDS227572760',
                    goodsName: '基础升级套餐 ',
                    img: '/static/images/cooperate/recommend/bg_GDS227572760.png',
                    goodsOriginPrice: 334,
                    goodsActivePrice: 99,
                    url: '/sz/product/newdetail?goodsCode=GDS227572760&price=99&DATA=54031&activityCode=ACT402081909&orderFrom=3&tag=1&istob=1',
                    desc: '腹部B超'

                },
                A2: {
                    goodsCode: 'GDS535103783',
                    goodsName: '标准体检套餐',
                    img: '/static/images/cooperate/recommend/bg_GDS535103783.png',
                    goodsOriginPrice: 598,
                    goodsActivePrice: 398,
                    url: '/sz/product/newdetail?goodsCode=GDS535103783&price=398&DATA=54031&activityCode=ACT402081909&orderFrom=3&tag=1&istob=1',
                    desc: '眼科、裂隙灯、腹部B超、肾脏B超、前列腺超声、妇科超声、宫颈刮片等'
                },
                A3: {
                    goodsCode: 'GDS472631485',
                    goodsName: '高级体检套餐',
                    img: '/static/images/cooperate/recommend/bg_GDS472631485.png',
                    goodsOriginPrice: 796,
                    goodsActivePrice: 596,
                    url: '/sz/product/newdetail?goodsCode=GDS472631485&price=596&DATA=54031&activityCode=ACT402081909&orderFrom=3&tag=1&istob=1',
                    desc: '裂隙灯、腹部B超、肾脏B超、甲状腺超声、前列腺超声、腰椎、妇科超声、宫颈刮片等'
                },
                A4: {
                    goodsCode: 'GDS315337753',
                    goodsName: '豪华全面体检套餐',
                    img: '/static/images/cooperate/recommend/bg_GDS315337753.png',
                    goodsOriginPrice: 1698,
                    goodsActivePrice: 1398,
                    url: '/sz/product/newdetail?goodsCode=GDS315337753&price=1398&DATA=54031&activityCode=ACT402081909&orderFrom=3&tag=1&istob=1',
                    desc: '裂隙灯、口腔科、腹部B超、肾脏B超、甲状腺超声、前列腺超声、乳腺超声、颈椎、腰椎、幽门螺杆菌、宫颈TCT等'
                }
            }
        },
        getMyChooseData: function (_data) {
            var _self = this, i, x, j;
            _data = _data.substring(4);
            var _arr = _data.split('');
            for (i = 0; i < _arr.length; i++) {
                _self.chooseData[_self.libList[i]].status = _arr[i];
            }
            for (x in _self.chooseData) {
                if (_self.chooseData[x].status == '1') {
                    _self.myChooseDataInfo[_self.chooseData[x].key].descArr.push(_self.chooseData[x].val);
                    _self.myChooseDataInfo[_self.chooseData[x].key].score += parseInt(_self.chooseData[x].score);
                }
            }
            for (x in _self.myChooseDataInfo) {
                _self.myChooseDataInfo[x].desc = _self.myChooseDataInfo[x].descArr.join('/');
                if (_self.myChooseDataInfo[x].desc.lastIndexOf('/') == _self.myChooseDataInfo[x].desc.length - 1) {
                    _self.myChooseDataInfo[x].desc = _self.myChooseDataInfo[x].desc.substring(0, _self.myChooseDataInfo[x].desc.length - 1);
                }
                for (i = 0; i < _self.lib.libScoreLevel[x].length; i++) {
                    if (_self.myChooseDataInfo[x].score <= _self.lib.libScoreLevel[x][i].score) {
                        _self.myChooseDataInfo[x].title = _self.lib.libScoreLevel[x][i].name;
                        _self.myChooseDataInfo[x].goodsList = _self.lib.libScoreLevel[x][i].goodsList;
                        _self.myChooseDataInfo[x].goodsListStr = _self.lib.libScoreLevel[x][i].goodsList.join(',');
                        for (j = 0; j < _self.lib.libScoreLevel[x][i].desc.length; j++) {
                            var _obj = {};
                            _obj.name = _self.lib.libScoreLevel[x][i].desc[j];
                            _obj.words = _self.lib.libDesc[_self.lib.libScoreLevel[x][i].desc[j]];
                            _self.myChooseDataInfo[x].item.push(_obj);
                        }
                        break;
                    }
                }
            }
            for (x in _self.myChooseDataInfo) {
                _self.myChooseDataInfoTmpl.push(_self.myChooseDataInfo[x]);
            }
        },
        getGoodsArray: function () {
            var _self = this, i,j, _goodsListStr = '', _goodsList = [], _goodsListTemp = [],_tempGoodsList1=[],_tempGoodsList2=[];
            for (i = 0; i < $('#showItemWrap').find('.itemCheck').length; i++) {
                if ($($('#showItemWrap').find('.itemCheck').get(i)).prop('checked')) {
                    //_goodsListStr += $($('#showItemWrap').find('.itemCheck').get(i)).data('goods') + ',';
                    if(_tempGoodsList1.length<1){
                        _tempGoodsList1=$($('#showItemWrap').find('.itemCheck').get(i)).data('goods').split(',');
                    }
                    else{
                        _tempGoodsList2=$($('#showItemWrap').find('.itemCheck').get(i)).data('goods').split(',');
                        _tempGoodsList1=_tempGoodsList1.concat(_tempGoodsList2);
                        _tempGoodsList1.sort();
                        _tempGoodsList2=[];
                        for (j = 0; j < _tempGoodsList1.length - 1; j++) {
                            if (_tempGoodsList1[j] == _tempGoodsList1[j + 1]) {
                                _goodsListTemp.push(_tempGoodsList1[j]);
                            }
                        }
                        _tempGoodsList1 =_goodsListTemp.concat([]);
                        _goodsListTemp = [];
                    }
                }
            }
            if(_tempGoodsList1.length<1){
                _tempGoodsList1=['A0'];
            }
            var goodsInfo = _self.lib.libGoodsCode[_tempGoodsList1[0]];
            $('#serWords').html(goodsInfo.desc);
            if (goodsInfo.desc == '') {
                $('#serWords').parent().addClass('hidden');
            }
            else {
                $('#serWords').parent().removeClass('hidden')
            }
            $('#showGoodsWrap').html($('#dShowGoods').tmpl(goodsInfo));
        },
        fomateDom: function () {
            var _self = this, i, x, goodsListData = '';
            _self.getMyChooseData(STATUS);
            $('#showItemWrap').html($('#dShowItem').tmpl(_self.myChooseDataInfoTmpl));
            $($('#showItemWrap').children('.rrv2Module').get(0)).children('.body').addClass('open');
            _self.getGoodsArray();
        },
        init: function () {
            var _self = this;
            $(function () {
                FastClick.attach(document.body);
                _self.fomateDom();
            });
        },
        bindEvent: function () {
            var _self = this;
            $('#showItemWrap').on('click', '.infoController', function () {
                if ($(this).parents('.body').hasClass('open')) {
                    $(this).parents('.body').removeClass('open');
                }
                else {
                    $(this).parents('.body').addClass('open');
                }
                var _item = $(this).data('name');
                if (!_self.pingStatus[_item]) {
                    switch (_item) {
                        case 'xn':
                            shan.tools.statisticsPing("31001008");
                            break;
                        case 'fb':
                            shan.tools.statisticsPing("31001009");
                            break;
                        case 'zl':
                            shan.tools.statisticsPing("31001010");
                            break;
                        case 'gj':
                            shan.tools.statisticsPing("31001011");
                            break;
                        default:
                            break;
                    }
                    _self.pingStatus[_item] = true;
                }
            });
            $('#showItemWrap').on('click', '.yo-switch', function () {
                if ($(this).children('.itemCheck').prop('checked')) {
                    $(this).children('.itemCheck').prop('checked', false);
                    $(this).parents('.rrv2Module').addClass('closed');
                }
                else {
                    $(this).children('.itemCheck').prop('checked', true);
                    $(this).parents('.rrv2Module').removeClass('closed');
                }
                _self.getGoodsArray();
            });
            $('#showGoodsWrap').on('click', '#nextBtn', function () {
                shan.tools.statisticsPing("31001012", {sourceCode: $(this).data('code')});
            });
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});

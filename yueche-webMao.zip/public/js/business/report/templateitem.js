define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    var defineData = {
        "BLOOD_GLUCOSE_PKG_A" : "301001",
        "BLOOD_GLUCOSE_PKG_B" : "301002",
        "BLOOD_GLUCOSE_METER" : "301003",
        "BLOOD_PRESSURE_METER" : "301022",
        "HYPERTENSION" : "301023",
        "HIGH_BLOOD_LIPID" : "301024"
    };
    
    var f = {
        domList : {
            name : 'proName',
            detectionVal : 'detectionVal',
            detectionStatus : 'detectionStatus',
            detectionResult : 'detectionResult',
            detectionUnit : 'detectionUnit',
            normalVal : 'normalVal',
            normalUnit : 'normalUnit',
            abnormity : 'abnormity',
            projectdefine : 'projectdefine',
            items : 'items',
            schemes : 'schemes',
            detectionStatusLine : 'detectionStatusLine',
            relatedDisease : 'relatedDisease'
        },
        options : {
            itemCode : shan.tools.getUrlParam('itemCode'),
            url : '/report/reportdisease',
            imgMap : {
                BLOOD_GLUCOSE_PKG_A : 'product/product-a.png',
                BLOOD_GLUCOSE_PKG_B : 'product/product-b.png',
                BLOOD_GLUCOSE_METER : 'product/product-1.png',
                BLOOD_PRESSURE_METER : "product/product-2.png",
                HYPERTENSION : "product/product-5.png",
                HIGH_BLOOD_LIPID : "product/product-5.png"
            }
        },
        imgStatic : '/static/images/report/',
        init : function () {
            var _self=this;
            _self.options.itemCode = shan.tools.getUrlParam('itemCode');
            _self.options.sourceCode = shan.tools.getUrlParam('sourceCode');
            _self.options.src = shan.tools.getUrlParam('src');
            //统计来源
            
            shan.ajax({
                url : "/sz/report/templatedetail",
                data: {
                    itemCode : _self.options.itemCode
                },
                success: function(json) {
                    if(json.SZ_HEAD.RESP_CODE === 'S0000'){
                        var i,_temp = '';
                        $('#' + _self.domList.name).html(json.SZ_BODY.ITEM_D.itemName);
                        switch (json.SZ_BODY.ITEM_D.checkResultType){
                            case 1 :
                                $('#' + _self.domList.detectionVal).html(json.SZ_BODY.ITEM_CHECK_D.reportCheckValue).attr('colspan','3').css('width','75%');
                                //$('#' + _self.domList.detectionStatusLine).addClass('hidden');
                                $('#' + _self.domList.detectionUnit).addClass('hidden');
                                $('#' + _self.domList.normalVal).parent().addClass('hidden');
                                if(json.SZ_BODY.ITEM_CHECK_D.reportCheckResult == 'COMMON' || json.SZ_BODY.ITEM_CHECK_D.reportCheckResult == ""){
                                    $('#' + _self.domList.detectionStatus).removeClass('abnormal');
                                    $('#' + _self.domList.detectionResult).addClass('green').text("正常");
                                }
                                else{
                                    $('#' + _self.domList.detectionStatus).addClass('abnormal');
                                    $('#' + _self.domList.detectionResult).addClass('red').text("异常");
                                }
                                break;
                            case 2 :
                                $('#' + _self.domList.detectionVal).html(json.SZ_BODY.ITEM_CHECK_D.reportCheckValue).removeAttr('colspan').css('width','25%');
                                //$('#' + _self.domList.detectionStatusLine).removeClass('hidden');
                                $('#' + _self.domList.detectionUnit).removeClass('hidden').html(json.SZ_BODY.ITEM_CHECK_D.reportItemUnit);
                                $('#' + _self.domList.normalVal).parent().addClass('hidden');
                                if(json.SZ_BODY.ITEM_CHECK_D.reportCheckResult == 'COMMON' || json.SZ_BODY.ITEM_CHECK_D.reportCheckResult == ""){
                                    $('#' + _self.domList.detectionStatus).removeClass('abnormal');
                                    $('#' + _self.domList.detectionResult).addClass('green').text("正常");
                                }
                                else{
                                    $('#' + _self.domList.detectionStatus).addClass('abnormal');
                                    $('#' + _self.domList.detectionResult).addClass('red').text("异常");
                                }
                                break;
                            case 3 :
                                $('#' + _self.domList.detectionVal).html(json.SZ_BODY.ITEM_CHECK_D.reportCheckValue).removeAttr('colspan').css('width','25%');
                                //$('#' + _self.domList.detectionStatusLine).removeClass('hidden');
                                $('#' + _self.domList.detectionUnit).removeClass('hidden').html(json.SZ_BODY.ITEM_CHECK_D.reportItemUnit);

                                if(json.SZ_BODY.ITEM_CHECK_D.reportStandardValue && json.SZ_BODY.ITEM_CHECK_D.reportStandardValue != ''){
                                    $('#' + _self.domList.normalVal).html(json.SZ_BODY.ITEM_CHECK_D.reportStandardValue).parent().removeClass('hidden');
                                }

                                $('#' + _self.domList.normalUnit).html(json.SZ_BODY.ITEM_CHECK_D.reportItemUnit);
                                if(json.SZ_BODY.ITEM_CHECK_D.reportCheckResult == 'COMMON' || json.SZ_BODY.ITEM_CHECK_D.reportCheckResult == ""){
                                    $('#' + _self.domList.detectionStatus).removeClass('abnormal');
                                    $('#' + _self.domList.detectionResult).addClass('green').text("正常");
                                }
                                else{
                                    $('#' + _self.domList.detectionStatus).addClass('abnormal');
                                    $('#' + _self.domList.detectionResult).addClass('red').text("异常");
                                }
                                break;
                            default :
                                break;
                        }
                        if(json.SZ_BODY.ITEM_CHECK_D.abnormalExplain && json.SZ_BODY.ITEM_CHECK_D.abnormalExplain != ''){

                            $('#' + _self.domList.abnormity).html(json.SZ_BODY.ITEM_CHECK_D.abnormalExplain).parent().removeClass('hidden');
                        }
                        if(json.SZ_BODY.ITEM_D.itemIntro && json.SZ_BODY.ITEM_D.itemIntro != ''){
                            $('#' + _self.domList.projectdefine).html(json.SZ_BODY.ITEM_D.itemIntro).parent().removeClass('hidden');
                        }

                        if(json.SZ_BODY.ITEM_D.relatedDiseases && json.SZ_BODY.ITEM_D.relatedDiseases != ''){
                            $('#' + _self.domList.relatedDisease).html(json.SZ_BODY.ITEM_D.relatedDiseases).parent().removeClass('hidden');
                        }

                        _self.options.itemCode = json.SZ_BODY.ITEM_D.itemId;

                    }
                    else{
                        pop.alert(json.SZ_HEAD.RESP_MSG);
                    }

                },
                error : function(json){
                    console.log(json);
                }
            });
            shan.ajax({
                url : "/sz/report/diseaselist",
                data: {
                    itemCode : _self.options.itemCode
                },
                success: function(json) {
                    if(json.SZ_HEAD.RESP_CODE === 'S0000'){
                        if(json.SZ_BODY.DISEASES_D && json.SZ_BODY.DISEASES_D.length > 0) {
                            $('#' + _self.domList.items).html(_self.formatItem(json.SZ_BODY.DISEASES_D,_self.options)).parent().removeClass('hidden');
                        }
                        else{
                            $('#' + _self.domList.items).parent().addClass('hidden');
                        }
                        if(json.SZ_BODY.SERVICES_D && json.SZ_BODY.SERVICES_D.length > 0) {
                            $('#' + _self.domList.schemes).html(_self.formatSchemes(json.SZ_BODY.SERVICES_D,_self.options,_self.imgStatic)).parent().removeClass('hidden');
                        }
                        else{
                            $('#' + _self.domList.schemes).parent().addClass('hidden');
                        }
                    }
                    else{
                        pop.alert(json.SZ_HEAD.RESP_MSG);
                    }

                },
                error : function(json){
                    console.log(json);
                }
            });
        },
        formatItem : function(_items,_options){
            var i = 0,
                _tmp = '';
            for(i = 0  ; i < _items.length ;i++){
                _tmp +='<li  class="clickable">' +
                            '<a href="' + _options.url + '/itemCode/' + _options.itemCode + '/diseaseCode/' + _items[i].diseaseCode + '" data-code="' + _items[i].diseaseCode + '">' +
                                '<div class="sz-proportion-title">' +
                                    '<span>' + _items[i].diseaseCause + '</span>' +
                                    '<span class="fr hidden">' + _items[i].similarPercentage + '%相似病例</span>' +
                                '</div>' +
                                '<div class="yo-proportion sz-proportion hidden">' +
                                    '<div class="inner" style="width:' + _items[i].similarPercentage + '%"></div>' +
                                '</div>' +
                                '<i class="yo-ico"></i>' +
                            '</a>' +
                        '</li>';
            }
            return _tmp;
        },
        formatSchemes : function(_items,_optins,_imgStatic){
            var i = 0,
                _tmp = '',
                _url ='/sz/product/product/serviceCode/';
            for(i = 0  ; i < _items.length ;i++){
                _tmp +='<li class="clickable">' +
                            '<a href="' + _url +_items[i].serviceCode +'?DATA='+defineData[_items[i].serviceCode]+'">' +
                                '<img src="' + _imgStatic + _optins.imgMap[_items[i].serviceCode] + '">' +
                                '<h3>' + _items[i].serviceName + '</h3>' +
                                '<p>' + _items[i].serviceDesc + '</p>' +
                                '<span class="price fr text-red f13 hidden">￥' + _items[i].servicePriceVal + '</span>' +
                            '</a>' +
                        '</li>';
            }
            return _tmp;
        },
        bindEvent : function () {
            var _self = this;
            $('body').on('click','#pageBack',function (){
                if(_self.options.src == 1){
                    window.location.replace('/sz/report/template/sourceCode/' + _self.options.sourceCode);
                }
                else{
                    window.location.replace('/sz/report/templateset');
                }
                

            });
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});

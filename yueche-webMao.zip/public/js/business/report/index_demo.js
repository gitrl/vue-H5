/**
 * Created by wayyue05 on 2017/3/1.
 */
define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    require('lib/fastclick');
    require('lib/swiper.min.js');
    require('lib/share/wxshare');
    var f = {
        init: function () {
            $(function () {
                FastClick.attach(document.body);
            });
            var options = {
                title: '健康数据中心',
                desc: '2015-2017体检报告',
                imgUrl: "http://m.shanzhen.me/static/images/demo/share.jpg"
            };

            //配置微信分享
            var controller = new wxController();
            controller.init(
                ['onMenuShareTimeline', 'onMenuShareAppMessage'],
                function () {
                    controller.configShareTimeline({
                        title: options.title, // 分享标题
                        desc:  options.desc, // 分享描述
                        imgUrl: options.imgUrl, //分享图标
                        success: function () {
                        },
                        cancel: function () {
                        }
                    });
                    controller.configShareAppMessage({
                        title: options.title, // 分享标题
                        desc:  options.desc, // 分享描述
                        imgUrl: options.imgUrl, //分享图标
                        type: '', // 分享类型,music、video或link，不填默认为link
                        dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
                        success: function () {
                        },
                        cancel: function () {
                        }
                    });
                }
            );

        },
        bindEvent: function () {
            $('.report-year').on('click',function(e){
                var index = $(this).index();
                window.location.href = '/sz/report/demo?years=' + index;
            })
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    };

    //初始化函数
    exports.run = run;
});
define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/jquery.tmpl');
    require('lib/fastclick');
    var szAudio = require('lib/sz-audio');
    var orderCode = shan.tools.getUrlParam("orderCode");
    var opt = {
        ele: $('#szAudio').get(0),
        min: 0,
        step: 1,
        clone: true,
        cloneEle: $('#szAudio_1').get(0)
    };
    var audioFixed = false;

    var f = {
        $domItemAudioSource: $('#itemAudioSource'),
        $domItemAudioBtn: null,
        isAudioShow: false,
        //isAudioPlay: false,
        isShowReview: g_evaluate,
        init: function () {
            $(function () {
                FastClick.attach(document.body);
                shan.tools.statisticsPing("190003", {mainId: orderCode});
                try {
                    var obj = JSON.parse(g_data);
                    f.showReport(obj.SZ_BODY);
                }
                catch (e) {
                    pop.alert("初始化失败!", function () {
                        window.location.replace("/sz/user/reportlist");
                    });
                    return;
                }
                
            });

        },
        showReport: function (data) {
            var _self = this;
            $('#examineeName').text(data.examineeName ? data.examineeName : '');
            $("#abnormalNum").text(data.abnormal ? data.abnormal : 0);
            $("#institName").text(data.institName ? data.institName : '');
            $("#examineeDate").text(data.examineeDate ? data.examineeDate : '');

            if (data.HAS_MEDIA_REPORT && data.HAS_MEDIA_REPORT == '1') {
                var _audio = szAudio.init(opt);
            }

            if ($('.audio-btn').length > 0) {
                $('.audio-btn').on('click', function () {

                    if ($(this).hasClass('pause')) {
                        shan.tools.statisticsPing("190018");
                        _self.$domItemAudioSource.get(0).pause();
                        _self.$domItemAudioSource.get(0).currentTime = 0;
                        $(this).removeClass('pause');
                    }
                    else {
                        shan.tools.statisticsPing("190017");
                        if ($(this).data('src') != _self.$domItemAudioSource.attr('src')) {
                            _self.$domItemAudioSource.attr('src', $(this).data('src')+"?_"+Math.random());
                        }
                        _self.$domItemAudioSource.get(0).currentTime = 0;
                        _self.$domItemAudioSource.get(0).play();
                        _self.$domItemAudioBtn = $(this);
                        if (_self.$domItemAudioSource.get(0).networkState == '0' || _self.$domItemAudioSource.get(0).networkState == '3') {
                            setTimeout(function () {
                                _self.$domItemAudioSource.get(0).play();
                                $('.audio-btn').removeClass('pause');
                                _self.$domItemAudioBtn.addClass('pause');

                            }, 0);

                        }
                        else {
                            $('.audio-btn').removeClass('pause');
                            _self.$domItemAudioBtn.addClass('pause');
                        }
                    }
                    //if (!f.isAudioPlay) {
                    //    shan.tools.statisticsPing("190011");
                    //    f.isAudioPlay = true;
                    //}
                });
                if (!f.isAudioShow) {
                    shan.tools.statisticsPing("190014");
                    f.isAudioShow = true;
                }
            }

        },
        checkAbnormal: function (_orderCode) {
            shan.ajax({
                data: {
                    url: "/szreport/preview/abnormal_summary.htm",
                    orderCode: _orderCode
                },
                success: function (_json) {
                    try {
                        if (_json.SZ_HEAD.RESP_CODE == 'S0000') {
                            if (_json.SZ_BODY.abnormalCount > 0) {
                                location.href = '/sz/report/abnormalpreview/orderCode/' + orderCode;
                            }
                        }
                    }
                    catch (e) {

                    }
                }
            });
        },
        bindEvent: function () {
            var _self = this;
            _self.isFristShowEnd = true;
            var topDistance = 0,
                $backTop = $('#backTop'),
                $flexBody = $('#flexBody');
            $('#sItemList').on('click', 'li', function () {
                location.href = "/sz/report/detail/orderCode/" + orderCode + "#" + $(this).data('code');
            });
            // 查询异常汇总页面，因为云脉数据问题暂时关闭
            $('#errBox').click(function () {
                shan.tools.statisticsPing("190005", {mainId: orderCode});
                _self.checkAbnormal(orderCode);
            });

            $('#flexBody').scroll(function () {
                if (!audioFixed) {
                    if ($('#flexBody').scrollTop() >= 57) {
                        $('#audioFlexBox').removeClass('hidden');
                        $('#audioFlexBoxInit').hide();
                        audioFixed = true;
                    }
                }

            });


            //滚动，出现返回按钮
            $("body").on("touchend", function (e) {
                topDistance = $flexBody.scrollTop();
                if (topDistance > 330) {
                    $backTop.show();
                }
                else {
                    $backTop.hide();
                }

                var totalHigh = 0;
                $("section").each(function () {
                    totalHigh += $(this).height() * 1;
                });

                if (topDistance + 600 >= totalHigh && _self.isFristShowEnd) {
                    shan.tools.statisticsPing("190004", {mainId: orderCode});
                    _self.isFristShowEnd = false;
                }
            });

            //点击返回按钮
            $backTop.on('click', function () {
                $backTop.hide(500);

                $flexBody.animate({'scrollTop': 0}, 500);
            });

            //点击报告区，提示消失
            $('#szAudio').on('click', function (e) {
                $('#audio-tips').addClass('hidden');
            });
            //点击播放按钮
            $('#playBtn, #playBtn_1').on('click', function (e) {
                shan.tools.statisticsPing("190009", {mainId: orderCode});
            });
            //孝心套餐语音监控
            f.$domItemAudioSource.on('ended', function () {
                f.$domItemAudioBtn.removeClass('pause');
            })

            //医生解读回评
            $('#pageBack').click(function (e) {
                if (f.isShowReview == 1){
                    $('#review').removeClass('hidden');
                    shan.tools.statisticsPing("190012");
                    return false;
                }
            });

            $('#review').on('click', '.close', function () {
                $('#review').addClass('hidden');
            });

            //语音评价页面
            $("#hasHelp").click(function(){
                window.location.href = "/sz/report/goodcomment/orderCode/" + orderCode;
            });
            $("#hasNohelp").click(function(){
                window.location.href = "/sz/report/badcomment/orderCode/" + orderCode;
            });

            $('#unscrambleComprehensive,#unscrambleHelp').children('li').click(function () {
                var _index = $(this).index(),
                    $_domLi = $(this).parent().children('li'),
                    _len = $_domLi.length,
                    i;
                for (var i = 0; i < _len; i++) {
                    if (i <= _index) {
                        $($_domLi[i]).addClass('cur');
                    }
                    else {
                        $($_domLi[i]).removeClass('cur');
                    }
                }
            });

            $('#reviewBtn').click(function () {
                var _unscrambleComprehensive = $('#unscrambleComprehensive').children('.cur').length,
                    _unscrambleHelp = $('#unscrambleHelp').children('.cur').length;
                shan.tools.statisticsPing("190013");
                shan.ajax({
                    data: {
                        url: '/reportmedia/preview/updateReportMedia.htm',
                        orderCode: orderCode,
                        unscrambleComprehensive: _unscrambleComprehensive,
                        unscrambleHelp: _unscrambleHelp
                    },
                    success: function (_json) {
                        console.log(_json)
                        $('#review').addClass('hidden');
                    }
                });
            });

            //展开孝心异常语音
            $('.abnormal.has-radio').find('.status').click(function () {
                if ($(this).parents('.abnormal.has-radio').hasClass('show')) {
                    $(this).parents('.abnormal.has-radio').removeClass('show');
                    shan.tools.statisticsPing("190016");
                }
                else {
                    $(this).parents('.abnormal.has-radio').addClass('show');
                    shan.tools.statisticsPing("190015");
                }
            });

        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});

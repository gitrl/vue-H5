define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/vue/vue.min');
    require('lib/jquery.tmpl');
    require('lib/fastclick');
    require('lib/draggabilly.pkgd.min');
    var szAudio = require('lib/sz-audio');
    var orderCode = shan.tools.getUrlParam("orderCode");

    var showReview = function () {
        if (f.isShowReview == 1) {
            $('#review').removeClass('hidden');
        }
    };


    var audioFixed = false;
    var f = {
        $domItemAudioSource: $('#itemAudioSource'),
        $domItemAudioBtn: null,
        isAudioShow: false,
        isShowReview: g_evaluate,
        comment: shan.tools.getUrlParam("comment"),
        init: function () {
            try {
                var report_summary = (JSON.parse(g_report_summary.replace(/\r\n/g, '<br/>').replace(/\n/g, '<br/>').replace(/\t/g, "").replace(/'/g, "\"").replace(/\s+/g, ""))).SZ_BODY,
                    resultRadioDetail = JSON.parse(g_resultRadioDetail.replace(/\r\n/g, '<br/>').replace(/\n/g, '<br/>').replace(/\t/g, "").replace(/'/g, "\"").replace(/\s+/g, "")),
                //report_items = JSON.parse(g_REPORT_ITEM.replace(/\r\n/g,'<br/>').replace(/\n/g,'<br/>').replace(/\t/g,"").replace( /'/g , "\"" ).replace( /\s+/g , "" )),
                //abnormal_items = JSON.parse(g_abnormal_items.replace(/\r\n/g,'<br/>').replace(/\n/g,'<br/>').replace(/\t/g,"").replace( /'/g , "\"" ).replace( /\s+/g , "" )),
                    orderInterpretation = JSON.parse(g_orderInterpretation);
            } catch (e) {
                pop.alert("初始化失败!", function () {
                    window.location.replace("/sz/user/reportlist");
                });
            }
            var vm = new Vue({
                el: '#app',
                data: {
                    orderInterpretation: orderInterpretation,   //报告解读状态
                    abnormal: 0,    //异常数
                    report_summary: report_summary, //体检概况
                    hadRadio: g_hadRadio,   //是否有语音解读
                    resultRadioDetail: resultRadioDetail,   //语音详情
                    report_items: [],     //报告详情
                    abnormal_items: [], //异常项详情
                    showProcess: false,  //解读中提示弹窗
                    showStatement: false,    //善诊报告声明弹窗
                    showGetTicket: false,//是否展示送券
                    showRightBottomBtn: false,//是否展示右下角按钮
                    showTicketDataList: [],//券数据
                    hasBackAbnormal_items:false,//回调函数是否返回
                    needAnimated:false//需要动画
                },
                watch:{
                    hasBackAbnormal_items:function(newValue,oldValue){
                        var _self=this;
                        if(newValue===true&&_self.showRightBottomBtn===true){
                            _self.needAnimated=true;
                            setTimeout(function(){
                                _self.needAnimated=false;
                            },1100);
                        }
                    },
                    showRightBottomBtn:function(newValue,oldValue){
                        var _self=this;
                        if(newValue===true&&_self.hasBackAbnormal_items===true){
                            _self.needAnimated=true;
                            setTimeout(function(){
                                _self.needAnimated=false;
                            },1100);
                        }
                    }
                },
                created: function () {
                    //获取体检详情,避开JSON.parse
                    shan.ajax({
                        url: '/sz/report/get_report_detail_list_async',
                        data: {
                            orderCode: orderCode
                        },
                        success: function (json) {
                            if (json.SZ_HEAD.RESP_CODE == 'S0000') {
                                vm.report_items = json.SZ_BODY.REPORT_ITEM;
                                vm.hasBackAbnormal_items=true;
                            } else {
                                pop.alert(json.SZ_HEAD.RESP_MSG);
                            }
                        }
                    });

                    //获取异常项详情,避开JSON.parse
                    shan.ajax({
                        url: '/sz/report/get_abnormal_code_async',
                        data: {
                            orderCode: orderCode
                        },
                        success: function (json) {
                            if (json.SZ_HEAD.RESP_CODE == 'S0000') {
                                vm.abnormal_items = json.SZ_BODY.ABNORMAL_ITEM_LIST;
                            } else {
                                pop.alert(json.SZ_HEAD.RESP_MSG);
                            }
                        }
                    });
                    //异常数不为0时动画
                    if (report_summary.abnormal != 0) {
                        var abnormalAnimation = setInterval(function () {
                            vm.abnormal += 1;
                            if (vm.abnormal == report_summary.abnormal) {
                                clearInterval(abnormalAnimation);
                            }
                        }, 1000 / report_summary.abnormal);
                    }

                    try {
                        g_firt_get_ticket = JSON.parse(g_firt_get_ticket) || {};
                        if (typeof g_firt_get_ticket != 'undefined' && g_firt_get_ticket.SZ_HEAD.RESP_CODE == 'S0000' && typeof g_firt_get_ticket.SZ_BODY.generatedEquityRecords != 'undefined' && g_firt_get_ticket.SZ_BODY.generatedEquityRecords.length > 0) {
                            this.showTicketDataList = g_firt_get_ticket.SZ_BODY.generatedEquityRecords;
                            this.showGetTicket = true;
                        }
                        else{
                            this.showRightBottomBtn=true;
                            //this.needAnimated=true;
                        }

                    }
                    catch (e) {
                        console.log(e);
                    }
                },
                mounted: function () {
                    var opt = {
                        ele: $('#szAudio').get(0),
                        min: 0,
                        step: 1,
                        clone: true,
                        cloneEle: $('#szAudio_1').get(0),
                        audioDuration: Math.ceil(parseFloat($('#api-audio-duration').val())),
                        review: showReview
                    };
                    if (report_summary.HAS_MEDIA_REPORT && report_summary.HAS_MEDIA_REPORT == '1') {
                        var _audio = szAudio.init(opt);
                    }
                },
                methods: {
                    closeFirstMask: function () {
                        this.showGetTicket = false;
                        this.showRightBottomBtn = true;
                        //this.needAnimated=true;
                    },
                    //关闭解读中弹窗
                    closeProcess: function () {
                        this.showProcess = false;
                    },
                    //查看订单
                    checkOrder: function () {
                        window.location.href = '/sz/ask/my_ask_list';
                    },
                    //查看报告声明
                    toStatement: function () {
                        this.showStatement = true;
                    },
                    //关闭报告声明
                    closeStatement: function () {
                        this.showStatement = false;
                    }
                }
            });

            var $abnormalAsk = $('.abnormal-ask').draggabilly();
            var $reportAsk = $('.report-ask').draggabilly();
            //点击异常解读按钮
            $abnormalAsk.on('staticClick', function (event, pointer) {
                if (vm.abnormal_items.length == 0) {
                    window.location.href = '/sz/order/fast_ask?orderSource=2&orderCode=' + orderCode;
                    shan.tools.statisticsPing("250020");
                    return;
                }
                shan.tools.statisticsPing("252001", {mainId: orderCode});
                window.location.href = '/sz/order/abnormal_pay?orderCode=' + orderCode;
            });
            //点击报告解读按钮
            $reportAsk.on('staticClick', function (event, pointer) {
                shan.tools.statisticsPing("252002", {mainId: orderCode});
                if (vm.orderInterpretation == 'PROCESSING') {
                    vm.showProcess = true;
                    return;
                }
                window.location.href = '/sz/order/report_pay?orderCode=' + orderCode;
            });

            $(function () {
                FastClick.attach(document.body);
                shan.tools.statisticsPing("190003", {mainId: orderCode});
                shan.tools.statisticsPing("252004", {mainId: orderCode});
            });
            if (f.isShowReview == 1 && f.comment == 1) {
                $('#review').removeClass('hidden');
                shan.tools.statisticsPing("190012");
            }
        },
        showReport: function () {
            var _self = this;
            if ($('.audio-btn').length > 0) {
                $('.audio-btn').on('click', function () {
                    if ($(this).hasClass('pause')) {
                        shan.tools.statisticsPing("190018");
                        _self.$domItemAudioSource.get(0).pause();
                        _self.$domItemAudioSource.get(0).currentTime = 0;
                        $(this).removeClass('pause');
                    } else {
                        shan.tools.statisticsPing("190017");
                        if ($(this).data('src') != _self.$domItemAudioSource.attr('src')) {
                            _self.$domItemAudioSource.attr('src', $(this).data('src') + "?_" + Math.random());
                        }
                        _self.$domItemAudioSource.get(0).currentTime = 0;
                        _self.$domItemAudioSource.get(0).play();
                        _self.$domItemAudioBtn = $(this);
                        if (_self.$domItemAudioSource.get(0).networkState == '0' || _self.$domItemAudioSource.get(0).networkState == '3') {
                            setTimeout(function () {
                                _self.$domItemAudioSource.get(0).play();
                                $('.audio-btn').removeClass('pause');
                                _self.$domItemAudioBtn.addClass('pause');

                            }, 0);

                        } else {
                            $('.audio-btn').removeClass('pause');
                            _self.$domItemAudioBtn.addClass('pause');
                        }
                    }
                });
                if (!f.isAudioShow) {
                    shan.tools.statisticsPing("190014");
                    f.isAudioShow = true;
                }
            }

        },
        checkAbnormal: function (_orderCode) {
            shan.ajax({
                data: {
                    url: "/szreport/abnormal_summary.htm",
                    orderCode: _orderCode
                },
                success: function (_json) {
                    try {
                        if (_json.SZ_HEAD.RESP_CODE == 'S0000') {
                            if (_json.SZ_BODY.abnormalCount > 0) {
                                location.href = '/sz/report/abnormal/orderCode/' + orderCode;
                            }
                        }
                    }
                    catch (e) {
                        console.log(e);
                    }
                }
            });
        },
        bindEvent: function () {
            var _self = this;
            _self.isFristShowEnd = true;
            var topDistance = 0,
                $backTop = $('#backTop'),
                $statement = $('#statement'),
                $flexBody = $('#flexBody');
            $('#sItemList').on('click', 'li', function () {
                location.href = "/sz/report/detail/orderCode/" + orderCode + "#" + $(this).data('code');
            });
            // 查询异常汇总页面，因为云脉数据问题暂时关闭
            $('#errBox_1').click(function () {
                shan.tools.statisticsPing("190005", {mainId: orderCode});
                shan.tools.statisticsPing("252003");
                _self.checkAbnormal(orderCode);
            });

            $flexBody.scroll(function () {
                if (!audioFixed) {
                    if ($flexBody.scrollTop() >= 57) {
                        $('#audioFlexBox').removeClass('hidden');
                        $('#audioFlexBoxInit').hide();
                        audioFixed = true;
                    }
                }
            });

            //滚动，出现返回按钮
            $("body").on("touchend", function (e) {
                topDistance = $flexBody.scrollTop();
                if (topDistance > 330) {
                    $backTop.show();
                } else {
                    $backTop.hide();
                }

                var totalHigh = 0;
                $("section").each(function () {
                    totalHigh += $(this).height() * 1;
                });

                if (topDistance + 600 >= totalHigh && _self.isFristShowEnd) {
                    shan.tools.statisticsPing("190004", {mainId: orderCode});
                    _self.isFristShowEnd = false;
                }
            });

            //点击返回按钮
            $backTop.on('click', function () {
                $backTop.hide(500);
                $flexBody.animate({'scrollTop': 0}, 500);
            });

            //点击报告区，提示消失
            $('#szAudio').on('click', function (e) {
                $('#audio-tips').addClass('hidden');
            });
            //点击播放按钮
            $('#playBtn, #playBtn_1').on('click', function (e) {
                shan.tools.statisticsPing("190009", {mainId: orderCode});
                shan.tools.statisticsPing("252005", {mainId: orderCode});
            });
            //孝心套餐语音监控
            f.$domItemAudioSource.on('ended', function () {
                f.$domItemAudioBtn.removeClass('pause');
            });

            //医生解读回评
            $('#pageBack').click(function (e) {
                if (f.isShowReview == 1) {
                    $('#review').removeClass('hidden');
                    shan.tools.statisticsPing("190012");
                    return false;
                }
            });

            $('#review').on('click', '.close', function () {
                $('#review').addClass('hidden');
            });

            //语音评价页面
            $("#hasHelp").click(function () {
                window.location.href = "/sz/report/goodcomment/orderCode/" + orderCode;
            });
            $("#hasNohelp").click(function () {
                window.location.href = "/sz/report/badcomment/orderCode/" + orderCode;
            });

            $('#unscrambleComprehensive,#unscrambleHelp').children('li').click(function () {
                var _index = $(this).index(),
                    $_domLi = $(this).parent().children('li'),
                    _len = $_domLi.length;
                for (var i = 0; i < _len; i++) {
                    if (i <= _index) {
                        $($_domLi[i]).addClass('cur');
                    }
                    else {
                        $($_domLi[i]).removeClass('cur');
                    }
                }
            });

            $('#reviewBtn').click(function () {
                var _unscrambleComprehensive = $('#unscrambleComprehensive').children('.cur').length,
                    _unscrambleHelp = $('#unscrambleHelp').children('.cur').length;
                shan.tools.statisticsPing("190013");
                shan.ajax({
                    data: {
                        url: '/reportmedia/updateReportMedia.htm',
                        orderCode: orderCode,
                        unscrambleComprehensive: _unscrambleComprehensive,
                        unscrambleHelp: _unscrambleHelp
                    },
                    success: function (_json) {
                        console.log(_json)
                        $('#review').addClass('hidden');
                    }
                });
            });

            //展开孝心异常语音
            $('.abnormal.has-radio').find('.status').click(function () {
                if ($(this).parents('.abnormal.has-radio').hasClass('show')) {
                    $(this).parents('.abnormal.has-radio').removeClass('show');
                    shan.tools.statisticsPing("190016");
                }
                else {
                    $(this).parents('.abnormal.has-radio').addClass('show');
                    shan.tools.statisticsPing("190015");
                }
            });


            //点击快问图标
            //var $fastAsk = $('#fast_ask').draggabilly();
            /*$fastAsk.on('staticClick',function(event,pointer){
             window.location.href = '/sz/order/fast_ask?orderSource=2&orderCode=' + orderCode;
             shan.tools.statisticsPing("250020");
             });*/
        }
    };

    var run = function () {
        f.init();
        f.showReport();
        f.bindEvent();
    };

    //初始化函数
    exports.run = run;
});

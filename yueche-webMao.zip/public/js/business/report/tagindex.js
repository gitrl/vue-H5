define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/fastclick');
    require('lib/szCarousel');
    var szAudio = require('lib/sz-audio');
    var orderCode = shan.tools.getUrlParam("orderCode");
    var opt = {
        ele: $('#szAudio').get(0),
        min: 0,
        step: 1,
        firstPingID: '190019',
        secondPingID: '190020',
        thirdPingID: '190021',
        audioDuration:Math.ceil(parseFloat($('#api-audio-duration').val()))
    };

    var f = {
        isAudioShow: false,
        isShowReview: true,
        urls: [],
        $domPdfBox: $('#pdfBox'),
        init: function () {
            $(function () {
                FastClick.attach(document.body);

                    try {
                        f.showReport();

                            f.$domPdfBox.swipeSlide({
                                continuousScroll: false,
                                speed: 500,
                                transitionType: 'cubic-bezier(0.22, 0.69, 0.72, 0.88)',
                                firstCallback: function (i, sum, me) {
                                    $('#pageNum').text(i + 1);
                                },
                                callback: function (i, sum, me) {
                                    $('#pageNum').text(i + 1);
                                },
                                autoSwipe: false,
                                lazyLoad:true
                            });

                        f.urls = f.getUrls();
                    }
                    catch (e) {
                        pop.alert("初始化失败!", function () {
                            window.location.replace("/user-report-list.php");
                        });
                        return;
                    }

            });

        },
        showReport: function () {
            var _self = this;

            if ($('#audioFlexBoxInit').length>0) {
                var _audio = szAudio.init(opt);
            }

            if ($('.audio-btn').length > 0) {
                $('.audio-btn').on('click', function () {
                    shan.tools.statisticsPing("190022");
                    if ($(this).hasClass('pause')) {
                        //shan.tools.statisticsPing("190018");
                        _self.$domItemAudioSource.get(0).pause();
                        _self.$domItemAudioSource.get(0).currentTime = 0;
                        $(this).removeClass('pause');
                    }
                    else {
                        //shan.tools.statisticsPing("190017");
                        if ($(this).data('src') != _self.$domItemAudioSource.attr('src')) {
                            _self.$domItemAudioSource.attr('src', $(this).data('src'));
                        }
                        _self.$domItemAudioSource.get(0).currentTime = 0;
                        _self.$domItemAudioSource.get(0).play();
                        _self.$domItemAudioBtn = $(this);
                        if (_self.$domItemAudioSource.get(0).networkState == '0' || _self.$domItemAudioSource.get(0).networkState == '3') {
                            setTimeout(function () {
                                _self.$domItemAudioSource.get(0).play();
                                $('.audio-btn').removeClass('pause');
                                _self.$domItemAudioBtn.addClass('pause');
                            }, 0);
                        }
                        else {
                            $('.audio-btn').removeClass('pause');
                            _self.$domItemAudioBtn.addClass('pause');
                        }
                    }
                });
                if (!f.isAudioShow) {
                    shan.tools.statisticsPing("190014");
                    f.isAudioShow = true;
                }
            }

        },
        getImgUrl: function (cur, id, mcode, mtoken, sign) {
            var url = 'https://asgard.shanzhen.me/reportimg/getimg.htm?memberCode=' + mcode + '&szMemberToken=' + mtoken + '&f=' + id + '&n=' + cur + '&sign=' + sign;
            return url;
        },
        getUrls: function () {
            var id = f.$domPdfBox.find('ul').attr('data-id'),
                mcode = f.$domPdfBox.find('ul').attr('data-mcode'),
                mtoken = f.$domPdfBox.find('ul').attr('data-mtoken'),
                sign = f.$domPdfBox.find('ul').attr('data-sign'),
                length = f.$domPdfBox.find('ul').attr('data-num'),
                urls = [];
            for (var i = 1; i <= length; i++) {
                urls.push(f.getImgUrl(i, id, mcode, mtoken, sign));
            }
            return urls;
        },
        previewImage: function (cur, urls, config) {
            var apiList = ['previewImage'];
            if (!config) config = {};

            var _config = {
                debug: false,
                appId: 'wx702d948d6b468b97',
            };

            $.extend(_config, config);
            // 注入设置
            wx.config(_config);
            wx.ready(function () {
                wx.checkJsApi({
                    jsApiList: apiList,
                    success: function (res) {
                        wx.previewImage({
                            current: cur,
                            urls: urls
                        });
                    }
                });
            });
        },

        bindEvent: function () {
            var _self = this;

            $("#prevBtn").click(function () {
                shan.tools.statisticsPing("190001", {mainId: orderCode});
            });
            $("#nextBtn").click(function () {
                shan.tools.statisticsPing("190002", {mainId: orderCode});
            });

            $('.pdfLi').click(function () {
                var cur = $(this).data('cur'),
                    id = f.$domPdfBox.find('ul').attr('data-id'),
                    mcode = f.$domPdfBox.find('ul').attr('data-mcode'),
                    mtoken = f.$domPdfBox.find('ul').attr('data-mtoken'),
                    sign = f.$domPdfBox.find('ul').attr('data-sign'),
                    curUrl = f.getImgUrl(cur, id, mcode, mtoken, sign);
                f.previewImage(curUrl, f.urls, {timestamp: g_timestamp, nonceStr: g_nonceStr, signature: g_signature});
            });


            //点击播放按钮
            $('#playBtn, #playBtn_1').on('click', function (e) {
                shan.tools.statisticsPing("190009", {mainId: orderCode});
            });


            //医生解读回评
            $('#pageBack').click(function (e) {
                if ($('#review').length == 1 && f.isShowReview) {
                    $('#review').removeClass('hidden');
                    shan.tools.statisticsPing("190012");
                    f.isShowReview = false;
                    $('#review').on('click', '.close', function () {
                        $('#review').addClass('hidden');
                    });
                    return false;
                }
            });

            $('#unscrambleComprehensive,#unscrambleHelp').children('li').click(function () {
                var _index = $(this).index(),
                    $_domLi = $(this).parent().children('li'),
                    _len = $_domLi.length,
                    i;
                for (var i = 0; i < _len; i++) {
                    if (i <= _index) {
                        $($_domLi[i]).addClass('cur');
                    }
                    else {
                        $($_domLi[i]).removeClass('cur');
                    }
                }
            });

            $('#reviewBtn').click(function () {
                var _unscrambleComprehensive = $('#unscrambleComprehensive').children('.cur').length,
                    _unscrambleHelp = $('#unscrambleHelp').children('.cur').length;
                shan.tools.statisticsPing("190013");
                shan.ajax({
                    data: {
                        url: '/reportmedia/updateReportMedia.htm',
                        orderCode: orderCode,
                        unscrambleComprehensive: _unscrambleComprehensive,
                        unscrambleHelp: _unscrambleHelp
                    },
                    success: function (_json) {
                        $('#review').addClass('hidden');
                    }
                });
            });

            //蒙版
            $('#tagWatched').click(function(){
                $(this).addClass('hidden');
                shan.tools.statisticsPing("190023");
            });


        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
        shan.tools.statisticsPing("190000", {mainId: orderCode});
    }

    //初始化函数
    exports.run = run;
});

define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/vue/vue.min');
    require('lib/fastclick');
    var orderCode = shan.tools.getUrlParam("orderCode");

    var f = {
        init: function () {
            $(function () {
                FastClick.attach(document.body);
            });

        }
    };

    var commentList = {
                "1": [],
                "2": [],
                "3": [],
                "4": [],
                "5": []
            };

    var comment = new Vue({
        el: "#comment",
        data: {
            score: 0,
            commentModel: "",
            orderCode: orderCode,
            isSending: false,
            commentTemplate: {},
            isSelected: false,
            selComment: {
                "1": [],
                "2": [],
                "3": [],
                "4": [],
                "5": []
            }
        },
        created: function(){
            try{
                //g_commentList = '[{"createTime":"2017-01-18 12:00:00","evaluateBizType":"001","evaluateCode":"3","evaluateItemList":{"0010010301":"语音无法播放","0010010302":"环境嘈杂听不清","0010010303":"态度有问题"},"evaluateName":"评价详情","evaluateType":"001","id":7,"status":1,"updateTime":"2017-01-18 12:00:00"}]';
                var obj = JSON.parse(g_commentList);

                for(key in obj){
                    var item = obj[key],
                        evaluateStarCode = item.evaluateCode,
                        itemList = item.evaluateItemMap,
                        comment = {};
                    
                    for(commentCode in itemList){
                        comment[commentCode] = false;
                    }

                    commentList[evaluateStarCode].push(item);
                    this.selComment[evaluateStarCode].push(comment);
                }
                
            }
            catch(e){}
            
        },
        methods: {
            setScore: function(score){
                this.isSelected = true;
                this.score = score;
                this.commentTemplate = commentList[score];
            },
            getComment: function(code){
                try{
                    var codeArr = code.split("_"),
                        evaluateCode = codeArr[0],
                        index = codeArr[1],
                        itemCode = codeArr[2];

                    if(typeof this.selComment[evaluateCode][index][itemCode] == "undefined"){
                        return;
                    }
                    
                }catch(e){}
                
                if(this.selComment[evaluateCode][index][itemCode]){
                    this.selComment[evaluateCode][index][itemCode] = false;
                }
                else{
                    this.selComment[evaluateCode][index][itemCode] = true;
                }
            },
            getValueViewBoList: function(){
                var valueViewBoList = [],
                    commentArr = commentList[this.score],
                    selList = this.selComment[this.score];

                for(index in selList){
                    var obj = {
                        "evaluateCode": this.score,
                        "evaluateItemMap": {}
                    }
                    for(itemCode in selList[index]){
                        if(selList[index][itemCode]){
                            obj.evaluateItemMap[itemCode] = commentArr[index]["evaluateItemMap"][itemCode];
                        }
                    }
                    valueViewBoList.push(obj);
                }
                
                //用户手写意见
                var obj = {
                    "evaluateCode": 6,
                    "evaluateItemMap": {}
                }
                obj.evaluateItemMap["0010010601"] = this.commentModel.replace(/'|"/g,'');
                valueViewBoList.push(obj);

                return JSON.stringify(valueViewBoList);
            },
            commit: function(){
                try{
                    if(this.commentModel.length != 0){
                        this.isSelected = true;
                    }
                    if(!this.isSelected){
                        pop.alert("请填写反馈意见再提交");
                        return;
                    }
                    var valueViewBoList = this.getValueViewBoList();
                    
                }catch(e){
                    return;
                }

                this.isSending = true;
                shan.ajax({
                    url: "/sz/report/commentsave",
                    data: {
                        orderCode: orderCode,
                        valueViewBoList: valueViewBoList,
                        evaluateType: "001"
                    },
                    success : function(_json){
                        comment.isSending = false;
                        if(_json.SZ_HEAD.RESP_CODE == 'S0000'){
                            pop.alert("提交成功");
                            window.location.href = "/sz/user/reportlist";
                        }
                        else{
                            pop.alert(_json.SZ_HEAD.RESP_MSG);
                        }
                    }
                });
            }
        }
    });
    
    var run = function () {
        f.init();
    }

    //初始化函数
    exports.run = run;
});

define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('/static/js/lib/shan_base');
    var pop = require('/static/js/lib/dialog');

    var orderCode = shan.tools.getUrlParam("orderCode");
    var serviceCode = shan.tools.getUrlParam("serviceCode");
    var number = shan.tools.getUrlParam("number");
    var price = shan.tools.getUrlParam("price");
    var define = {
        "BLOOD_GLUCOSE_PKG_A_BACK" : "301016",
        "BLOOD_GLUCOSE_PKG_B_BACK" : "301017",
        "BLOOD_GLUCOSE_METER_BACK" : "301018",
        "BLOOD_GLUCOSE_PKG_A_NEXT" : "301019",
        "BLOOD_GLUCOSE_PKG_B_NEXT" : "301020",
        "BLOOD_GLUCOSE_METER_NEXT" : "301021",
        "BLOOD_PRESSURE_METER_BACK" : "301037",
        "HYPERTENSION_BACK" : "301038",
        "HIGH_BLOOD_LIPID_BACK" : "301039",
        "BLOOD_PRESSURE_METER_NEXT" : "301040",
        "HYPERTENSION_NEXT" : "301041",
        "HIGH_BLOOD_LIPID_NEXT" : "301042"
    };
    
    var _self = {};
    var f = {
    	init : function(){
            _self.memberName = "",
            _self.memberPhone = "",
            _self.addressId = "",
            _self.addressDetail = "";

            if(!number || number * 1 <= 0){
                pop.alert("产品订单数量有误", function(){
                    history.back();
                    return false;
                });
            }
            $(".c_mainPrice").text("￥" + price * number);
    		shan.ajax({
                data : {
                    url : "/szreportorder/member_address.htm"
                },
                success: function(json){
                    if(json &&json.SZ_HEAD && json.SZ_HEAD.RESP_CODE == "S0000"){
                        if(json && json.SZ_BODY && json.SZ_BODY.MEMBER_ADDRESS_D){
                            f.showAddress(json.SZ_BODY.MEMBER_ADDRESS_D);
                        }
                    }
                    else{
                        pop.alert("获取商品详情失败!");
                    }
                }
            });
    	},
        showAddress : function(data){
            console.log(data);
            $(".c_doing").text("当前收货地址");
            $(".c_name").val(data.memberName || "");
            $(".c_phone").val(data.memberPhone || "");
            $(".c_address").val(data.addressDetail || "");              
            _self.addressId = data.addressId;
        },
        bindEvent : function(){
            $(".c_pageBack").bind("click",function(){
                shan.tools.statisticsPing(define[serviceCode+"_BACK"]);
                history.back();
                return false;
            });
            $(".c_next").bind("click", function(){
                shan.tools.statisticsPing(define[serviceCode+"_NEXT"]);
                f.pay();
            });
        },
        checkFillIn : function(){
            if($(".c_name").val() == ""){
                pop.alert("请填写收货人姓名");
                return true;
            }
            _self.memberName = $(".c_name").val();
            var phone = $(".c_phone").val();
            if(phone == "" || !(/^1\d{10}/.test( phone ))){
                pop.alert("请填写正确的收货人手机号码");
                return true;
            }
            _self.memberPhone = phone;
            if($(".c_address").val().length == 0){
                pop.alert("请填写收货人地址");
                return true;
            }
            _self.addressDetail = $(".c_address").val();
            return false;
        },
        pay : function(){
            if(f.checkFillIn()){
                return;
            }

            shan.ajax({
                data : {
                    url : "/szorder/nplaceorder.htm",
                    examOrderCode : orderCode,
                    personCount : number,
                    serviceCode : serviceCode,
                    addressId : _self.addressId,
                    memberName : _self.memberName,
                    memberPhone : _self.memberPhone,
                    addressDetail : _self.addressDetail
                },
                type : "post",
                success: function(json){
                    if(json &&json.SZ_HEAD && json.SZ_HEAD.RESP_CODE == "S0000" && json.SZ_BODY.N_ORDER_D){
                        window.location.href = "/sz-pay.php?orderCode="+json.SZ_BODY.N_ORDER_D.orderCode;
                    }
                    else{
                        pop.alert("下单失败");
                    }
                }
            });
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});
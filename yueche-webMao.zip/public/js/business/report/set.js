define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/mustache');
    var orderCode = shan.tools.getUrlParam("orderCode");
    var imgMap = {
                BLOOD_GLUCOSE_PKG_A : 'product/product-a.png',
                BLOOD_GLUCOSE_PKG_B : 'product/product-b.png',
                BLOOD_GLUCOSE_METER : 'product/product-1.png',
                BLOOD_PRESSURE_METER : "product/product-2.png",
                HYPERTENSION : "product/product-5.png",
                HIGH_BLOOD_LIPID : "product/product-5.png"
            };
    var defineRelease = {
        "BLOOD_GLUCOSE_PKG_A":301043,
        "BLOOD_GLUCOSE_PKG_B":301044,
        "BLOOD_GLUCOSE_METER":301045, //血糖仪
        "BLOOD_PRESSURE_METER":301046, //血压计
        "HIGH_BLOOD_LIPID":301047, //血脂
        "HYPERTENSION":301048
    };

    var f = {
        init: function () {
            try{
                f.getReportDetail(orderCode);
                //shan.tools.statisticsPing(301051);
            }
            catch(e){
                pop.alert("解析失败!",function(){
                    window.location.replace("/user-report-list.php");  
                });
                return;
            }
        },
        getReportDetail : function(orderCode){
            if(typeof orderCode == "undefined"){
                return;
            }
            shan.ajax({
                data : {
                    url : "/szreport/abnormal_summary.htm",
                    orderCode : orderCode
                },
                success: function(json){
                    if(json &&json.SZ_HEAD && json.SZ_HEAD.RESP_CODE == "S0000"){
                        f.showItemList(json.SZ_BODY);
                    }
                    else{
                        pop.alert("获取体检项目列表失败!");
                    }
                }
            });
        },
        getDetailStyle2 : function(itemList, itemId){
            if(typeof itemList.isNormal == "undefined"
                || typeof itemList.iSubId == "undefined"
                || typeof itemList.szName == "undefined"
                || typeof itemList.szSuggest == "undefined"
                || typeof itemList.szExamVaule == "undefined"){
                return "";
            }
            var s = "",
                hasExplain = "";
                if(itemList.abnormalExplain == ""){
                    hasExplain = "hidden";
                }
                
                s += '<li><div class="result pb16">\
                            <span class="f15 fl">'+itemList.szName+'</span>\
                            <span class="text-gray fl">'+itemList.szSuggest+'</span>\
                            <span class="text-red fr">'+itemList.szExamVaule+'</span>\
                        </div>\
                        <div class="explanation '+hasExplain+'">\
                            <h4 class="pt15 pb15"><label>异常解读</label></h4>\
                            <p class="text-gray">'+itemList.abnormalExplain+'</p>\
                            <ul class="service-list">\
                                '+f.getRelase(itemList)+'\
                            </ul>\
                        </div></li>';
            return s;
        },
        getDetailStyle1:function(itemList, itemId){
            if(typeof itemList.isNormal == "undefined"
                || typeof itemList.iSubId == "undefined"
                || typeof itemList.szName == "undefined"
                || typeof itemList.szExamVaule == "undefined"){
                return "";
            }
            var s = "",
                hasExplain = "";
            if(itemList.abnormalExplain == ""){
                hasExplain = "hidden";
            }
            s += '<li><div class="result pb16">\
                        <h3 class="f15 mb10">'+itemList.szName+'</h3>\
                        <p class="text-gray">'+itemList.szExamVaule+'</p>\
                    </div>\
                    <div class="explanation '+hasExplain+'">\
                        <h4 class="pt15 pb15"><label>异常解读</label></h4>\
                        <p class="text-gray">'+itemList.abnormalExplain+'</p>\
                        <ul class="service-list">\
                            '+f.getRelase(itemList)+'\
                        </ul>\
                    </div></li>';

            return s;
        },
        getRelase: function(itemList){
            var s = "";
            if(typeof itemList.serviceInfoList == "undefined"){
                return s;
            }
            $.each(itemList.serviceInfoList,function(i, item){
                s += '<li class="clickable">\
                        <a class="btn_release" href="javascript:;" data-i="'+item.serviceCode+'">\
                            <img src="/static/images/report/'+imgMap[item.serviceCode]+'"/>\
                            <span>'+item.serviceName+'</span>\
                        </a>\
                    </li>';
            });
                
            return s;
        },
        getDetail : function(){
            var s = "",
                itemCode = this.itemCode;
            $.each(this.reportItemInfoBo, function(index,itemList){
                if(itemList.type == 1){//文字
                    s += f.getDetailStyle1(itemList ,itemCode);
                }
                else{ //进度条
                    s += f.getDetailStyle2(itemList, itemCode);
                }
            });
            return s;
        },
        showItemList: function(data){
            $(".c_total").text("异常指标解读("+data.abnormalCount+")");
            $.each(data.list,function(i,item){
                if(typeof this.szName == "undefined" || this.szName == ""){
                    return true;
                }
                var tpl = '<section class="sz-list mt10 pb13">\
                                <h2 class="label">{{szName}}</h2>\
                                <div class="sz-list-body">\
                                    <ul>{{&getDetail}}</ul>\
                                </div>\
                            </section>';

                item.getDetail = f.getDetail;
                $(".c_reportList").append(Mustache.render(tpl, item));
            });
            f.bindEvent();
        },
        bindEvent: function(){
            $(".btn_site").bind("click",function(e){
                var i = $(this).attr("data-i"),
                    u = $(this).attr("data-u");
                shan.tools.statisticsPing(defineIndex[u]);
                $(".flex").animate({scrollTop: $("#site_"+i).offset().top+"px"}, 700,"swing");
            });
            
            $(".btn_detail").on("click",function(){
                var activeId = $(this).attr("data-i"),
                    iSubId = $(this).attr("data-s");
                shan.tools.statisticsPing(activeId);
                window.location.replace("/sz/report/reportitem/itemCode/"+iSubId
                    +"/sourceCode/"+activeId.substring(0,activeId.length-1)+"/src/"+2+'/orderCode/'+orderCode);
            });

            $(".btn_release").on("click",function(){
                var serviceCode = $(this).attr("data-i");

                shan.tools.statisticsPing(defineRelease[serviceCode]);
                window.location.replace("/sz/product/product/serviceCode/"+serviceCode+"/orderCode/"+orderCode);
            });
        }
    };

    var run = function () {
        f.init();
        
        $(".c_pageBack").bind("click",function(){
            history.back();
            return false;
        });
    }

    //初始化函数
    exports.run = run;
});

define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    require('lib/draggabilly.pkgd.min');
    var orderCode = shan.tools.getUrlParam("orderCode");
    var f = {
    	init : function(){
            shan.tools.statisticsPing("190025");
            /*var $fastAsk = $('#fast_ask').draggabilly();
            $fastAsk.on('staticClick',function(event,pointer){
                window.location.href = '/sz/order/fast_ask?orderSource=2&orderCode=' + orderCode;
                shan.tools.statisticsPing("250021");
            });*/
        }
    };
    var run = function () {
        f.init();
    };
    //初始化函数
    exports.run = run;
});
define(function (require, exports, module) {
    var f = {
    	init : function(){},
        bindEvent : function(){},
    };
    var run = function () {
        f.init();
        f.bindEvent();
    }
    //初始化函数
    exports.run = run;
});
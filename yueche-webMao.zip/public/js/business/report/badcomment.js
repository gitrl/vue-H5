define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/vue/vue.min');
    require('lib/fastclick');
    var orderCode = shan.tools.getUrlParam("orderCode");

    var f = {
        init: function () {
            $(function () {
                FastClick.attach(document.body);
            });

        }
    };

    var commentList = [];

    var comment = new Vue({
        el: "#comment",
        data: {
            commentModel: "",
            orderCode: orderCode,
            isSending: false,
            commentTemplate: [],
            isSelected: false,
            selComment: []
        },
        created: function(){
            try{
                var obj = JSON.parse(g_commentList);

                for(key in obj){
                    var item = obj[key],
                        evaluateStarCode = item.evaluateCode,
                        itemList = item.evaluateItemMap,
                        comment = {};
                    
                    for(commentCode in itemList){
                        comment[commentCode] = false;
                    }

                    commentList.push(item);
                    this.selComment.push(comment); 
                }
                this.commentTemplate = commentList;
            }
            catch(e){} 
        },
        methods: {
            setScore: function(score){
                this.isSelected = true;
                this.score = score;
                this.commentTemplate = commentList[score];
            },
            getComment: function(code){
                try{
                    var codeArr = code.split("_"),
                        index = codeArr[0],
                        itemCode = codeArr[1];

                    if(typeof this.selComment[index][itemCode] == "undefined"){
                        return;
                    }
                    
                }catch(e){}
                
                if(this.selComment[index][itemCode]){
                    this.selComment[index][itemCode] = false;
                }
                else{
                    this.selComment[index][itemCode] = true;
                }
            },
            getValueViewBoList: function(){
                var valueViewBoList = [],
                    commentArr = commentList,
                    selList = this.selComment;

                for(index in selList){
                    var obj = {
                        "evaluateCode": "",
                        "evaluateItemMap": {}
                    }
                    for(itemCode in selList[index]){
                        if(selList[index][itemCode]){
                            obj.evaluateCode = commentArr[index]["evaluateCode"];
                            obj.evaluateItemMap[itemCode] = commentArr[index]["evaluateItemMap"][itemCode];
                        }
                    }
                    //用户手写意见
                    obj.evaluateItemMap["0010020301"] = this.commentModel.replace(/'|"/g,'');
                    valueViewBoList.push(obj);
                }
                //用户手写意见
                var obj = {
                    "evaluateCode": "00100203",
                    "evaluateItemMap": {}
                }
                obj.evaluateItemMap["0010020301"] = this.commentModel.replace(/'|"/g,'');
                valueViewBoList.push(obj);

                return JSON.stringify(valueViewBoList);
            },
            commit: function(){
                try{
                    if(this.commentModel.length != 0){
                        this.isSelected = true;
                    }
                    if(!this.isSelected){
                        pop.alert("请填写反馈意见再提交");
                        return;
                    }
                    var valueViewBoList = this.getValueViewBoList();

                }catch(e){
                    return;
                }

                this.isSending = true;
                shan.ajax({
                    url: "/sz/report/commentsave",
                    data: {
                        orderCode: orderCode,
                        valueViewBoList: valueViewBoList,
                        evaluateType: "002"
                    },
                    success : function(_json){
                        comment.isSending = false;
                        if(_json.SZ_HEAD.RESP_CODE == 'S0000'){
                            pop.alert("提交成功");
                            window.location.href = "/sz/user/reportlist";
                        }
                        else{
                            pop.alert(_json.SZ_HEAD.RESP_MSG);
                        }
                    }
                });
            }
        }
    });
    
    var run = function () {
        f.init();
    }

    //初始化函数
    exports.run = run;
});

/**
 * Created by wayyue05 on 2017/3/1.
 */
define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    require('lib/fastclick');
    require('lib/swiper.min.js');
    var szAudio = require('lib/sz-audio');

    var f = {
        init: function () {
            $(function () {
                FastClick.attach(document.body);
                szAudio.init({
                    ele: $('#szAudio1').get(0),
                    min: 0,
                    step: 1,
                    firstPingID: '130008',
                    thirdPingID: '130009',
                    palyDuration: '.palyDuration1',
                });
                var _self = this;
                _self.$domItemAudioSource = $('#itemAudioSource');
                $('.audio-area').find(".audio-play-btn").on('click', function () {

                    if ($(this).hasClass('pause')) {
                        _self.$domItemAudioSource.get(0).pause();
                        _self.$domItemAudioSource.get(0).currentTime = 0;
                        $(this).removeClass('pause');
                    }
                    else {
                        if($('#szAudio1').find('.audio-play-btn').hasClass('pause')){
                            $('#szAudio1').find('.audio-play-btn').click();
                        }

                        $('.audio-area').find(".audio-play-btn").removeClass('pause');
                        if ($(this).data('src') != _self.$domItemAudioSource.attr('src')) {
                            _self.$domItemAudioSource.attr('src', $(this).data('src')+"?_"+Math.random());
                        }
                        _self.$domItemAudioSource.get(0).currentTime = 0;
                        _self.$domItemAudioSource.get(0).play();
                        _self.$domItemAudioBtn = $(this);
                        if (_self.$domItemAudioSource.get(0).networkState == '0' || _self.$domItemAudioSource.get(0).networkState == '3') {
                            setTimeout(function () {
                                _self.$domItemAudioSource.get(0).play();
                                $('.audio-btn').removeClass('pause');
                                _self.$domItemAudioBtn.addClass('pause');

                            }, 0);

                        }
                        else {
                            $('.audio-btn').removeClass('pause');
                            _self.$domItemAudioBtn.addClass('pause');
                        }
                    }

                });
            });
            var swiper1 = new Swiper('.swiper-container1', {
                pagination: '.swiper-pagination',
                slidesPerView: 'auto',
                centeredSlides: true,
                paginationClickable: true,
                spaceBetween: 10
            });
            $('#check-1').on('click',function(e){
                swiper1.slideTo(2, 500, false);
            });
            var swiper2 = new Swiper('.swiper-container2', {
                pagination: '.swiper-pagination',
                slidesPerView: 'auto',
                centeredSlides: true,
                paginationClickable: true,
                spaceBetween: 10
            });
            $('#check-2').on('click',function(e){
                swiper2.slideTo(2, 500, false);
            });
            var swiper3 = new Swiper('.swiper-container3', {
                pagination: '.swiper-pagination',
                slidesPerView: 'auto',
                centeredSlides: true,
                paginationClickable: true,
                spaceBetween: 10
            });
            var swiper4 = new Swiper('.swiper-container4', {
                pagination: '.swiper-pagination',
                slidesPerView: 'auto',
                centeredSlides: true,
                paginationClickable: true,
                spaceBetween: 10
            });
            $('#check-4').on('click',function(e){
                swiper4.slideTo(2, 500, false);
            });
            var swiper5 = new Swiper('.swiper-container5', {
                pagination: '.swiper-pagination',
                slidesPerView: 'auto',
                centeredSlides: true,
                paginationClickable: true,
                spaceBetween: 10
            });
            $('#check-5').on('click',function(e){
                swiper5.slideTo(2, 500, false);
            });

            var w = window,
                $window = $(w),
                defaultOptions = {
                    threshold: -200,
                    failure_limit: 0,
                    event: 'scroll',
                    effect: 'show',
                    effect_params: null,
                    container: w,
                    appear: emptyFn,
                    load: emptyFn,
                    vertical_only: false,
                    check_appear_throttle_time: 300,
                    url_rewriter_fn: emptyFn,
                    no_fake_img_loader: false,
                    ping: emptyFn
                },
                type; // function


            function emptyFn() {
            }

            type = (function () {
                var object_prototype_toString = Object.prototype.toString;
                return function (obj) {
                    // todo: compare the speeds of replace string twice or replace a regExp
                    return object_prototype_toString.call(obj).replace('[object ', '').replace(']', '');
                }
            })();

            function belowthefold($element, options) {
                var fold;
                if (options._$container == $window) {
                    fold = ('innerHeight' in w ? w.innerHeight : $window.height()) + $window.scrollTop();
                } else {
                    fold = options._$container.offset().top + options._$container.height();
                }
                return fold <= $element.offset().top - options.threshold;
            }

            function rightoffold($element, options) {
                var fold;
                if (options._$container == $window) {
                    // Zepto do not support `$window.scrollLeft()` yet.
                    fold = $window.width() + ($.fn.scrollLeft ? $window.scrollLeft() : w.pageXOffset);
                } else {
                    fold = options._$container.offset().left + options._$container.width();
                }
                return fold <= $element.offset().left - options.threshold;
            }

            function abovethetop($element, options) {
                var fold
                if (options._$container == $window) {
                    fold = $window.scrollTop()
                } else {
                    fold = options._$container.offset().top
                }
                // console.log('abovethetop fold '+ fold)
                // console.log('abovethetop $element.height() '+ $element.height())
                return fold >= $element.offset().top + options.threshold + $element.height()
            }

            function leftofbegin($element, options) {
                var fold
                if (options._$container == $window) {
                    // Zepto do not support `$window.scrollLeft()` yet.
                    fold = $.fn.scrollLeft ? $window.scrollLeft() : w.pageXOffset
                } else {
                    fold = options._$container.offset().left
                }
                return fold >= $element.offset().left + options.threshold + $element.width()
            }

            function checkAppear($elements, options) {
                var counter = 0
                $elements.each(function (i, e) {
                    var $element = $elements.eq(i);
                    if (($element.width() <= 0 && $element.height() <= 0) || $element.css('display') === 'none') {
                        return
                    }
                    function appear() {
                        $element.trigger('_ping_');
                        // if we found an image we'll load, reset the counter
                        counter = 0
                    }

                    // If vertical_only is set to true, only check the vertical to decide appear or not
                    // In most situations, page can only scroll vertically, set vertical_only to true will improve performance
                    if (options.vertical_only) {
                        if (abovethetop($element, options)) {
                            // Nothing.
                        } else if (!belowthefold($element, options)) {
                            appear();
                        } else {
                            if (++counter > options.failure_limit) {
                                return false;
                            }
                        }
                    } else {
                        if (abovethetop($element, options) || leftofbegin($element, options)) {
                            // Nothing.
                        } else if (!belowthefold($element, options) && !rightoffold($element, options)) {
                            appear();
                        } else {
                            if (++counter > options.failure_limit) {
                                return false;
                            }
                        }
                    }
                })
            }

            // Remove image from array so it is not looped next time.
            function getUnloadElements($elements) {
                return $elements.filter(function (i, e) {
                    return !$elements.eq(i)._lazyload_loadStarted;
                })
            }

            // throttle : https://github.com/component/throttle , MIT License
            function throttle(func, wait) {
                var ctx, args, rtn, timeoutID; // caching
                var last = 0;

                return function throttled() {
                    ctx = this;
                    args = arguments;
                    var delta = new Date() - last;
                    if (!timeoutID)
                        if (delta >= wait) call();
                        else timeoutID = setTimeout(call, wait - delta);
                    return rtn
                }

                function call() {
                    timeoutID = 0;
                    last = +new Date();
                    rtn = func.apply(ctx, args);
                    ctx = null;
                    args = null;
                }
            }

            var init = function (options) {
                var $elements = $(options.el),
                    isScrollEvent,
                    isScrollTypeEvent,
                    throttleCheckAppear;

                if (!$.isPlainObject(options)) {
                    options = {}
                }

                $.each(defaultOptions, function (k, v) {
                    if ($.inArray(k, ['threshold', 'failure_limit', 'check_appear_throttle_time']) != -1) { // these params can be a string
                        if (type(options[k]) == 'String') {
                            options[k] = parseInt(options[k], 10);
                        } else {
                            options[k] = v;
                        }
                    } else if (k == 'container') { // options.container can be a seletor string \ dom \ jQuery object
                        if (options.hasOwnProperty(k)) {
                            if (options[k] == w || options[k] == document) {
                                options._$container = $window;
                            } else {
                                options._$container = $(options[k]);
                            }
                        } else {
                            options._$container = $window;
                        }
                        delete options.container;
                    } else if (defaultOptions.hasOwnProperty(k) && (!options.hasOwnProperty(k) || (type(options[k]) != type(defaultOptions[k])))) {
                        options[k] = v;
                    }
                });

                isScrollEvent = options.event == 'scroll';
                throttleCheckAppear = options.check_appear_throttle_time == 0 ?
                    checkAppear
                    : throttle(checkAppear, options.check_appear_throttle_time);

                // isScrollTypeEvent cantains custom scrollEvent . Such as 'scrollstart' & 'scrollstop'
                isScrollTypeEvent = isScrollEvent || options.event == 'scrollstart' || options.event == 'scrollstop'

                $elements.each(function (i, e) {
                    var element = this,
                        $element = $elements.eq(i),
                        actionId = $element.attr('actionId'),
                        itemId = $element.attr('itemId');

                    //if($element._lazyload_loadStarted == true || placeholderSrc == originalSrc){
                    if ($element._lazyload_loadStarted == true) {
                        $element._lazyload_loadStarted = true;
                        $elements = getUnloadElements($elements);
                        return
                    }

                    // When appear is triggered load original image.
                    $element.one('_ping_', function () {
                        var effectParamsIsArray = $.isArray(options.effect_params),
                            effectIsNotImmediacyShow;

                        if (!$element._lazyload_loadStarted) {
                            effectIsNotImmediacyShow = (options.effect != 'show' &&
                            $.fn[options.effect] && (!options.effect_params || (effectParamsIsArray && options.effect_params.length == 0)))
                            if (options.appear != emptyFn) {
                                options.appear.call(element, $element, $elements.length, options);
                            }
                            $element._lazyload_loadStarted = true;

                            if (options.load != emptyFn) {
                                $element.one('load', function () {
                                    options.load.call(element, $element, $elements.length, options);
                                })
                            }

                            $(this).find('.fei').addClass('animation');
                        }
                    });

                    // When wanted event is triggered load original image
                    // by triggering appear.
                    if (!isScrollTypeEvent) {
                        $element.on(options.event, function () {
                            if (!$element._lazyload_loadStarted) {
                                $element.trigger('_ping_')
                            }
                        })
                    }
                })

                // Fire one scroll event per scroll. Not one scroll event per image.
                if (isScrollTypeEvent) {
                    options._$container.on(options.event, function () {
                        throttleCheckAppear($elements, options)
                    })
                }

                // Force initial check if images should appear.
                $(function () {
                    throttleCheckAppear($elements, options)
                })

                //return this
            };
            var initAnimation = true;
            var playAnimation = function(){
                if(initAnimation){
                    init({
                        container: $(".flex"),
                        el: $(".swiper-container")
                    });
                }
                initAnimation = false;
            };
            playAnimation();


            var options = {
                title: '健康数据中心',
                desc: '2015-2017体检报告',
                imgUrl: "http://m.shanzhen.me/static/images/demo/share.jpg"
            };

            //配置微信分享
            var controller = new wxController();
            controller.init(
                ['onMenuShareTimeline', 'onMenuShareAppMessage'],
                function () {
                    controller.configShareTimeline({
                        title: options.title, // 分享标题
                        desc:  options.desc, // 分享描述
                        imgUrl: options.imgUrl, //分享图标
                        success: function () {
                        },
                        cancel: function () {
                        }
                    });
                    controller.configShareAppMessage({
                        title: options.title, // 分享标题
                        desc:  options.desc, // 分享描述
                        imgUrl: options.imgUrl, //分享图标
                        type: '', // 分享类型,music、video或link，不填默认为link
                        dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
                        success: function () {
                        },
                        cancel: function () {
                        }
                    });
                }
            );



        },
        bindEvent: function () {
            var years = shan.tools.getUrlParam("years");
            var $cervical_abnormal = $('#cervical-abnormal');
            var
                $blood_high = $('#blood-high'),
                $blood_low = $('#blood-low'),
                $hungry_glucose = $('#hungry-glucose'),
                $hemoglobin_glucose = $('#hemoglobin-glucose'),
                $sugar_abnormal_text = $('#sugar-abnormal-text'),
                $cervical_text = $('.cervical-text'),
                $visceral_text = $('.visceral-text'),
                $visceral_text2 = $('.visceral-text2');
            $('.swiper-container1 .years li').eq(years).addClass('active').siblings().removeClass('active');
            $('.swiper-container4 .years li').eq(years).addClass('active').siblings().removeClass('active');
            $('.swiper-container5 .years li').eq(years).addClass('active').siblings().removeClass('active');
            $('.swiper-container1 .items1').addClass('hidden');
            $('.swiper-container1 .items1').eq(years).removeClass('hidden');
            $cervical_text.addClass('hidden');
            $cervical_text.eq(years).removeClass('hidden');
            $visceral_text.addClass('hidden');
            $visceral_text2.addClass('hidden');
            $visceral_text.eq(years).removeClass('hidden');
            $visceral_text2.eq(years).removeClass('hidden');
            if(years != 0){
                $cervical_abnormal.text('1项异常');
            }else{
                $cervical_abnormal.text('2项异常');
            }

            switch (String(years)){
                case '1':
                    $blood_high.text('130');
                    $blood_low.text('80');
                    $sugar_abnormal_text.text('1项异常').addClass('abnormal');
                    $hungry_glucose.text('6.25').addClass('abnormal-num');
                    $hemoglobin_glucose.text('5.78').addClass('normal-num');
                    $cervical_abnormal.text('1项异常');
                    break;
                case '2':
                    $blood_high.text('125');
                    $blood_low.text('75');
                    $sugar_abnormal_text.text('各指标正常').addClass('normal');
                    $hungry_glucose.text('5.88').addClass('normal-num');
                    $hemoglobin_glucose.text('5.10').addClass('normal-num');
                    /*$('#sugar-2').remove();
                    $('#sugar-3').remove();
                    $('#sugar-pagination').remove();
                    $('.swiper-container1 .swiper-slide').eq(0).removeClass('hidden').siblings().remove();
                    $('.swiper-container1 .swiper-pagination').addClass('hidden');*/
                    $cervical_abnormal.text('1项异常');
                    break;
                default :
                    $blood_high.text('140');
                    $blood_low.text('88');
                    $sugar_abnormal_text.text('2项异常').addClass('abnormal');
                    $hungry_glucose.text('6.95').addClass('abnormal-num');
                    $hemoglobin_glucose.text('6.10').addClass('abnormal-num');
                    $cervical_abnormal.text('2项异常');
                    break;

            }
            //年份切换
            $('.swiper-container1 .years li').on('click',function(e){
                $(this).addClass('active').siblings().removeClass('active');
                var index = $(this).index();
                $('.swiper-container1 .items1').addClass('hidden');
                $('.swiper-container1 .items1').eq(index).removeClass('hidden');
            });

            $('.swiper-container4 .years li').on('click',function(e){
                $(this).addClass('active').siblings().removeClass('active');
                var index = $(this).index();
                $visceral_text.addClass('hidden');
                $visceral_text2.addClass('hidden');
                $visceral_text.eq(index).removeClass('hidden');
                $visceral_text2.eq(index).removeClass('hidden');
            });

            $('.swiper-container5 .years li').on('click',function(e){
                $(this).addClass('active').siblings().removeClass('active');
                var index = $(this).index();
                $cervical_text.addClass('hidden');
                $cervical_text.eq(index).removeClass('hidden');
                if(index != 0){
                    $cervical_abnormal.text('1项异常');
                }else{
                    $cervical_abnormal.text('2项异常');
                }
            });



            //点击查看报告
            $('#origin-btn').on('click',function(e){
                window.location.href = "/sz/cooperate/report?year=" + years;
            })

        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    };

    //初始化函数
    exports.run = run;
});
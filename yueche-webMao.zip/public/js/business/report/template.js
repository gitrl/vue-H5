define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/mustache');
    var sourceCode = shan.tools.getUrlParam("sourceCode");
    
    var f = {
        init: function () {
            if(g_data && g_data.SZ_BODY){
                try{
                    f.showReport(g_data.SZ_BODY);
                    f.getReportDetail();
                }
                catch(e){
                    pop.alert("初始化失败!",function(){
                        window.location.replace("/user-report-list.php");  
                    });
                    return;
                }
            }
            else{
                window.location.replace("/user-report-list.php");
            }
        },
        showReport: function(data){
            $(".c_total").text(data.total);
            $(".c_counter").text(data.abnormal);
            $(".c_abnormal").text(data.abnormal);
            $(".c_userName").text(data.examineeName);
            data.examineeGender!="男性"?$(".report-body-detail").addClass("female"):$(".report-body-detail").addClass("male");
            $.each(data.L2_ITEM_D,function(i, item){
                var tpl = '<li class="{{statusType}}"><a href="javascript:;" \
                    class="{{statusAbnormal}} btn_site" data-i="'+item.itemCode+'" data-u="{{isNormal}}">'+item.itemName+'</a></li>';

                item.statusType = function(){
                    var s = "";
                    if(this.isNormal == -1){
                        this.statusAbnormal = "abnormal";
                    }
                    else if(this.isNormal == -2){
                        s = "serious";
                        this.statusAbnormal = "abnormal";
                    }
                    return s;
                }
                if(i%2 == 0){
                    $(".report-item-list.left").append(Mustache.render(tpl, item));
                }else{
                    $(".report-item-list.right").append(Mustache.render(tpl, item));
                }
            });
        },
        getReportDetail : function(){
            shan.ajax({
                url : "/sz/report/grouplist",
                data : {
                },
                success: function(json){
                    if(json &&json.SZ_HEAD && json.SZ_HEAD.RESP_CODE == "S0000"){
                        f.showItemList(json.SZ_BODY);
                    }
                    else{
                        pop.alert("获取体检项目列表失败!");
                    }
                }
            });

        },
        getDetailStyle1 : function(itemList, itemId){
            if(typeof itemList.isNormal == "undefined"
                || typeof itemList.iSubId == "undefined"
                || typeof itemList.szName == "undefined"
                || typeof itemList.szSuggest == "undefined"
                || typeof itemList.szExamVaule == "undefined"){
                return "";
            }
            var s = "",
                isNormal = "normal",
                activeId = "",
                isSerious = "",
                isNormalStyle = '<div class="value-rate"></div>';
                if(itemList.isNormal == "WARNING"){ //严重
                    isSerious = 'serious pr20';
                    isNormalStyle = '<div class="value-rate"></div>';
                    activeId = itemId + "2";
                    isNormal = "abnormal";
                }
                else if(itemList.isNormal == "COMMON" || itemList.isNormal == ""){ //正常和数据为空
                    activeId = itemId + "1";
                }
                else{ //异常
                    isNormal = "abnormal";
                    isNormalStyle = '<div class="value-rate"></div>';
                    activeId = itemId + "0";
                }

                s += '<ul class="flex-list">\
                        <li class="'+isNormal+' clickable">\
                        <a class="clickable-inner text-black btn_detail" data-i="'+activeId+'" data-s="'+itemList.iSubId+'" href="javascript:;">\
                            <div class="item-label text-black f15 '+isSerious +'">'+itemList.szName+'</div>\
                            <div class="gray">'+itemList.szSuggest+'</div>\
                            <div class="item-rate">\
                               '+isNormalStyle+'\
                            </div>\
                            <div class="tr item-value f16" width="25%">'+itemList.szExamVaule+'<i class="yo-ico"></i></div>\
                        </a>\
                        </li></ul>';
            return s;
        },
        getDetailStyle2:function(itemList, itemId){
            if(typeof itemList.isNormal == "undefined"
                || typeof itemList.iSubId == "undefined"
                || typeof itemList.szName == "undefined"
                || typeof itemList.szExamVaule == "undefined"){
                return "";
            }
            var s = "",
                isNormal = "normal",
                activeId = "",
                isSerious = "",
                isNormalStyle = "";
            if(itemList.isNormal == "WARNING"){ //严重
                isSerious = 'serious';
                isNormalStyle = '<span class="item-status value-rate"></span>';
                activeId = itemId + "2";
                isNormal = "abnormal";
            }
            else if(itemList.isNormal == "COMMON" || itemList.isNormal == ""){
                activeId = itemId + "1";
            }
            else{ //异常
                isNormal = "abnormal";
                isNormalStyle = '<span class="item-status value-rate"></span>';
                activeId = itemId + "0";
            }

            s += '<ul class="ul-list"><li class="clickable '+isNormal+'">\
                    <a href="javascript:;" class="text-black btn_detail" data-i="'+activeId+'" data-s="'+itemList.iSubId+'">\
                        <h3 class="'+isSerious+'">'+itemList.szName+'</h3>\
                        <p>'+itemList.szExamVaule+'</p>\
                        '+isNormalStyle+'\
                        <i class="yo-ico"></i>\
                    </a>\
                </li></ul>';
            return s;
        },
        getDetailStyle3: function(itemList, itemId){
            if(typeof itemList.isNormal == "undefined"
                || typeof itemList.iSubId == "undefined"
                || typeof itemList.szName == "undefined"
                || typeof itemList.szExamVaule == "undefined"){
                return "";
            }
            var s = "",
                isNormal = "normal",
                activeId = itemId,
                isSerious = "",
                isNormalStyle = "";
            if(itemList.isNormal == "WARNING"){ //严重
                activeId = itemId + "2";
                isNormal = "abnormal";
                isSerious = 'serious';
            }
            else if(itemList.isNormal == "COMMON" || itemList.isNormal == ""){ //正常和数据为空
                activeId = itemId + "1";
            }
            else{ //异常
                isNormal = "abnormal";
                activeId = itemId + "0";
                isNormalStyle = "value-rate";
            }
            s += '<ul class="ul-list last-border-none f15">\
                    <li class="'+isNormal+' clickable">\
                        <a href="javascript:;" class="text-black btn_detail" data-i="'+activeId+'" data-s="'+itemList.iSubId+'">\
                            <span class="text-black '+isSerious+'">'+itemList.szName+'</span>\
                            <span class="item-status '+isNormalStyle+'">'+itemList.szExamVaule+'</span>\
                            <i class="yo-ico"></i>\
                        </a>\
                    </li></ul>';
            return s;
        },
        getRelase: function(){
            
            var s = "";
            if(typeof this.serviceMap == "undefined"){
                return s;
            }
            for(serviceCode in this.serviceMap){
                var szName = this.serviceMap[serviceCode];
                s += '<dd ><a class="tag-list-item btn-default f15 btn_release" href="javascript:;" data-i="'+serviceCode+'">'+szName+'</a></dd>';
            }
            return s;
        },
        getDetail : function(){
            var s = "",
                itemCode = this.itemCode;
            $.each(this.reportItemInfoBo, function(index,itemList){
                if(itemList.type == 1){//文字
                    s += f.getDetailStyle2(itemList ,itemCode);
                }
                else if(itemList.type == 2){//数值
                    s += f.getDetailStyle3(itemList, itemCode);
                }
                else{ //进度条
                    s += f.getDetailStyle1(itemList, itemCode);
                }
                
            });
            return s;
        },
        showItemList: function(data){
            $.each(data.list,function(i,item){
                if(typeof this.szName == "undefined"){
                    return true;
                }
                var tpl = '<section class="sz-list mt10" id="site_'+item.itemCode+'">\
                    <h2 class="label">{{szName}}</h2>\
                    <ul class="flex-list">\
                        {{&getDetail}}\
                    </ul>\
                </section>';
                
                item.getDetail = f.getDetail;
                //item.getRelase = f.getRelase;
                $(".c_reportList").append(Mustache.render(tpl, item));
            });
            f.bindClick();
        },
        bindClick: function(){
            $(".btn_site").bind("click",function(e){
                var i = $(this).attr("data-i"),
                    u = $(this).attr("data-u");
                //shan.tools.statisticsPing(defineIndex[u]);
                $(".flex").animate({scrollTop: $("#site_"+i).offset().top+"px"}, 700,"swing");
            });
            
            $(".btn_detail").on("click",function(){
                var activeId = $(this).attr("data-i"),
                    iSubId = $(this).attr("data-s");
                //shan.tools.statisticsPing(activeId);
                window.location.replace("/sz/report/templateitem/src/1/itemCode/"+iSubId
                    +"/sourceCode/"+activeId.substring(0,activeId.length-1));
            });

            if(sourceCode != ""){
                $(".flex").animate({scrollTop: $("#site_"+sourceCode).offset().top+"px"}, 700,"swing");
            } 
        },
        bindEvent : function(){
            $(".c_top").bind("click",function(){
            $(".flex").animate({scrollTop: "0px"}, 700,"swing");
            });
            $(".c_next").bind("click",function(){
                window.location.replace("/sz/report/templateset");
            });
            
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
        //shan.tools.statisticsPing("301050",{mainId:orderCode});
    }

    //初始化函数
    exports.run = run;
});

define(function (require, exports, module) {
    var $ = require('jquery');
    require('lib/fastclick');

    var f = {
        init: function () {
            $(function () {
                FastClick.attach(document.body);
            });
        },
        bindEvent: function () {
            $("#backTop").click(function(){
                $(".flex").animate({scrollTop: "0px"}, 700,"swing");
            });
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});

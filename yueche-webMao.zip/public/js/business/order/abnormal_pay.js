define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/vue/vue.min');
    require('lib/swiper.min');
    require('lib/vue/vue-lazyload');
    require('lib/jquery.tmpl');
    var reportCode = shan.tools.getUrlParam("orderCode");    //报告订单号

    const PAY_HANDLER_WX = 1;

    //兑换卷列表浮层
    var ticketListDialog = pop.layer({
        ele: $('#ticketListDialog'),
        bindEvent: function (layer) {
            layer.ele.find('#couponChooseBtn').off('touchend').on('touchend', function (e) {
                layer.hide();
                e.preventDefault();
            });
        }
    });

    var f = {
        init: function () {
            try{
                var abnormal_items = JSON.parse(g_abnormal_items.replace(/\r\n/g,'<br/>').replace(/\n/g,'<br/>').replace(/\t/g,"").replace( /'/g , "\"" ).replace( /\s+/g , "" )),
                    doctor_list = JSON.parse(g_doctor_list.replace(/\r\n/g,'<br/>').replace(/\n/g,'<br/>')),
                    ticketData = JSON.parse(g_ticket),
                    payData=JSON.parse(g_pay),
                    orderInterpretation = JSON.parse(g_orderInterpretation);
            }catch(e){
                pop.alert("系统繁忙，请稍后再试!", function () {
                    window.location.replace("/sz/report/index?orderCode=" + reportCode);
                });
            }

            //使用懒加载
            Vue.use(VueLazyload, {
                preLoad: 1.3,
                error: '/static/images/ask/icon_logo.png',
                loading: '/static/images/avatar.jpg',
                attempt: 1
            });

            var vm  = new Vue({
                el: '#app',
                data: {
                    showAbnormalCheck: true,    //异常选择页
                    showAbnormalConfirm: false, //异常确认页
                    showConfirmSuccess: false,  //支付成功弹窗
                    showAbnormalDetails: false, //选中的异常项详情
                    isFold: false,   //异常详情收起
                    isUnfold: true,    //异常详情展开
                    doctor_list: doctor_list,   //医生团队列表
                    abnormal_items: abnormal_items, //异常项详情
                    abnormalArr: [],     //选中的异常项详情数组
                    detailIdArr: [],   //选中的异常项id数组
                    orderInterpretation: orderInterpretation,   //报告解读状态
                    textMessage: '',     //用户描述的问题
                    residueNum: 200,      //用户剩余可输入数
                    payPrice: 9.9,   //支付价格
                    orderCode: '',   //提问订单号
                    isSelWx: true,  //是否在微信环境
                    wxInitData: {}, //微信初始化数据
                    isSending: false, //是否正在支付
                    ticketSrc: "/static/images/redPacket/icon_ticket_none.png",//不用使用卷状态下的icon:/static/images/redPacket/icon_ticket.png;/static/images/redPacket/icon_ticket_none.png
                    ticketText: "", //不用使用卷状态下的文字描述:暂无可用券,有X张券可使用,已减免￥XXX
                    hasQuestionTicket: false,//是否有问答券
                    hasRadioTicket: false,//是否有语音券
                    ticketStatusClass: 'noTicket',//noTicket，hasTicket
                    ticketStatusShow: false, //是否展示"请选择券按钮" 仅仅在hasTicket状态下展示
                    isUseTicket: false, //用户是否选择了优惠卷
                    couponIds: "", //用户选择的卷ID
                    ticketAmt: 0, //用户选择的卷面价格
                    ticketDataList: [],//券列表
                    ableTicketCount: 0,//可用券数量
                    needPay: 0,//问答价格
                    isFirstFormatTicket:true,//是否第一次初始化券列表
                },
                computed:{
                    needPayStr: function () {
                        var _temp = ((this.needPay - this.ticketAmt) / 1000);
                        if (_temp <= 0) {
                            return '免费';
                        }
                        else {
                            return '￥'+_temp.toFixed(1);
                        }
                    },
                    isShowAmtStr: function () {
                        if (this.ticketAmt == 0) {
                            return false;
                        }
                        else {
                            return true;
                        }
                    },
                    amtStr: function () {
                        return (this.ticketAmt / 1000).toFixed(1);
                    }
                },
                created: function(){
                    shan.tools.statisticsPing("253001");
                    if(shan.tools.isWeixin() == 0){
                        this.isSelWx = false;
                    }
                    //if (ticketData.SZ_HEAD.RESP_CODE == 'S0000' && ticketData.SZ_BODY.COUPON_EXISTS == 1) {
                    //    this.payPrice = 0;
                    //}
                    if (ticketData.SZ_HEAD.RESP_CODE == 'S0000') {
                        //this.hasFreeTicket = true;
                        //shan.tools.statisticsPing('250012');
                        if (typeof ticketData.SZ_BODY.QUESTION_EQUITY != 'undefined' && ticketData.SZ_BODY.QUESTION_EQUITY.length > 0) {
                            this.hasQuestionTicket = true;
                            this.ticketStatusClass = 'hasTicket';
                            this.ableTicketCount = ticketData.SZ_BODY.QUESTION_EQUITY.length;
                            this.ticketText = '有<span class="text-red">' + this.ableTicketCount + '</span>张券可使用';

                        }
                        else {
                            ticketData.SZ_BODY.QUESTION_EQUITY = [];
                            this.hasQuestionTicket = false;
                            this.ticketStatusClass = 'noTicket';
                            this.ticketText = '暂无可用券';

                        }
                        if (typeof ticketData.SZ_BODY.REPORTINTERPRETATION_EQUITY != 'undefined' && ticketData.SZ_BODY.REPORTINTERPRETATION_EQUITY.length > 0) {
                            this.hasRadioTicket = true;
                        }
                        else {
                            ticketData.SZ_BODY.REPORTINTERPRETATION_EQUITY = [];
                            this.hasRadioTicket = false;
                        }
                        this.ticketDataList = ticketData.SZ_BODY.QUESTION_EQUITY.concat(ticketData.SZ_BODY.REPORTINTERPRETATION_EQUITY);
                    }
                    if(payData.SZ_HEAD.RESP_CODE=='S0000' && typeof payData.SZ_BODY.QUESTION_PRICE !='undefined'){
                        this.needPay=payData.SZ_BODY.QUESTION_PRICE;
                    }
                },
                mounted: function(){
                    var mySwiper = new Swiper ('.swiper-container', {
                        autoplay: 5000,
                        direction: 'vertical',
                        initialSlide: parseInt(Math.random()*19),
                        loop: true
                    });
                },
                methods: {
                    renderTicket: function (list, layer) {
                        if (this.isUseTicket) {
                            list.chooseTicketCode = this.couponIds;
                            list.id = this.couponIds;
                        }
                        layer.ele.find('.red-packet-ticket-list').html("").html($('#dmyTicketList').tmpl(list, {
                            getInput: function (spr) {
                                if (list.chooseTicketCode == this.data.id) {
                                    return '<input type="checkbox" name="project13" checked="checked"/>';
                                } else {
                                    return '<input type="checkbox" name="project13" />';
                                }
                            },
                            formatExpireTime: function (spr) {
                                return this.data.expireTime.substring(0, 10);
                            }
                        }));
                        //选择口令券
                        layer.ele.off('click').on('click', 'li', function () {
                            if (!$(this).hasClass('text-disabled')) {
                                if ($(this).find('input[type="checkbox"]').prop('checked')) {
                                    $(this).find('input[type="checkbox"]').prop('checked', false);
                                    vm.couponIds = "";
                                    vm.ticketAmt = 0;
                                    vm.isUseTicket = false;
                                    vm.ticketText = '有<span class="text-red">' + vm.ableTicketCount + '</span>张券可使用';
                                }
                                else {
                                    if (vm.isUseTicket) {
                                        layer.ele.find('.red-packet-ticket input[type="checkbox"]').attr('checked', false);
                                        vm.couponIds = "";
                                    }
                                    $(this).find('input[type="checkbox"]').prop('checked', true);
                                    vm.isUseTicket = true;
                                    vm.couponIds = $(this).attr('data-code');
                                    vm.ticketAmt = parseInt($(this).attr('data-price'));
                                    vm.ticketText = '已减免￥'+(vm.ticketAmt/1000).toFixed(1);
                                }
                            }
                        });
                    },
                    selTicket: function () {
                        if (this.hasQuestionTicket) { //有优惠券
                            if (this.isFirstFormatTicket) {
                                this.renderTicket(this.ticketDataList, ticketListDialog);
                                this.isFirstFormatTicket=false;
                            }
                            ticketListDialog.show();
                            //shan.tools.statisticsPing("54005");
                        }
                    },
                    checkAbnormal: function(){
                        //限制选项
                        if(this.abnormalArr.length > 2){
                            this.abnormalArr.pop();
                            shan.tools.statisticsPing("253017");
                            if(this.orderInterpretation == 'NONE'){
                                pop.alert('异常解读最多只能选两项，您也可以在报告页选择报告解读~');
                            }else{
                                pop.alert('最多只能选两项哦~');
                            }
                        }
                    },
                    //提交异常项的选择(下一步)
                    submitAbnormal: function(){
                        shan.tools.statisticsPing("253002");
                        if(this.abnormalArr.length > 2){
                            pop.alert('最多只能选两项哦~');
                            return;
                        }
                        if(this.abnormalArr.length == 0){
                            pop.alert('请至少选择一项哦~');
                            return;
                        }
                        this.detailIdArr = this.formatData(this.abnormalArr);
                        this.showAbnormalCheck = false;
                        this.showAbnormalConfirm = true;
                        shan.tools.statisticsPing("253003");
                    },
                    //返回异常项选择页
                    backToAbnormalCheck: function(){
                        this.showAbnormalConfirm = false;
                        this.showAbnormalCheck = true;
                    },
                    //收起展开的开关
                    switchAbnormal: function(){
                        if(this.isUnfold){
                            this.isFold = true;
                            this.isUnfold = false;
                            this.showAbnormalDetails = true;
                            return;
                        }
                        this.isFold = false;
                        this.isUnfold = true;
                        this.showAbnormalDetails = false;
                    },
                    //输入时计算剩余数
                    countMessage: function(){
                        if(this.textMessage.length <= 200){
                            this.residueNum = 200 - this.textMessage.length;
                        }else{
                            this.residueNum = 0;
                        }
                    },
                    //查看订单
                    checkOrder: function(){
                      shan.tools.statisticsPing("253012");
                      window.location.href = '/sz/ask/my_ask_list';
                    },
                    //继续查看报告
                    toReport: function(){
                        shan.tools.statisticsPing("253011");
                    },
                    //提交异常解读
                    submitOrder: function(){
                        shan.tools.statisticsPing("253004");
                        if(!this.textMessage){
                            pop.alert('说点什么，帮助医生更好解答哦~');
                            return;
                        }
                        if(this.textMessage.length > 200){
                            pop.alert('请控制在200字以内哦~');
                            return;
                        }
                        //提交异常项及问题
                        shan.ajax({
                            url: '/sz/order/submit_abnormal_pay_async',
                            type: 'post',
                            data: {
                                questionContent: this.textMessage,
                                abnormalItem: JSON.stringify(this.detailIdArr),
                                orderCodeRelated: reportCode,
                                orderSource: 2,
                                equityId:this.couponIds
                            },
                            success: function(_json){
                                if(_json.SZ_HEAD.RESP_CODE == 'S0000'){
                                    vm.orderCode = _json.SZ_BODY.ORDER_CODE;
                                    if(_json.SZ_BODY.NEED_PAY != '1'){//不需支付,显示弹窗
                                        shan.tools.statisticsPing("253007");
                                        vm.showConfirmSuccess = true;
                                        return;
                                    }
                                    shan.ajax({
                                        url: "/sz/order/wxpay_ask_async",
                                        data: {
                                            orderCode: vm.orderCode
                                        },
                                        success: function (_json) {
                                            if (typeof _json != "undefined" && _json.SZ_HEAD.RESP_CODE == "S0000") {
                                                vm.wxInitData = _json.SZ_BODY.PREPAY_D;
                                                if (typeof wx != 'object') {
                                                    pop.alert("微信支付初始化失败，请重试~");
                                                    return;
                                                }
                                                wx.config({
                                                    appId: vm.wxInitData.appId,
                                                    timestamp: vm.wxInitData.timeStamp,
                                                    nonceStr: vm.wxInitData.nonceStr,
                                                    signature: vm.wxInitData.paySign,
                                                    jsApiList: ["chooseWXPay"]
                                                });
                                                vm.toPay(vm.orderCode);
                                            }else {
                                                pop.message.show('微信支付失败，请检查网络环境~');
                                            }
                                        }
                                    });
                                }else{
                                    pop.alert('系统繁忙，请稍后再试~');
                                }
                            }
                        });
                    },
                    //获取detailId数组
                    formatData: function(initArr){
                        var dataArr = [];
                        for(var i=0, len=initArr.length; i<len;i++){
                            var item = initArr[i].detailId;
                            dataArr.push(item);
                        }
                        return dataArr;
                    },
                    toPay: function(orderCode){
                        if(!vm.isSelWx){
                            pop.alert('请在微信中完成支付~');
                            return;
                        }
                        if(vm.isSelWx){ //微信支付
                            if(vm.isSending){
                                pop.message.show('正在支付...');
                                return;
                            }
                            wx.ready( function(){
                                wx.chooseWXPay({
                                    timestamp   : vm.wxInitData.timeStamp ,
                                    nonceStr    : vm.wxInitData.nonceStr,
                                    package     : vm.wxInitData.packageStr,
                                    signType    : vm.wxInitData.signType,
                                    paySign     : vm.wxInitData.paySign,
                                    success     : function( rtn ) {
                                        vm.isSending = true;
                                        shan.ajax({
                                            url: '/sz/order/pay_ask_result_async',
                                            data: {
                                                payType: PAY_HANDLER_WX,
                                                orderCode: orderCode,
                                                rs: 1
                                            },
                                            success: function (_json) {
                                                vm.isSending = false;
                                                if (typeof _json != 'undefined' && _json.SZ_HEAD.RESP_CODE == "S0000") {
                                                    vm.showConfirmSuccess = true;
                                                    shan.tools.statisticsPing('253007');
                                                }
                                                else {
                                                    pop.alert(_json.SZ_HEAD.RESP_MSG);
                                                }
                                            }
                                        })
                                    } ,
                                    fail: function(){
                                        pop.message.show("微信支付失败，请重试~");
                                    }
                                });
                            });
                        }
                    }
                }
            })
        }

    };

    var run = function () {
        f.init();
    };

    //初始化函数
    exports.run = run;
});

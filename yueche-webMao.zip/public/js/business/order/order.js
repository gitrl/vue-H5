define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/mustache');
    var serviceCode = shan.tools.getUrlParam("serviceCode");
    var orderCode = shan.tools.getUrlParam("orderCode");
    var serivceID = "";
    var price = 0;
    var define = {
        "BLOOD_GLUCOSE_PKG_A_BACK" : "301010",
        "BLOOD_GLUCOSE_PKG_B_BACK" : "301011",
        "BLOOD_GLUCOSE_METER_BACK" : "301012",
        "BLOOD_GLUCOSE_PKG_A_NEXT" : "301013",
        "BLOOD_GLUCOSE_PKG_B_NEXT" : "301014",
        "BLOOD_GLUCOSE_METER_NEXT" : "301015",
        "BLOOD_PRESSURE_METER_BACK" : "301031",
        "HYPERTENSION_BACK" : "301032",
        "HIGH_BLOOD_LIPID_BACK" : "301033",
        "BLOOD_PRESSURE_METER_NEXT" : "301034",
        "HYPERTENSION_NEXT" : "301035",
        "HIGH_BLOOD_LIPID_NEXT" : "301036"
    };
    var defineImg = {
        "BLOOD_GLUCOSE_PKG_A":"/static/images/report/product/product-a.png",
        "BLOOD_GLUCOSE_PKG_B":"/static/images/report/product/product-b.png",
        "BLOOD_GLUCOSE_METER":"/static/images/report/product/product-1.png",
        "BLOOD_PRESSURE_METER" : "/static/images/report/product/product-2.png",
        "HYPERTENSION" : "/static/images/report/product/product-5.png",
        "HIGH_BLOOD_LIPID" : "/static/images/report/product/product-5.png"
    };

    var _self = {};
    var f = {
    	init : function(){
            _self.memberName = "",
            _self.memberPhone = "",
            _self.addressId = "",
            _self.addressDetail = "";

    		shan.ajax({
                data : {
                    url : "/szreportorder/service_detail.htm",    
                    serviceCode : serviceCode
                },
                success: function(json){
                    if(json &&json.SZ_HEAD && json.SZ_HEAD.RESP_CODE == "S0000" && json.SZ_BODY.SERVICE_D){
                        f.showItem(json.SZ_BODY.SERVICE_D);
                    }
                    else{
                        pop.alert("获取商品详情失败!");
                    }
                }
            });
            
    	},
        showAddress : function(data){
            $(".c_doing").text("当前收货地址");
            $(".c_name").val(data.memberName || "");
            $(".c_phone").val(data.memberPhone || "");
            $(".c_address").val(data.addressDetail || "");              
            _self.addressId = data.addressId;
        },
        showItem : function(data){
            $(".c_shorTitle").text(data.serviceName || "");
            $(".c_desc").text(data.serviceDesc || "");
            $(".c_mainPrice").text("￥"+data.servicePriceVal || "0");
            $(".c_subPrice").text("￥"+data.servicePriceVal || "0");
            $(".c_img").attr("src",defineImg[serviceCode]);
            serivceID = data.serviceId;
            price = data.servicePriceVal || 0;
        },
        checkFillIn : function(){
            if($(".c_name").val() == ""){
                pop.alert("请填写收货人姓名");
                return true;
            }
            _self.memberName = $(".c_name").val();
            var phone = $(".c_phone").val();
            if(phone == "" || !(/^1\d{10}/.test( phone ))){
                pop.alert("请填写正确的收货人手机号码");
                return true;
            }
            _self.memberPhone = phone;
            if($(".c_address").val().length == 0){
                pop.alert("请填写收货人地址");
                return true;
            }
            _self.addressDetail = $(".c_address").val();
            return false;
        },
        pay : function(){
            var number = $(".c_sum").text();
            shan.ajax({
                data : {
                    url : "/szorder/nplaceorder.htm",
                    personCount : number,
                    serviceCode : serviceCode
                },
                type : "post",
                success: function(json){
                    if(json &&json.SZ_HEAD && json.SZ_HEAD.RESP_CODE == "S0000" && json.SZ_BODY.N_ORDER_D){
                        if(shan.tools.isMyApp()){
                            window.location.replace('/sz-pay-app.php?orderCode=' + json.SZ_BODY.N_ORDER_D.orderCode);
                        }
                        else{
                            window.location.replace('/sz/order/pay?orderCode=' + json.SZ_BODY.N_ORDER_D.orderCode);
                        }
                    }
                    else{
                        pop.alert("下单失败");
                    }
                }
            });
        },
        bindEvent : function(){
            $(".c_pageBack").bind("click",function(){
                shan.tools.statisticsPing(define[serviceCode+"_BACK"]);
                history.back();
                return false;
            });
            $(".c_reduct").bind("click",function(){
                var sum = $(".c_sum").text();
                if(sum != 1){
                    --sum; 
                    $(".c_sum").text(sum);
                    $(".c_number").text(sum);
                    $(".c_mainPrice").text("￥" + price * sum);
                    $(".c_subPrice").text("￥" + price * sum);
                }
            });
            $(".c_add").bind("click",function(){
                var sum = $(".c_sum").text();
                sum++;
                $(".c_sum").text(sum);
                $(".c_sum").text(sum);
                $(".c_number").text(sum);
                $(".c_mainPrice").text("￥" + price * sum);
                $(".c_subPrice").text("￥" + price * sum);
            });

            $(".c_next").bind("click", function(){
                shan.tools.statisticsPing(define[serviceCode+"_NEXT"]);
                f.pay();
            });
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});
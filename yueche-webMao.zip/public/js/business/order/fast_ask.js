define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/fastclick');
    require('lib/vue/vue');
    require('lib/iscroll');
    require('lib/share/wxshare');
    require('lib/jquery.tmpl');

    const PAY_HANDLER_WX = 1;
    const PAY_HANDLER_ZFB = 2;
    //兑换卷列表浮层
    var ticketListDialog = pop.layer({
        ele: $('#ticketListDialog'),
        bindEvent: function (layer) {
            //layer.ele.find('.haveSzCode').off('touchend').on('touchend', function (e) {
            //    layer.hide();
            //    exchangeCouponDialog.show();
            //    // 54007    活动框架—下单页—抵扣券浮层—我有善诊口令
            //    shan.tools.statisticsPing("54007");
            //    e.preventDefault();
            //});
            layer.ele.find('#couponChooseBtn').off('touchend').on('touchend', function (e) {
                //if (vm.isNeedConfirm) {
                //    vm.confirmOrder();
                //}
                //else {
                    layer.hide();
                //}
                e.preventDefault();
            });
        }
    });
    var f = {
        init: function () {
            var _self = this;
            var orderCode = shan.tools.getUrlParam('orderCode') || '';
            var orderSource = shan.tools.getUrlParam('orderSource');
            var bId = '',
                newShare = 0;
            shan.tools.statisticsPing("33021");
            $(function () {
                FastClick.attach(document.body);
                $(document).off('ajaxStart');
                $(document).off('ajaxStop');
            });

            try {
                var reportData = JSON.parse(g_report);
                var ticketData = JSON.parse(g_ticket);
                var fastTagData = JSON.parse(g_fastTag);
                var payData=JSON.parse(g_pay);
                if (orderCode && typeof g_bId != "undefined" && g_bId != "") {
                    bId = g_bId;
                }
                if (orderCode && typeof g_newShare != "undefined") {
                    newShare = g_newShare;
                }
            } catch (e) {
                pop.alert('系统繁忙，请稍后再试~');
            }

            var vm = new Vue({
                el: '#app',
                data: {//数据
                    waitFuzzySearch: false,//等待模糊匹配返回
                    fastTagArr: [],//快捷标签数据
                    inputTagWords: '',//用户输入标签
                    limitInputTagWords: 10,//用户最少需提交字数
                    isHideTagMatch: true,//是否隐藏模糊匹配
                    matchTagArr: [],//模糊匹配标签数据
                    matchTagNum: 4,//模糊匹配标签展示数量
                    isChoosedTag: false,//是否已选择标签
                    choosedTag: {//已选择标签
                        tagName: '',
                        tagCode: ''
                    },
                    textareaMessage: '',//用户描述问题
                    residueNum: 200,//用户剩余可输入数字
                    totalNum: 200,//用户可输入总数字
                    reportArr: [],//用户体检报告数据
                    //hasFreeTicket: false,//是否拥有免费提问券
                    choosedorderCode: '',//已选择关联报告code
                    isSelWx: true,  //是否在微信环境
                    isSending: false, //是否正在支付
                    wxInitData: {},   //微信初始化数据
                    isSuccessAsked: false,//是否成功提问
                    showRed: false, //红包弹窗
                    orderCode: orderCode,//提问订单号
                    bId: bId,   //分享链接唯一标识
                    showShare: false,   //分享蒙版
                    shareSuccess: false,    //分享成功
                    successText: '恭喜您已经获得一次免费提问的机会', //分享提示文字
                    showCard: true, //提问券信息
                    deadLine: '',   //有效日期
                    cardPrice: '',  //折扣价格
                    shareFailed: false,  //分享失败
                    newShare: newShare,  //分享是否完成
                    ticketSrc: "/static/images/redPacket/icon_ticket_none.png",//不用使用卷状态下的icon:/static/images/redPacket/icon_ticket.png;/static/images/redPacket/icon_ticket_none.png
                    ticketText: "", //不用使用卷状态下的文字描述:暂无可用券,有X张券可使用,已减免￥XXX
                    //hasTicketText: "", //选择了卷后的文字描述:
                    hasQuestionTicket: false,//是否有问答券
                    hasRadioTicket: false,//是否有语音券
                    ticketStatusClass: 'noTicket',//noTicket，hasTicket
                    ticketStatusShow: false, //是否展示"请选择券按钮" 仅仅在hasTicket状态下展示
                    isUseTicket: false, //用户是否选择了优惠卷
                    couponIds: "", //用户选择的卷ID
                    ticketAmt: 0, //用户选择的卷面价格
                    ticketDataList: [],//券列表
                    ableTicketCount: 0,//可用券数量
                    needPay: 0,//问答价格
                    isFirstFormatTicket:true,//是否第一次初始化券列表
                },
                computed: {//计算属性
                    needPayStr: function () {
                        var _temp = ((this.needPay - this.ticketAmt) / 1000);
                        if (_temp <= 0) {
                            return '免费';
                        }
                        else {
                            return '￥'+_temp.toFixed(1);
                        }
                    },
                    isShowAmtStr: function () {
                        if (this.ticketAmt == 0) {
                            return false;
                        }
                        else {
                            return true;
                        }
                    },
                    amtStr: function () {
                        return (this.ticketAmt / 1000).toFixed(1);
                    },
                    hasFastTag: function () {//是否有快捷标签
                        return this.fastTagArr.length > 0 ? true : false;
                    },
                    hasReport: function () {//是否有体检报告
                        return this.reportArr.length > 0 ? true : false;
                    }
                },
                created: function () {//创建实例后
                    if (shan.tools.isWeixin() == 0) {
                        this.isSelWx = false;
                    }
                    if (reportData.SZ_HEAD.RESP_CODE == 'S0000') {
                        this.reportArr = reportData.SZ_BODY.REPORT_BRIEF;
                        if (this.reportArr.length > 0) {
                            this.choosedorderCode = this.orderCode;
                            shan.tools.statisticsPing('250014');
                        }
                    }
                    if (ticketData.SZ_HEAD.RESP_CODE == 'S0000') {
                        //this.hasFreeTicket = true;
                        //shan.tools.statisticsPing('250012');
                        if (typeof ticketData.SZ_BODY.QUESTION_EQUITY != 'undefined' && ticketData.SZ_BODY.QUESTION_EQUITY.length > 0) {
                            this.hasQuestionTicket = true;
                            this.ticketStatusClass = 'hasTicket';
                            this.ableTicketCount = ticketData.SZ_BODY.QUESTION_EQUITY.length;
                            this.ticketText = '有<span class="text-red">' + this.ableTicketCount + '</span>张券可使用';

                        }
                        else {
                            ticketData.SZ_BODY.QUESTION_EQUITY = [];
                            this.hasQuestionTicket = false;
                            this.ticketStatusClass = 'noTicket';
                            this.ticketText = '暂无可用券';

                        }
                        if (typeof ticketData.SZ_BODY.REPORTINTERPRETATION_EQUITY != 'undefined' && ticketData.SZ_BODY.REPORTINTERPRETATION_EQUITY.length > 0) {
                            this.hasRadioTicket = true;
                        }
                        else {
                            ticketData.SZ_BODY.REPORTINTERPRETATION_EQUITY = [];
                            this.hasRadioTicket = false;
                        }
                        this.ticketDataList = ticketData.SZ_BODY.QUESTION_EQUITY.concat(ticketData.SZ_BODY.REPORTINTERPRETATION_EQUITY);
                    }

                    if (fastTagData.SZ_HEAD.RESP_CODE == 'S0000') {
                        this.fastTagArr = fastTagData.SZ_BODY.SZ_TAGS;
                    }

                    if(payData.SZ_HEAD.RESP_CODE=='S0000' && typeof payData.SZ_BODY.QUESTION_PRICE !='undefined'){
                        this.needPay=payData.SZ_BODY.QUESTION_PRICE;
                    }

                    if (this.bId) { //具有分享券功能
                        shan.tools.statisticsPing('250101');
                        /*if(this.newShare == 1){
                         this.showRed = true;
                         }*/
                    }
                },
                mounted: function () {//创建dom后
                    this.formatIsScrollWidth('#tagFastBox');
                    this.formatIsScrollWidth('#reportsBox');
                    var fastTag = new IScroll('#tagFastBox', {
                        scrollX: true,
                        scrollY: false,
                        mouseWheel: true,
                        preventDefault: false
                    }, 100);


                    var reportList = new IScroll('#reportsBox', {
                        scrollX: true,
                        scrollY: false,
                        mouseWheel: true,
                        preventDefault: false
                    }, 100);
                },
                methods: {//方法
                    renderTicket: function (list, layer) {

                        if (this.isUseTicket) {
                            list.chooseTicketCode = this.couponIds;
                            list.id = this.couponIds;
                        }

                        //if (list.length > 0) {
                        //    layer.ele.find('.haveSzCode').hide();
                        //}

                        layer.ele.find('.red-packet-ticket-list').html("").html($('#dmyTicketList').tmpl(list, {
                            getInput: function (spr) {
                                if (list.chooseTicketCode == this.data.id) {
                                    return '<input type="checkbox" name="project13" checked="checked"/>';
                                } else {
                                    return '<input type="checkbox" name="project13" />';
                                }
                            },
                            formatExpireTime: function (spr) {
                                return this.data.expireTime.substring(0, 10);
                            }
                            //isFree: function () {
                            //    if (vm.activityPrice == 0) {
                            //        return true;
                            //    }
                            //    else {
                            //        return false;
                            //    }
                            //}
                        }));

                        //选择口令券
                        layer.ele.off('click').on('click', 'li', function () {
                            if (!$(this).hasClass('text-disabled')) {
                                if ($(this).find('input[type="checkbox"]').prop('checked')) {
                                    $(this).find('input[type="checkbox"]').prop('checked', false);
                                    //vm.couponIds = [];
                                    vm.couponIds = "";
                                    vm.ticketAmt = 0;
                                    //vm.isHasTicket = true;
                                    vm.isUseTicket = false;
                                    //vm.ticketStatus = false;
                                    vm.ticketText = '有<span class="text-red">' + vm.ableTicketCount + '</span>张券可使用';
                                    //vm.ticketSrc = '/static/images/redPacket/icon_ticket_none.png';
                                    //vm.hasTicketText='';

                                }
                                else {
                                    if (vm.isUseTicket) {
                                        layer.ele.find('.red-packet-ticket input[type="checkbox"]').attr('checked', false);
                                        //vm.couponIds = [];
                                        vm.couponIds = "";
                                    }
                                    $(this).find('input[type="checkbox"]').prop('checked', true);
                                    //vm.couponIds.push($(this).data('code'));
                                    vm.isUseTicket = true;
                                    vm.couponIds = $(this).attr('data-code');
                                    vm.ticketAmt = parseInt($(this).attr('data-price'));
                                    //vm.ticketStatus = true;
                                    vm.ticketText = '已减免￥'+(vm.ticketAmt/1000).toFixed(1);
                                    //vm.ticketSrc = '';
                                    //vm.hasTicketText='已减免￥'+(vm.ticketAmt/1000).toFixed(1);
                                }
                                //vm.countPrice();
                            }
                        });

                        /*var ticketWidth = 3.75 * 0.9 - 0.16 * 2;
                         layer.ele.find('.red-packet-ticket-list li').css('height', parseInt(ticketWidth * 0.351 * 100, 10) / 100 + 0.05 + 'rem');*/
                    },
                    selTicket: function () {
                        if (this.hasQuestionTicket) { //有优惠券
                            //this.isNeedConfirm = false;
                            if (this.isFirstFormatTicket) {
                                this.renderTicket(this.ticketDataList, ticketListDialog);
                                this.isFirstFormatTicket=false;
                            }
                            ticketListDialog.show();
                            //shan.tools.statisticsPing("54005");
                        }
                    },
                    cancelTag: function () {
                        this.choosedTag.tagName = '';
                        this.choosedTag.tagCode = '';
                        this.isChoosedTag = false;
                        this.isHideTagMatch = true;
                        this.inputTagWords = '';
                        this.matchTagArr = [];
                        shan.tools.statisticsPing('250002');
                    },
                    countMessage: function () {
                        if (this.textareaMessage.length <= this.totalNum) {
                            this.residueNum = this.totalNum - this.textareaMessage.length;
                        }
                        else {
                            this.textareaMessage = this.textareaMessage.substring(0, this.totalNum);
                            this.residueNum = 0;
                        }
                    },
                    focusTextArea: function () {//文本框获取焦点
                        shan.tools.statisticsPing('33022');
                    },
                    askQuestion: function () {
                        shan.tools.statisticsPing('250013');
                        if (this.waitFuzzySearch) {
                            pop.alert('稍等片刻，请不要频繁提交请求！')
                        }
                        else {
                            shan.tools.statisticsPing('250017');
                            pop.confirm('是否确认发起提问？', vm.submitOrder);
                        }
                    },
                    formatIsScrollWidth: function (_id) {
                        var _len = 0;
                        var $_ul = $(_id).find('ul');
                        $_ul.children('li').each(function () {
                            _len += $(this).outerWidth() + 10;
                        });
                        _len += 20;
                        $_ul.css('width', _len + 'px');
                    },
                    chooseReport: function (_obj) {
                        var $_obj = $(_obj.currentTarget);
                        if ($_obj.hasClass('item-on')) {
                            this.choosedorderCode = '';
                            $_obj.removeClass('item-on');
                        }
                        else {
                            this.choosedorderCode = $_obj.attr('data-code');
                            $_obj.addClass('item-on').siblings().removeClass('item-on');

                        }
                    },
                    chooseTag: function (_obj, _index) {
                        this.choosedTag.tagName = $(_obj.currentTarget).html();
                        this.choosedTag.tagCode = $(_obj.currentTarget).attr('data-code');
                        this.isChoosedTag = true;
                        this.isHideTagMatch = true;
                        this.inputTagWords = '';
                        this.matchTagArr = [];
                        shan.tools.statisticsPing((_index + 4 + 250000).toString());
                    },
                    fuzzySearch: function () {
                        if (this.inputTagWords.length < 1) {
                            this.isHideTagMatch = true;
                        }
                        else {
                            shan.ajax({
                                data: {
                                    url: '/askdoctor/matchtags.htm',
                                    keyword: this.inputTagWords,
                                    limitCount: this.matchTagNum
                                },
                                success: function (_json) {
                                    vm.waitFuzzySearch = false;
                                    if (typeof _json != "undefined" && _json.SZ_HEAD.RESP_CODE == 'S0000') {
                                        try {
                                            if (_json.SZ_BODY.SZ_TAGS && _json.SZ_BODY.SZ_TAGS.length > 0) {
                                                vm.isHideTagMatch = false;
                                                vm.matchTagArr = _json.SZ_BODY.SZ_TAGS;
                                            }
                                            else {
                                                vm.isHideTagMatch = true;
                                            }
                                        }
                                        catch (e) {
                                            console.log(e);
                                        }
                                    }
                                },
                                error: function (_json, _status, _err) {
                                    vm.waitFuzzySearch = false;
                                }
                            });
                        }
                    },
                    submitOrder: function () {
                        shan.tools.statisticsPing('250018');
                        if (!this.waitFuzzySearch) {

                            /*for(var i=0;i<this.textareaMessage.length;i++){
                             if(this.isEmojiCharacter(this.textareaMessage.charAt(i))){
                             pop.message.show('请不要输入特殊表情和空格！');
                             return false;
                             }
                             }*/
                            if (this.textareaMessage.length >= this.limitInputTagWords) {
                                this.waitFuzzySearch = true;
                                var _questionTagCodes = [this.choosedTag.tagCode];
                                shan.ajax({
                                    data: {
                                        url: '/askdoctor/postquestioncontent.htm',
                                        orderCodeRelated: this.choosedorderCode,
                                        questionContent: this.textareaMessage,
                                        questionTagCodes: JSON.stringify(_questionTagCodes),
                                        orderSource: orderSource,
                                        equityId:this.couponIds
                                    },
                                    type: 'POST',
                                    version: 'V2',
                                    success: function (_json) {
                                        vm.waitFuzzySearch = false;
                                        if (typeof _json != "undefined" && _json.SZ_HEAD.RESP_CODE == 'S0000') {
                                            vm.orderCode = _json.SZ_BODY.ORDER_CODE;
                                            if (_json.SZ_BODY.NEED_PAY == '1') {
                                                vm.waitFuzzySearch = true;
                                                shan.ajax({
                                                    url: "/sz/order/wxpay_ask_async",
                                                    data: {
                                                        orderCode: vm.orderCode
                                                    },
                                                    success: function (_json) {
                                                        vm.waitFuzzySearch = false;
                                                        if (typeof _json != "undefined" && _json.SZ_HEAD.RESP_CODE == "S0000") {
                                                            vm.wxInitData = _json.SZ_BODY.PREPAY_D;
                                                            if (typeof wx != 'object') {
                                                                pop.alert("微信支付失败，请重试~");
                                                                return;
                                                            }
                                                            wx.config({
                                                                appId: vm.wxInitData.appId,
                                                                timestamp: vm.wxInitData.timeStamp,
                                                                nonceStr: vm.wxInitData.nonceStr,
                                                                signature: vm.wxInitData.paySign,
                                                                jsApiList: ["chooseWXPay"]
                                                            });
                                                            vm.toPay(vm.orderCode);
                                                        } else {
                                                            pop.message.show('微信支付失败，请重试~');
                                                        }

                                                    }
                                                });
                                            } else {
                                                vm.isSuccessAsked = true;
                                                shan.tools.statisticsPing('250016');
                                            }
                                        } else {
                                            //pop.alert(_json.SZ_HEAD.RESP_MSG);
                                            pop.alert('支付失败，请检查网络情况后重试~');
                                        }
                                    },
                                    error: function (_json, _status, _err) {
                                        vm.waitFuzzySearch = false;
                                    }
                                });
                            } else {
                                pop.message.show('请详细描述您的问题，方便医生解答，建议最少十个字！');
                            }
                        }
                        else {
                            pop.alert('稍等片刻，请不要频繁提交请求！')
                        }
                    },
                    toPay: function (orderCode) {
                        if (vm.isSelWx) { //微信支付
                            if (vm.isSending) {
                                pop.message.show('正在支付...');
                                return;
                            }

                            wx.ready(function () {
                                wx.chooseWXPay({
                                    timestamp: vm.wxInitData.timeStamp,
                                    nonceStr: vm.wxInitData.nonceStr,
                                    package: vm.wxInitData.packageStr,
                                    signType: vm.wxInitData.signType,
                                    paySign: vm.wxInitData.paySign,
                                    success: function (rtn) {
                                        vm.isSending = true;
                                        shan.ajax({
                                            url: '/sz/order/pay_ask_result_async',
                                            data: {
                                                payType: PAY_HANDLER_WX,
                                                orderCode: orderCode,
                                                rs: 1
                                            },
                                            success: function (_json) {
                                                vm.isSending = false;
                                                if (typeof _json != 'undefined' && _json.SZ_HEAD.RESP_CODE == "S0000") {
                                                    vm.isSuccessAsked = true;
                                                    shan.tools.statisticsPing('250016');
                                                }
                                                else {
                                                    pop.alert(_json.SZ_HEAD.RESP_MSG);
                                                }
                                            }
                                        })
                                    },
                                    fail: function () {
                                        pop.message.show("微信支付失败，请重试~");
                                    }
                                });
                            });
                        } else {
                            pop.alert('请在微信中完成支付~');
                        }
                    },
                    leavePage: function () {
                        window.location.replace('/sz/ask/my_ask_details?orderCode=' + vm.orderCode);
                    },
                    /*isEmojiCharacter: function (codePoint) {
                     return (codePoint == 0x0) || (codePoint == 0x9) || (codePoint == 0xA) ||
                     (codePoint == 0xD) || ((codePoint >= 0x20) && (codePoint <= 0xD7FF)) ||
                     ((codePoint >= 0xE000) && (codePoint <= 0xFFFD)) || ((codePoint >= 0x10000)
                     && (codePoint <= 0x10FFFF));
                     },*/
                    setPoint: function () {
                        shan.tools.statisticsPing('250001');
                    },
                    //点击分享banner
                    /*toRed: function(){
                     this.showRed = true;
                     },
                     //点击立即分享
                     toShare: function(){
                     this.showRed = false;
                     this.showShare = true;
                     shan.tools.statisticsPing('250102');
                     },
                     //关闭红包弹窗
                     closeRed: function () {
                     this.showRed = false;
                     },
                     //关闭分享
                     closeShare: function(){
                     this.showShare = false;
                     },*/
                    //关闭分享成功弹窗
                    closeSuccessDialog: function () {
                        this.shareSuccess = false;
                        shan.tools.statisticsPing('250116');
                        window.location.reload();
                    },
                    //关闭分享失败弹窗
                    closeFailedDialog: function () {
                        this.shareFailed = false;
                        shan.tools.statisticsPing('250118');
                    }
                }

            });

            //微信分享
            if (typeof g_bId != "undefined" && g_bId != "") {
                //初始化分享浮层
                var controller = new wxController();
                controller.init(
                    ['onMenuShareTimeline', 'onMenuShareAppMessage'],
                    function () {
                        controller.configShareTimeline({
                            title: "问医生，不花钱！", // 分享标题
                            link: "https://" + window.location.host + "/sz/ask/share_ask?bId=" + g_bId, // 分享链接
                            imgUrl: "https://" + window.location.host + "/static/images/ask/fast-ask/share.png", // 分享图标
                            success: function () {
                                shan.tools.statisticsPing('250122');
                                shan.ajax({
                                    data: {
                                        url: '/askdoctor/broadcast/question_share_cb.htm',
                                        broadcastId: g_bId
                                    },
                                    type: "POST",
                                    version: "V2",
                                    success: function (_json) {
                                        var resp_code = _json.SZ_HEAD.RESP_CODE;
                                        vm.showShare = false;
                                        if (resp_code == 'S0000') {
                                            var resultData = _json.SZ_BODY.CB_RESULT;
                                            vm.shareSuccess = true;
                                            vm.cardPrice = Math.floor((resultData.assignAmt) / 1000);
                                            vm.deadLine = resultData.expireTime.substring(0, 10);
                                            shan.tools.statisticsPing('250103');
                                        } else if (resp_code == 'BC0002' || resp_code == 'BC0003' || resp_code == 'BC0004' || resp_code == 'BC0005' || resp_code == 'BC0006') {
                                            vm.shareSuccess = true;
                                            vm.successText = '感谢您的分享';
                                            vm.showCard = false;
                                            shan.tools.statisticsPing('250104');
                                        } else {
                                            vm.shareFailed = true;
                                            shan.tools.statisticsPing('250105');
                                        }
                                    }
                                });
                            },
                            cancel: function () {

                            }
                        });
                        controller.configShareAppMessage({
                            title: "问医生，不花钱！", // 分享标题
                            desc: "一键领券，极速问诊。善诊精选公立医院全职医生为您答疑解惑~", // 分享描述
                            link: "https://" + window.location.host + "/sz/ask/share_ask?bId=" + g_bId, // 分享链接
                            imgUrl: "https://" + window.location.host + "/static/images/ask/fast-ask/share.png", // 分享图标
                            type: '', // 分享类型,music、video或link，不填默认为link
                            dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
                            success: function () {
                                shan.tools.statisticsPing('250121');
                                shan.ajax({
                                    data: {
                                        url: '/askdoctor/broadcast/question_share_cb.htm',
                                        broadcastId: g_bId
                                    },
                                    type: "POST",
                                    version: "V2",
                                    success: function (_json) {
                                        var resp_code = _json.SZ_HEAD.RESP_CODE;
                                        vm.showShare = false;
                                        if (resp_code == 'S0000') {
                                            var resultData = _json.SZ_BODY.CB_RESULT;
                                            vm.shareSuccess = true;
                                            vm.cardPrice = Math.floor((resultData.assignAmt) / 1000);
                                            vm.deadLine = resultData.expireTime.substring(0, 10);
                                            shan.tools.statisticsPing('250103');
                                        } else if (resp_code == 'BC0002' || resp_code == 'BC0003' || resp_code == 'BC0004' || resp_code == 'BC0005' || resp_code == 'BC0006') {
                                            vm.shareSuccess = true;
                                            vm.successText = '感谢您的分享';
                                            vm.showCard = false;
                                            shan.tools.statisticsPing('250104');
                                        } else {
                                            vm.shareFailed = true;
                                            shan.tools.statisticsPing('250105');
                                        }
                                    }
                                });
                            },
                            cancel: function () {
                            }
                        });
                    }
                );
            }

        }
    };

    var run = function () {
        f.init();
    }

    //初始化函数
    exports.run = run;
});
define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/vue/vue.min');

    const orderCode = shan.tools.getUrlParam("orderCode");
    const PAY_HANDLER_WX = 1;
    const PAY_HANDLER_ZFB = 2;

    var f = {
        init : function(){
            $(".yo-mask").click(function(){
                $(this).addClass("hidden");
                $(".to-brower").addClass("hidden");
            })
        }
    };

    var pay = new Vue({
        el: "#pay",
        data: {
            isSelWx: true,
            isSending: false,
            payType: shan.tools.isWeixin()?PAY_HANDLER_WX:PAY_HANDLER_ZFB

        },
        created: function () {
            if(shan.tools.isWeixin() == 0){
                this.isSelWx = false;
                $("#zfbBtn").attr("checked", true);
            }
        },
        methods: {
            goBack: function(){
                if(g_isBiz == 1){
                    window.location.href = "/sz/biz/index";
                }
                else{
                    history.go(-1);
                }
                
            },
            selWx: function(){
                this.isSelWx = true;
                this.payType = PAY_HANDLER_WX;
                $("#wxBtn").attr("checked", true);

            },
            selZfb: function(){
                this.isSelWx = false;
                this.payType = PAY_HANDLER_ZFB;
                $("#zfbBtn").attr("checked", true);
            },
            confirm: function(){
                
                if(this.isSelWx){ //微信支付
                    
                    if(this.isSending){
                        pop.message.show('正在支付...');
                        return;
                    }
                    else{
                        this.isSending = true;
                    }
                    
                    shan.ajax({
                        url: "/sz/order/wxpay_async",
                        data: {
                            orderCode: orderCode
                        },
                        success: function (_json) {
                            pay.isSending = false;
                            if(typeof _json != "undefined" && _json.SZ_HEAD.RESP_CODE == "S0000"){
                                var data = _json.SZ_BODY.PREPAY_D;
                                //alert(data.appId+","+data.timeStamp+","+data.nonceStr+","+data.paySign);
                                wx.config( {
                                    appId       : data.appId, 
                                    timestamp   : data.timeStamp,
                                    nonceStr    : data.nonceStr, 
                                    signature   : data.paySign ,
                                    jsApiList   : [ "chooseWXPay" ]
                                } );
                                wx.ready( function(){
                                    //alert(data.packageStr+","+data.timeStamp+","+data.nonceStr+","+data.packageStr+","+data.paySign);
                                    wx.chooseWXPay({
                                        timestamp: data.timeStamp , 
                                        nonceStr: data.nonceStr, 
                                        package: data.packageStr,
                                        signType: data.signType, 
                                        paySign: data.paySign, 
                                        success: function( rtn ) {
                                            var url = "/sz/order/pay_result?payType="+pay.payType+"&orderCode="+orderCode+"&rs=1";
                                            window.location.href = url;
                                            return;
                                        },
                                        fail: function(){
                                            pop.message.show("微信支付失败");
                                            return;
                                        }
                                    });
                                } );
                                wx.error(function(res){
                                    // config信息验证失败会执行error函数，如签名过期导致验证失败，具体错误信息可以打开config的debug模式查看，也可以在返回的res参数中查看，对于SPA可以在这里更新签名。
                                    pop.alert("微信支付初始化失败，"+res);
                                });
                            }
                            else{
                                pop.message.show('微信支付初始化失败');
                            }
                            
                        } 
                    });
                }
                else{ //支付宝支付
                    if(shan.tools.isWeixin() == 1){
                        $(".yo-mask").removeClass("hidden");
                        $(".to-brower").removeClass("hidden");
                    }
                    else{
                        if(this.isSending){
                            pop.message.show('正在支付...');
                            return;
                        }
                        else{
                            this.isSending = true;
                        }
                        $("#alipayForm" ).submit();
                    }
                    
                }
            }
        }
    });

    var run = function () {
        f.init();
    }

    //初始化函数
    exports.run = run;
});
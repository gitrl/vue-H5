define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/vue/vue.min');
    var SCROLL = require('lib/sz_scroll');
    require('lib/vue/vue-lazyload');
    require('lib/jquery.tmpl');
    var reportCode = shan.tools.getUrlParam("orderCode");    //报告订单号

    const PAY_HANDLER_WX = 1;

    //兑换卷列表浮层
    var ticketListDialog = pop.layer({
        ele: $('#ticketListDialog'),
        bindEvent: function (layer) {
            layer.ele.find('#couponChooseBtn').off('touchend').on('touchend', function (e) {
                layer.hide();
                e.preventDefault();
            });
        }
    });

    var f = {
        init: function () {
            try{
                var report_summary = JSON.parse(g_report_summary.replace(/\r\n/g,'<br/>').replace(/\n/g,'<br/>')),
                    doctor_list = JSON.parse(g_doctor_list.replace(/\r\n/g,'<br/>').replace(/\n/g,'<br/>')),
                    ticketData = JSON.parse(g_ticket),
                    payData=JSON.parse(g_pay);
            }catch(e){
                pop.alert("系统繁忙，请稍后再试!", function () {
                    window.location.replace("/sz/report/index?orderCode=" + reportCode);
                });
            }
            Vue.use(VueLazyload, {
                preLoad: 1.3,
                error: '/static/images/ask/icon_logo.png',
                loading: '/static/images/avatar.jpg',
                attempt: 1
            });

            var vm  = new Vue({
                el: '#app',
                data: {
                    report_summary: report_summary, //体检概况
                    doctor_list: doctor_list,   //医生团队列表
                    payPrice: 19.9,   //支付价格
                    showConfirmSuccess: false,  //提交成功弹窗
                    orderCode: '',   //提问订单号
                    isSelWx: true,  //是否在微信环境
                    wxInitData: {}, //微信初始化数据
                    isSending: false, //是否正在支付
                    page: 2,
                    myScroll: {},
                    listObject: {
                        marginTop: '0'
                    },
                    pullUpStatus: {
                        refresh: false,
                        loading: false
                    },
                    pullUpTipsShow: false,
                    pullUpLabelText: '',
                    pullUpTips: '上拉加载更多...',
                    loadingStep: 0  ,//加载状态0默认，1显示加载状态，2执行加载数据，只有当为0时才能再次加载，这是防止过快拉动刷新
                    ticketSrc: "/static/images/redPacket/icon_ticket_none.png",//不用使用卷状态下的icon:/static/images/redPacket/icon_ticket.png;/static/images/redPacket/icon_ticket_none.png
                    ticketText: "", //不用使用卷状态下的文字描述:暂无可用券,有X张券可使用,已减免￥XXX
                    hasQuestionTicket: false,//是否有问答券
                    hasRadioTicket: false,//是否有语音券
                    ticketStatusClass: 'noTicket',//noTicket，hasTicket
                    ticketStatusShow: false, //是否展示"请选择券按钮" 仅仅在hasTicket状态下展示
                    isUseTicket: false, //用户是否选择了优惠卷
                    couponIds: "", //用户选择的卷ID
                    ticketAmt: 0, //用户选择的卷面价格
                    ticketDataList: [],//券列表
                    ableTicketCount: 0,//可用券数量
                    needPay: 0,//问答价格
                    isFirstFormatTicket:true,//是否第一次初始化券列表
                },
                computed:{
                    needPayStr: function () {
                        var _temp = ((this.needPay - this.ticketAmt) / 1000);
                        if (_temp <= 0) {
                            return '免费';
                        }
                        else {
                            return '￥'+_temp.toFixed(1);
                        }
                    },
                    isShowAmtStr: function () {
                        if (this.ticketAmt == 0) {
                            return false;
                        }
                        else {
                            return true;
                        }
                    },
                    amtStr: function () {
                        return (this.ticketAmt / 1000).toFixed(1);
                    }
                },
                created: function(){
                    shan.tools.statisticsPing("253005");
                    if(shan.tools.isWeixin() == 0){
                        this.isSelWx = false;
                    }
                    //if (ticketData.SZ_HEAD.RESP_CODE == 'S0000' && ticketData.SZ_BODY.COUPON_EXISTS == 1) {
                    //    this.payPrice = 0;
                    //}
                    if (ticketData.SZ_HEAD.RESP_CODE == 'S0000') {
                        //this.hasFreeTicket = true;
                        //shan.tools.statisticsPing('250012');
                        if (typeof ticketData.SZ_BODY.REPORTINTERPRETATION_EQUITY != 'undefined' && ticketData.SZ_BODY.REPORTINTERPRETATION_EQUITY.length > 0) {
                            this.hasRadioTicket = true;
                            this.ticketStatusClass = 'hasTicket';
                            this.ableTicketCount = ticketData.SZ_BODY.REPORTINTERPRETATION_EQUITY.length;
                            this.ticketText = '有<span class="text-red">' + this.ableTicketCount + '</span>张券可使用';

                        }
                        else {
                            ticketData.SZ_BODY.REPORTINTERPRETATION_EQUITY = [];
                            this.hasRadioTicket = false;
                            this.ticketStatusClass = 'noTicket';
                            this.ticketText = '暂无可用券';

                        }
                        if (typeof ticketData.SZ_BODY.QUESTION_EQUITY != 'undefined' && ticketData.SZ_BODY.QUESTION_EQUITY.length > 0) {
                            this.hasQuestionTicket = true;
                        }
                        else {
                            ticketData.SZ_BODY.QUESTION_EQUITY = [];
                            this.hasQuestionTicket = false;
                        }
                        this.ticketDataList = ticketData.SZ_BODY.REPORTINTERPRETATION_EQUITY.concat(ticketData.SZ_BODY.QUESTION_EQUITY);
                    }
                    if(payData.SZ_HEAD.RESP_CODE=='S0000' && typeof payData.SZ_BODY.REPORT_INTERPRETATION_PRICE !='undefined'){
                        this.needPay=payData.SZ_BODY.REPORT_INTERPRETATION_PRICE;
                    }
                },
                mounted: function(){
                    this.initMyScroll();
                },
                methods: {
                    renderTicket: function (list, layer) {
                        if (this.isUseTicket) {
                            list.chooseTicketCode = this.couponIds;
                            list.id = this.couponIds;
                        }
                        layer.ele.find('.red-packet-ticket-list').html("").html($('#dmyTicketList').tmpl(list, {
                            getInput: function (spr) {
                                if (list.chooseTicketCode == this.data.id) {
                                    return '<input type="checkbox" name="project13" checked="checked"/>';
                                } else {
                                    return '<input type="checkbox" name="project13" />';
                                }
                            },
                            formatExpireTime: function (spr) {
                                return this.data.expireTime.substring(0, 10);
                            }
                        }));
                        //选择口令券
                        layer.ele.off('click').on('click', 'li', function () {
                            if (!$(this).hasClass('text-disabled')) {
                                if ($(this).find('input[type="checkbox"]').prop('checked')) {
                                    $(this).find('input[type="checkbox"]').prop('checked', false);
                                    vm.couponIds = "";
                                    vm.ticketAmt = 0;
                                    vm.isUseTicket = false;
                                    vm.ticketText = '有<span class="text-red">' + vm.ableTicketCount + '</span>张券可使用';
                                }
                                else {
                                    if (vm.isUseTicket) {
                                        layer.ele.find('.red-packet-ticket input[type="checkbox"]').attr('checked', false);
                                        vm.couponIds = "";
                                    }
                                    $(this).find('input[type="checkbox"]').prop('checked', true);
                                    vm.isUseTicket = true;
                                    vm.couponIds = $(this).attr('data-code');
                                    vm.ticketAmt = parseInt($(this).attr('data-price'));
                                    vm.ticketText = '已减免￥'+(vm.ticketAmt/1000).toFixed(1);
                                }
                            }
                        });
                    },
                    selTicket: function () {
                        if (this.hasRadioTicket) { //有优惠券
                            if (this.isFirstFormatTicket) {
                                this.renderTicket(this.ticketDataList, ticketListDialog);
                                this.isFirstFormatTicket=false;
                            }
                            ticketListDialog.show();
                            //shan.tools.statisticsPing("54005");
                        }
                    },
                    //查看订单
                    checkOrder: function(){
                        shan.tools.statisticsPing("253014");
                        window.location.href = '/sz/ask/my_ask_list';
                    },
                    //继续查看报告
                    toReport: function(){
                        shan.tools.statisticsPing("253013");
                    },
                    initMyScroll: function(){
                        $('#pullUp').hide();
                        //iScroll初始化
                        this.myScroll = new IScroll("#wrapper",SCROLL.initData());
                        //手指向上拉动
                        this.myScroll.on('scroll', SCROLL.scrollTop(this));
                        //手指松开刷新
                        this.myScroll.on('scrollEnd',SCROLL.scrollLoosen(this));
                    },
                    pullUpAction: function(){
                        setTimeout(function(){
                            //ajax请求
                            shan.ajax({
                                url: '/sz/order/get_more_doctor_async',
                                async : true,
                                data: {
                                    currentPage: vm.page,
                                    recordPerPage: 5
                                },
                                success: function(json){
                                    if(typeof json != 'undefined' && json.SZ_HEAD.RESP_CODE == 'S0000'){
                                        $('#pullUp').hide();
                                        if(json.SZ_BODY.DOCTOR_LIST.length >= 1){
                                            var moreData = json.SZ_BODY.DOCTOR_LIST;
                                            vm.doctor_list = vm.doctor_list.concat(moreData);
                                            SCROLL.pullSuccess(vm,'0');
                                            vm.page++;
                                        }else{
                                            vm.pullUpTipsShow = true;
                                            vm.pullUpTips = '—— 更多医生敬请期待 ——';
                                        }
                                    }else{
                                        pop.alert(json.SZ_HEAD.RESP_MSG);
                                    }
                                }
                            });
                        },0);
                    },
                    //提交报告解读
                    submitOrder: function(){
                        shan.tools.statisticsPing("253006");
                        shan.ajax({
                            url: '/sz/order/submit_report_pay_async',
                            type: 'post',
                            data: {
                                orderCode: reportCode,
                                equityId:this.couponIds
                            },
                            success: function(_json){
                                if(_json.SZ_HEAD.RESP_CODE == 'S0000'){
                                    vm.orderCode = _json.SZ_BODY.ORDER_CODE;
                                    if(_json.SZ_BODY.PAY_AMT == 0){//支付金额为0,直接显示弹窗
                                        vm.showConfirmSuccess = true;
                                        shan.tools.statisticsPing("253008");
                                        return;
                                    }
                                    shan.ajax({//微信支付
                                        url: "/sz/order/wxpay_ask_async",
                                        data: {
                                            orderCode: vm.orderCode
                                        },
                                        success: function (_json) {
                                            if (typeof _json != "undefined" && _json.SZ_HEAD.RESP_CODE == "S0000") {
                                                vm.wxInitData = _json.SZ_BODY.PREPAY_D;
                                                if (typeof wx != 'object') {
                                                    pop.alert("微信支付初始化失败，请重试~");
                                                    return;
                                                }
                                                wx.config({
                                                    appId: vm.wxInitData.appId,
                                                    timestamp: vm.wxInitData.timeStamp,
                                                    nonceStr: vm.wxInitData.nonceStr,
                                                    signature: vm.wxInitData.paySign,
                                                    jsApiList: ["chooseWXPay"]
                                                });
                                                vm.toPay(vm.orderCode);
                                            }else {
                                                pop.message.show('微信支付失败，请检查网络环境~');
                                            }
                                        }
                                    });
                                }else{
                                    pop.alert('系统繁忙，请稍后再试~');
                                }
                            }
                        });
                    },
                    //微信支付
                    toPay: function(orderCode){
                        if(!vm.isSelWx){
                            pop.alert('请在微信中完成支付~');
                            return;
                        }
                        if(vm.isSelWx){ //微信支付
                            if(vm.isSending){
                                pop.message.show('正在支付...');
                                return;
                            }

                            wx.ready( function(){
                                wx.chooseWXPay({
                                    timestamp   : vm.wxInitData.timeStamp ,
                                    nonceStr    : vm.wxInitData.nonceStr,
                                    package     : vm.wxInitData.packageStr,
                                    signType    : vm.wxInitData.signType,
                                    paySign     : vm.wxInitData.paySign,
                                    success     : function( rtn ) {
                                        vm.isSending = true;
                                        shan.ajax({
                                            url: '/sz/order/pay_ask_result_async',
                                            data: {
                                                payType: PAY_HANDLER_WX,
                                                orderCode: orderCode,
                                                rs: 1
                                            },
                                            success: function (_json) {
                                                vm.isSending = false;
                                                if (typeof _json != 'undefined' && _json.SZ_HEAD.RESP_CODE == "S0000") {
                                                    vm.showConfirmSuccess = true;
                                                    shan.tools.statisticsPing('253008');
                                                }
                                                else {
                                                    pop.alert(_json.SZ_HEAD.RESP_MSG);
                                                }
                                            }
                                        })
                                    } ,
                                    fail: function(){
                                        pop.message.show("微信支付失败，请重试~");
                                    }
                                });
                            });
                        }
                    }
                }
            })
        }

    };

    var run = function () {
        f.init();
    };

    //初始化函数
    exports.run = run;
});

define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');

    var orderCode = shan.tools.getUrlParam("orderCode");
    var f = {
        init : function(){
            
            $("#alipayFormTempalte").submit();
        }
    };

    

    var run = function () {
        f.init();
    }

    //初始化函数
    exports.run = run;
});
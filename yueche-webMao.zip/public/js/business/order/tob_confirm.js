define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    require('lib/vue/vue.min');
    require('lib/fastclick');
    require('lib/jquery.tmpl');
    var cityinstit = require('lib/cityinstit');
    var activityCode = shan.tools.getUrlParam("activityCode");

    var f = {
        init: function(){
            $(function () {
                FastClick.attach(document.body);
                //cityinstit.linkCss();
            });

            //善诊用户协议
            $('#sDealCheck').click(function () {
                if ($(this).children('input[type="checkbox"]').prop('checked')) {
                    $(this).children('input[type="checkbox"]').prop('checked', false);
                    $('#confirmBtn').addClass('yo-btn-disabled');
                }
                else {
                    $(this).children('input[type="checkbox"]').prop('checked', true);
                    $('#confirmBtn').removeClass('yo-btn-disabled');
                }
            });
            
            $('#sDealBtn').click(function () {
                $('#pmask').removeClass('hidden');
                $('#userAgreement').show();
            });
            $('.pCloseBtn').click(function () {
                $('#userAgreement').hide();
                $('#pmask').addClass('hidden');
            });
            $('#pmask').click(function () {
                $('#userAgreement').hide();
                $('#verifyCode').addClass('hidden');
                $('#pmask').addClass('hidden');
            });

            $('#watchMore').click(function(){
                $(this).parent('.add-item-inner').removeClass('hasMoreInfo');
                $(this).hide();
                shan.tools.statisticsPing("100012");
            });

            $('#watchMore_2').click(function(){
                $(this).parent('.add-item-inner').removeClass('hasMoreInfo');
                $(this).hide();
            });

        }
    };

    //兑换口令浮层
    var exchangeCouponDialog = pop.layer({
        ele: $('#exchangeCouponDialog'),
        onShow: function () {
            // 54009    活动框架—下单页—兑换抵扣券浮层展现
            shan.tools.statisticsPing("54009");
        },
        bindEvent: function (layer) {
            layer.ele.find('#exchangeCouponBtn').off('touchend').on('touchend', function (e) {
                var szCodeInput = $('#exChangeCouponInput');
                if (szCodeInput.val() != "") {
                    order.exchangeCoupon(szCodeInput.val());
                }
                else {
                    pop.alert("请输入兑换口令");
                }
                // 54010    活动框架—下单页—兑换抵扣券浮层—兑换按钮
                shan.tools.statisticsPing("54010");
                e.preventDefault();
            });
        }
    });

    //没有兑换卷浮层
    var noTicketDialog = pop.layer({
        ele: $('#noTicketDialog'),
        bindEvent: function (layer) {
            layer.ele.find('.haveSzCode').off('touchend').on('touchend', function (e) {
                layer.hide();
                sharePromptDialog.hide();
                exchangeCouponBottomDialog.show();
                exchangeCouponDialog.show();
                // 54008    活动框架—下单页—无抵扣券浮层—我有善诊口令
                shan.tools.statisticsPing("54008");
                e.preventDefault();
            });
        }
    });

    //兑换卷列表浮层
    var ticketListDialog = pop.layer({
        ele: $('#ticketListDialog'),
        bindEvent: function (layer) {
            layer.ele.find('.haveSzCode').off('touchend').on('touchend', function (e) {
                layer.hide();
                exchangeCouponDialog.show();
                // 54007    活动框架—下单页—抵扣券浮层—我有善诊口令
                shan.tools.statisticsPing("54007");
                e.preventDefault();
            });
            layer.ele.find('#couponChooseBtn').off('touchend').on('touchend', function (e) {
                if (order.isNeedConfirm) {
                    order.confirmOrder();
                }
                else {
                    layer.hide();
                }
                e.preventDefault();
            });
        }
    });

    //兑换口令卷-兑换按钮
    var exchangeCouponBottomDialog = pop.layer({
        ele: $('#exchangeCouponBottom'),
        mask: false
    });

    //口令用完-显示分享层
    var sharePromptDialog = pop.layer({
        ele: $('#sharePrompt'),
        mask: false,
        bindEvent: function (layer) {
            layer.ele.find('.shareList').off('touchend').on('touchend', function (e) {
                share.shareTipsLayer.show();
                e.preventDefault();
            });
        }
    });

    var powerEmbody = $("#powerEmbody").val();
    var powerParalleling = $("#powerParalleling").val();

    if(powerEmbody){ 
        Vue.component('order-embody',{
            data: function(){
                return {
                    isOpen: false,
                    isOpenAdded1: false,
                    isOpenAdded2: false 
                };
            },
            props: ['goodsCode'],
            methods: {
                open: function(){
                    if (this.isOpen) { //取消选中
                        shan.tools.statisticsPing("100011");
                        this.isOpen = false;
                        this.isOpenAdded1 = false;
                        this.isOpenAdded2 = false;
                        this.$emit("sel-goods", -1);

                        if(g_source == 2){
                            shan.tools.statisticsPing(100005);
                        }else{
                            shan.tools.statisticsPing(100004);
                        }
                    }
                    else { //选中
                        shan.tools.statisticsPing("100010");
                        this.isOpen = true;
                        this.isOpenAdded1 = false;
                        this.isOpenAdded2 = false;
                        this.$emit("sel-goods", 0);

                        if(g_source == 2){
                            shan.tools.statisticsPing(100003);
                        }else{
                            shan.tools.statisticsPing(100002);
                        }
                    }
                },
                openAdded1: function(){
                    if(this.isOpenAdded1){ //取消选中
                        shan.tools.statisticsPing("100014");
                        this.isOpenAdded1 = false;
                        this.isOpenAdded2 = false;
                        this.$emit("sel-goods", 0);
                    }
                    else{ //选中
                        shan.tools.statisticsPing("100013");
                        this.isOpenAdded1 = true;
                        this.isOpenAdded2 = false;
                        this.$emit("sel-goods", 1);
                    }
                },
                openAdded2: function(){
                    if(this.isOpenAdded2){ //取消选中
                        shan.tools.statisticsPing("100016");
                        this.isOpenAdded1 = false;
                        this.isOpenAdded2 = false;
                        this.$emit("sel-goods", 0);
                    }
                    else{ //选中
                        shan.tools.statisticsPing("100015");
                        this.isOpenAdded1 = false;
                        this.isOpenAdded2 = true;
                        this.$emit("sel-goods", 2);
                    }
                }
            }
        });

    }

    if(powerParalleling == 1 || powerParalleling ==2){
        Vue.component('order-paralle',{
            data: function(){
                return {
                    isOpenAdded1: false,
                    isOpenAdded2: false 
                };
            },
            methods: {
                openAdded1: function(){
                    if(this.isOpenAdded1){ //取消选中
                        this.isOpenAdded1 = false;
                        this.isOpenAdded2 = false;
                        this.$emit("sel-goods", -1);
                    }
                    else{ //选中
                        this.isOpenAdded1 = true;
                        this.isOpenAdded2 = false;
                        this.$emit("sel-goods", 0);
                    }
                },
                openAdded2: function(){
                    if(this.isOpenAdded2){ //取消选中
                        this.isOpenAdded1 = false;
                        this.isOpenAdded2 = false;
                        this.$emit("sel-goods", -1);
                    }
                    else{ //选中
                        this.isOpenAdded1 = false;
                        this.isOpenAdded2 = true;
                        this.$emit("sel-goods", 1);
                    }
                }
            }
        });

    }
    else if(powerParalleling == 3){
        Vue.component('order-paralle', {
            data: function () {
                return {
                    isOpenAdded1: false,
                    isOpenAdded2: false,
                    isOpenAdded3: false
                };
            },
            methods: {
                countGoods: function(){
                    if(this.isOpenAdded1 && !this.isOpenAdded2 && !this.isOpenAdded3){ //选1
                        this.$emit("sel-goods", 0);
                    }else if(!this.isOpenAdded1 && this.isOpenAdded2 && !this.isOpenAdded3){ //选2
                        this.$emit("sel-goods", 1);
                    }else if(!this.isOpenAdded1 && !this.isOpenAdded2 && this.isOpenAdded3){ //选3
                        this.$emit("sel-goods", 2);
                    }else if(this.isOpenAdded1 && this.isOpenAdded2 && !this.isOpenAdded3){ //选1 2
                        this.$emit("sel-goods", 3);
                    }else if(this.isOpenAdded1 && !this.isOpenAdded2 && this.isOpenAdded3){//选1 3
                        this.$emit("sel-goods", 4);
                    }else if(!this.isOpenAdded1 && this.isOpenAdded2 && this.isOpenAdded3){//选2 3
                        this.$emit("sel-goods", 5);
                    }else if(this.isOpenAdded1 && this.isOpenAdded2 && this.isOpenAdded3){ //选1 2 3
                        this.$emit("sel-goods", 6);
                    }else{
                        this.$emit("sel-goods", -1);
                    }
                },
                openAdded: function (index) {
                    if(index == 1){
                        this.isOpenAdded1 = !this.isOpenAdded1;
                        if(this.isOpenAdded1){
                            shan.tools.statisticsPing(330079);
                        }
                        else{
                            shan.tools.statisticsPing(330080);
                        }
                    }
                    else if(index == 2){
                        this.isOpenAdded2 = !this.isOpenAdded2;
                        if(this.isOpenAdded2){
                            shan.tools.statisticsPing(330082);
                        }
                        else{
                            shan.tools.statisticsPing(330083);
                        }
                    }
                    else if(index == 3){
                        this.isOpenAdded3 = !this.isOpenAdded3;
                        if(this.isOpenAdded3 && g_source != 2){
                            shan.tools.statisticsPing(330084);
                        }
                        else if(!this.isOpenAdded3 && g_source != 2){
                            shan.tools.statisticsPing(330085);
                        }
                        else if(this.isOpenAdded3 && g_source == 2){
                            shan.tools.statisticsPing(330086);
                        }
                        else if(!this.isOpenAdded3 && g_source == 2){
                            shan.tools.statisticsPing(330087);
                        }
                    }
                    this.countGoods();
                }
            }
        });
    }

    var order = new Vue({
        el: "#orderDetail",
        data: {
            powerEmbody: false, //复合升级的开关
            powerParalleling: false, //并列升级的开关
            defaultGoodsCode: "", //原始商品ID,
            defaultGoodsName: "", //原始商品名称,
            goodsName: "", //商品名称
            goodsCode: "", //商品ID（可能会变化）
            cityBoxShow: false,     //可选城市（孝心套餐时显示）
            originPrice: 0, //商品原价（不变）
            activityPrice: 0, //商品原活动价（不变）
            actualOrgPrice: 0, //商品的实际原价
            actualPrice: 0, //下单的实际价格
            servicePrice: 0, //服务产品的价格
            addedPrice: 0, //附加项目的价格
            ticketStatusClass: "", //使用卷状态 hasTicket noTicket needLogin
            ticketSrc: "",//不用使用卷状态下的icon
            ticketText: "", //不用使用卷状态下的文字描述
            hasTicketText: "", //选择了卷后的文字描述
            contactPhone: "", //用户联系电话
            isLogin: 0, //是否登录
            ticketStatusShow: false, //是否展示"请选择券按钮" 仅仅在hasTicket状态下展示
            isHasTicket: false, //用户是否持有优惠卷
            isNeedConfirm: false, //是否选择了优惠卷立即下单
            isUseTicket: false, //用户是否选择了优惠卷
            couponIds: "", //用户选择的卷ID
            ticketAmt: 0, //用户选择的卷面价格
            phoneVerifyCode: "", //电话验证码
            isApiLoading: false, //是否正确请求中
            serviceCode: "", //服务单ID
            testVersion: "", //订单埋点上报
            orderFrom: 1, //订单来源 1主站 2活动框架
            isFirstOrder: true, //是否第一次下单 0是 1不是
            phoneHeaderTxet: "", //已经登录时展示'当前账号'  否则'+86'
            currentTimer: 60, //收到验证码后的等待时间 
            isSendingCode: false, // 是否发送验证码
            timerId: "", //监听等待时间的id
            verifyCodeBtnTxt: "获取验证码",
            goodsData: {}, // 升级项的数据
            source: 0,
            activityCode: activityCode
        },
        created: function(){
            try{
                var obj = JSON.parse(g_goods),
                    goods = obj.goods;

                this.defaultGoodsCode = goods.goodsCode;
                this.defaultGoodsName = goods.goodsName;
                this.goodsName = goods.goodsName;
                this.goodsCode = goods.goodsCode;
                this.originPrice = goods.originPrice / 1000;
                this.activityPrice = goods.activityPrice / 1000;
                this.actualOrgPrice = this.originPrice;
                this.actualPrice = this.activityPrice;
                this.supportSzServiceList = goods.supportSzServiceList ? goods.supportSzServiceList : [];
                this.isLogin = g_isLogin;
                this.source = g_source;
                //如果用户登录了 并且持有卷就默认帮他使用卷
                if(this.isLogin == 1 && obj.ticketNum != 0){
                    this.isHasTicket = true;
                    this.ticketAmt = obj.ticketAmt;
                    //this.couponIds.push(obj.couponIds);
                    this.couponIds = obj.couponIds;
                    this.ticketStatus = true;
                }
                else{
                    this.ticketStatus = false;
                }
                //孝心套餐则显示可选城市按钮
                if(this.defaultGoodsCode == 'GDS110010001'){
                    this.cityBoxShow = true;
                }
                this.contactPhone = obj.contactPhone;
                this.powerEmbody = $("#powerEmbody").val();
                this.powerParalleling = $("#powerParalleling").val();
                this.orderFrom = shan.tools.getUrlParam("orderFrom");
                if(this.powerEmbody == 1){
                    this.goodsData = [
                        {
                            'goodsCode': 'GDS110010002',
                            'addedPrice': 99,
                            'goodsName': '关爱父母孝心升级套餐'
                        },
                        {
                            'goodsCode': 'GDS111010002',
                            'addedPrice': 198,
                            'goodsName': '关爱父母加强升级(女)套餐'
                        },
                        {
                            'goodsCode': 'GDS111010003',
                            'addedPrice': 198,
                            'goodsName': '关爱父母加强升级(男)套餐'
                        }
                    ];
                }

                if(this.powerParalleling == 1){
                    this.goodsData = [
                        {
                            'goodsCode': 'GDS111010002',
                            'addedPrice': 99,
                            'goodsName': '关爱父母加强升级(女)套餐'
                        },
                        {
                            'goodsCode': 'GDS111010003',
                            'addedPrice': 99,
                            'goodsName': '关爱父母加强升级(男)套餐'
                        }
                    ];
                }
                else if(this.powerParalleling == 2){
                    this.goodsData = [
                        {
                            'goodsCode': 'GDS281722014',
                            'addedPrice': 99,
                            'goodsName': '基础体检套餐（升级）'
                        }
                    ];
                }
                else if(this.powerParalleling == 3 && this.source != 2 ){
                    this.goodsData = [
                        {
                            'goodsCode': 'GDS807168351',
                            'addedPrice': 199,
                            'goodsName': '关爱父母高级升级A套餐'
                        },
                        {
                            'goodsCode': 'GDS172859584',
                            'addedPrice': 79,
                            'goodsName': '关爱父母高级升级B套餐'
                        },
                        {
                            'goodsCode': 'GDS357711094',
                            'addedPrice': 109,
                            'goodsName': '关爱父母高级升级C套餐'
                        },
                        {
                            'goodsCode': 'GDS887251836',
                            'addedPrice': 278,
                            'goodsName': '关爱父母高级升级E套餐'
                        },
                        {
                            'goodsCode': 'GDS778124688',
                            'addedPrice': 309,
                            'goodsName': '关爱父母高级升级F套餐'
                        },
                        {
                            'goodsCode': 'GDS612037083',
                            'addedPrice': 188,
                            'goodsName': '关爱父母高级升级G套餐'
                        },
                        {
                            'goodsCode': 'GDS467482874',
                            'addedPrice': 387,
                            'goodsName': '关爱父母高级升级D套餐'
                        }
                    ];
                }else if(this.powerParalleling == 3 && this.source == 2 ){
                    this.goodsData = [
                        {
                            'goodsCode': 'GDS807168351',
                            'addedPrice': 199,
                            'goodsName': '关爱父母高级升级A套餐'
                        },
                        {
                            'goodsCode': 'GDS172859584',
                            'addedPrice': 79,
                            'goodsName': '关爱父母高级升级B套餐'
                        },
                        {
                            'goodsCode': 'GDS403282209',
                            'addedPrice': 159,
                            'goodsName': '关爱父母高级升级H套餐'
                        },
                        {
                            'goodsCode': 'GDS887251836',
                            'addedPrice': 278,
                            'goodsName': '关爱父母高级升级E套餐'
                        },
                        {
                            'goodsCode': 'GDS575315529',
                            'addedPrice': 358,
                            'goodsName': '关爱父母高级升级I套餐'
                        },
                        {
                            'goodsCode': 'GDS309054348',
                            'addedPrice': 238,
                            'goodsName': '关爱父母高级升级J套餐'
                        },
                        {
                            'goodsCode': 'GDS536893824',
                            'addedPrice': 437,
                            'goodsName': '关爱父母高级升级K套餐'
                        }
                    ];
                }

                this.countPrice();

            }catch(e){
                pop.alert("初始化商品失败",function(){
                    history.go(-1);
                    return false;
                });
            }
            
        },
        computed: {
            ticketStatus: {
                set: function(isUseTicket){

                    if(this.isLogin == 0){ //未登录
                        this.ticketStatusClass = "needLogin";
                        this.ticketText = "登录后查看";
                        this.ticketSrc = "/static/images/redPacket/icon_ticket_none.png";
                        this.phoneHeaderTxet = "+ 86";
                        this.ticketStatusShow = false; 
                        this.isUseTicket = false;
                        this.isHasTicket = false;
                    }
                    else{
                        this.phoneHeaderTxet = "当前账号";
                        if(isUseTicket){ //使用卷
                            this.ticketStatusClass = "hasTicket";
                            this.ticketText = "";
                            this.ticketStatusShow = true;
                            this.ticketSrc = "/static/images/redPacket/icon_ticket.png";
                            this.isUseTicket = true;
                            this.hasTicketText = "已减免" + this.ticketAmt;
                            this.isHasTicket = true;
                        }
                        else{ //没有使用优惠卷
                            if(this.isHasTicket){ //有优惠卷
                                this.ticketStatusClass = "hasTicket";
                                this.ticketText = "";
                                this.ticketStatusShow = true;
                                this.ticketSrc = "/static/images/redPacket/icon_ticket.png";
                                this.isUseTicket = false;
                                this.hasTicketText = "请选择券";
                            }
                            else{ //没有优惠卷
                                this.ticketStatusClass = "noTicket";
                                this.ticketText = "暂无可用券";
                                this.ticketSrc = "/static/images/redPacket/icon_ticket_none.png";
                                this.ticketStatusShow = false;
                                this.isUseTicket = false;
                            }
                            
                        }
                    }
                    
                }
            }
        },
        methods: {
            addedGoods: function(index){
                if(index != "-1" && typeof this.goodsData[index] != "undefined"){
                    this.goodsCode = this.goodsData[index].goodsCode;
                    this.goodsName = this.goodsData[index].goodsName;
                    this.addedPrice = this.goodsData[index].addedPrice;
                }
                else{
                    this.goodsCode = this.defaultGoodsCode;
                    this.goodsName = this.defaultGoodsName;
                    this.addedPrice = 0;
                }
                this.countPrice();
            },
            selTicket: function(){
                if(this.isLogin == 0){ //未登录
                    if (shan.tools.isWeixin() == 1) {
                        window.location.href = "/sz/user/bindphone";
                    }
                    else {
                        window.location.href = "/sz/user/smslogin";
                    }
                }
                else{
                    if(this.isUseTicket){ //有使用卷
                        this.isNeedConfirm = false;
                        this.getTicketInfo();
                        ticketListDialog.show();
                        shan.tools.statisticsPing("54005");
                    }
                    else{ //没有使用优惠卷
                        if(this.isHasTicket){ //有优惠卷
                            this.isNeedConfirm = false;
                            this.getTicketInfo();
                            ticketListDialog.show();
                        }
                        else{ //没有优惠卷
                            exchangeCouponDialog.show();
                            shan.tools.statisticsPing("54006");
                        }
                        
                    }
                }

            },
            exchangeCoupon: function (szCode) {
                shan.ajax({
                    data: {
                        url: '/coupon/exchange_coupon.htm',
                        szCode: szCode
                    },
                    success: function (_json) {
                        if (_json && _json.SZ_HEAD && _json.SZ_HEAD.RESP_CODE == "S0000") {
                            pop.message.show(_json.SZ_BODY.EXCHANGE_MSG);
                            if (_json.SZ_BODY.EXCHANGE_STATUS == 'EXCHANGE_SUCC') {
                                //todo 显示获取到的抵扣券
                                exchangeCouponDialog.hide();
                                //展示兑换卷列表
                                ticketListDialog.show();
                                order.isHasTicket = true;
                                order.isHasTicket = true;
                                order.getTicketInfo();
                                order.ticketStatus = false;
                            }
                            else {
                                if (_json.SZ_BODY.SHOW_SHARE_COUPON == 1 && shan.tools.isWeixin() == 1) {
                                    //展示分享层
                                    // sharePromptDialog.show();
                                    // exchangeCouponBottomDialog.hide();
                                    // var channelCode = _json.SZ_BODY.CHANNEL_CODE || "";
                                    // var activityCode = _json.SZ_BODY.ACTIVITY_CODE || "";
                                    // //分享获券同步渠道
                                    // order.syncChannelCode(channelCode, activityCode);
                                }
                                else {
                                    pop.alert(_json.SZ_BODY.EXCHANGE_MSG);
                                }
                            }

                        }
                    }
                });
            },
            checkOrder: function(){
                if(!/^1\d{10}/.test(this.contactPhone)){
                    pop.alert("请输入正确的手机号码");
                    return false;
                }

                if (this.isLogin == '0' && !/\d{6}/.test(this.phoneVerifyCode)) {
                    pop.alert("请输入正确的手机验证码");
                    return false;
                }

                if (!$('#sDealCheck').children('input[type="checkbox"]').prop('checked')) {
                    pop.alert("同意《善诊用户协议》才能进行下一步");
                    return false;
                }
                return true;
            },
            resetCodeTimer: function () {
                this.currentTimer = 60;
                function refresh() {
                    order.currentTimer--;
                    if (order.currentTimer >= 0) {
                        order.verifyCodeBtnTxt = order.currentTimer + 's 重新发送';
                        order.isSendingCode = true;
                    }else {
                        order.verifyCodeBtnTxt = '获取验证码';
                        order.isSendingCode = false;
                        clearInterval(order.timerId);
                    }
                    
                }
                this.timerId = setInterval(refresh,1000);
            },
            sendVerifyCode: function () {
                if( !/^1\d{10}/.test(this.contactPhone) ){
                    pop.alert("请输入正确的手机号码!");
                    return false;
                }

                if ( !this.isSendingCode ) {
                    this.isSendingCode = true;
                    this.resetCodeTimer();
                    shan.ajax({
                        url : "/sz/index/smsverify",
                        data : {
                            phone : this.contactPhone
                        },
                        success: function(_json){
                            order.isSendingCode = false;
                            if(_json.SZ_HEAD.RESP_CODE === "S0000"){
                                pop.alert("验证码已成功发送至您手机中");
                            }
                            else if (_json.SZ_HEAD.RESP_CODE === "-2") {
                                pop.alert("抱歉，该手机号未注册");
                            } 
                            else if (_json.SZ_HEAD.RESP_CODE === "3") {
                                pop.alert("抱歉，该手机登陆次数过多 请等30分钟后重试");
                            }
                            else if (_json.SZ_HEAD.RESP_CODE === "5") {
                                pop.alert("抱歉，请刷新页面后重新输入验证码");
                            }
                            else {
                                pop.alert("发送失败请稍后再试");
                            }
                            
                        }
                    });
                }
            },
            confirmOrder: function () {

                if(!this.checkOrder()){
                    return;
                }

                // 登录 没有使用券 但是持有券 第一次下单
                if (this.isLogin == 1 && !this.isUseTicket && this.isHasTicket && this.isFirstOrder) {
                    this.isFirstOrder = false;
                    this.isNeedConfirm = true; //选择券后立即下单
                    this.getTicketInfo();
                    ticketListDialog.show();
                    return;
                }

                //决定testVersion
                this.getTestVersion();
                //用户路径埋点
                if(this.goodsCode == "GDS111010002" || this.goodsCode == "GDS111010003"){
                    shan.tools.statisticsPing(11152235);
                }
                else if(this.goodsCode == "GDS110010002"){
                    shan.tools.statisticsPing(12252234);
                }
                else{
                    shan.tools.statisticsPing(13352234);
                }
                if(this.powerParalleling == "3"){
                    shan.tools.statisticsPing(330088);
                }

                this.isApiLoading = true;


                shan.ajax({
                        url: '/sz/order/tob_confirmport_async',
                        data: {
                            goodsCode: this.goodsCode,
                            contactPhone: this.contactPhone,
                            personCount: 1,
                            szCode: '',
                            phoneVerifyCode: this.phoneVerifyCode,
                            serviceCodes: this.serviceCode,
                            testVersion: this.testVersion,
                            couponIds: this.couponIds,
                            isFirstOrder: this.isFirstOrder,
                            orderFrom: this.orderFrom
                        },
                        type: 'post',
                        success: function (_json) {
                            order.isApiLoading = false;
                            order.isFirstOrder = false;
                            if (_json.SZ_HEAD.RESP_CODE != 'S0000') {
                                //登录状态:改变文字/手机号变灰
                                if (_json.SZ_HEAD.RESP_CODE == 1) { //没有券
                                    order.isLogin = 1;
                                    order.useTiket = false;
                                    $('#exchangeInfo').html('抵扣券可在' + order.contactPhone + '的个人中心查看');
                                    exchangeCouponDialog.show();
                                    
                                }
                                else if (_json.SZ_HEAD.RESP_CODE == 2) { //有卷
                                    //展示兑换券列表
                                    order.isLogin = 1;
                                    order.useTiket = true;
                                    order.getTicketInfo();
                                    ticketListDialog.show();
                                    order.isNeedConfirm = true;
                                }
                                else if (_json.SZ_HEAD.RESP_CODE == 3) { //免费套餐没有使用卷
                                    pop.alert("此套餐为活动体验套餐，请输入善诊口令或使用口令券");
                                    return false;
                                }
                                else if(_json.SZ_HEAD.RESP_CODE == "B502"){
                                	pop.message.show("下单已成功，请勿重复下单");
                                	return;
                                }
                                else {
                                    pop.message.show(_json.SZ_HEAD.RESP_MSG);
                                    return;
                                }

                            } else {
                                //if (_json.SZ_BODY.price) {
                                    shan.tools.statisticsPing(350050101);
                                    //window.location.replace('/sz-pay.php?orderCode=' + _json.SZ_BODY.orderCode);
                                    window.location.replace('/sz/order/shopping_pay?shoppingId=' + _json.SZ_BODY.shoppingId + "&orderFrom=" + order.orderFrom+"&activityCode="+this.activityCode);
            
                                //}
                                // else {
                                //     shan.tools.statisticsPing(3500501);
                                //     if(order.orderFrom == 2){
                                //         window.location.replace('/sz/cooperate/result?status=1&orderCode=' + _json.SZ_BODY.orderCode+"&DATA=11152234");
                                //     }
                                //     else{
                                //         window.location.replace('/sz/order/result?status=1&orderCode=' + _json.SZ_BODY.orderCode+"&DATA=11152234");
                                //     }
                                    
                                // }
                            }

                        }
                    }
                );
                return false;
            },
            getTestVersion: function(){
                if (g_source == 2) {
                    this.testVersion = 2;
                }else if (g_source == 1) {
                    this.testVersion = 1;
                }else{
                    this.testVersion = 0;
                }
                
                this.testVersion += "_" + this.orderFrom;
            },
            getTicketInfo: function () {
                shan.ajax({
                    data: {
                        url: '/coupon/coupon_count.htm',
                        goodsCode: this.goodsCode
                    },
                    success: function (_json) {
                        
                        if (_json.SZ_HEAD.RESP_CODE != 'S0000') {
                            pop.alert(_json.SZ_HEAD.RESP_MSG);
                        }
                        else {
                            if (_json.SZ_BODY.COUPON_COUNT == 0) { //没有兑换券
                                order.isHasTicket = false;
                                if(_json.SZ_BODY.COUPON_LIST_D.length > 0){
                                    order.renderTicket(_json.SZ_BODY.COUPON_LIST_D, ticketListDialog);
                                }
                            }
                            else { //有兑换券
                                order.isHasTicket = true;
                                order.renderTicket(_json.SZ_BODY.COUPON_LIST_D, ticketListDialog);
                            }

                        }
                    }
                });
            },
            renderTicket: function (list, layer) {

                if (this.isUseTicket) {
                    //list.chooseTicketCode = this.couponIds[0];
                    list.chooseTicketCode = this.couponIds;
                }

                if (list.length > 0) {
                    layer.ele.find('.haveSzCode').hide();
                }

                layer.ele.find('.red-packet-ticket-list').html("").html($('#dmyTicketList').tmpl(list, {
                    getInput: function (spr) {
                        if (list.chooseTicketCode == this.data.id) {
                            return '<input type="checkbox" name="project13" checked="checked"/>';
                        } else {
                            return '<input type="checkbox" name="project13" />';
                        }
                    },
                    isFree: function () {
                        if (order.activityPrice == 0) {
                            return true;
                        }
                        else {
                            return false;
                        }
                    }
                }));

                //选择口令券
                layer.ele.off('click').on('click', 'li', function () {
                    if (!$(this).hasClass('text-disabled')) {
                        if ($(this).find('input[type="checkbox"]').prop('checked')) {
                            $(this).find('input[type="checkbox"]').prop('checked', false);
                            //order.couponIds = [];
                            order.couponIds = "";
                            order.ticketAmt = 0;
                            order.isHasTicket = true;
                            order.ticketStatus = false;
                            
                        }
                        else {
                            if (order.isUseTicket) {
                                layer.ele.find('.red-packet-ticket input[type="checkbox"]').attr('checked', false);
                                //order.couponIds = [];
                                order.couponIds = "";
                            }
                            $(this).find('input[type="checkbox"]').prop('checked', true);
                            //order.couponIds.push($(this).data('code'));
                            order.couponIds = $(this).data('code');
                            order.ticketAmt = parseInt($(this).data('price'));
                            order.ticketStatus = true;
                        }
                        order.countPrice();
                    }
                });

                /*var ticketWidth = 3.75 * 0.9 - 0.16 * 2;
                layer.ele.find('.red-packet-ticket-list li').css('height', parseInt(ticketWidth * 0.351 * 100, 10) / 100 + 0.05 + 'rem');*/
            },
            countPrice: function(){
                var actualPrice = 0;
                if(this.isUseTicket){//使用卷
                    actualPrice = this.originPrice + this.servicePrice + this.addedPrice - this.ticketAmt;
                }
                else{
                    actualPrice = this.activityPrice + this.servicePrice + this.addedPrice;
                }
                
                this.actualPrice = actualPrice>=0?actualPrice:0;
                this.actualOrgPrice = this.originPrice + this.servicePrice + this.addedPrice;
            },
            syncChannelCode: function(channelCode, activityCode) {
                shan.ajax({
                    url: '/sz/cooperate/syncChannel',
                    data: {
                        key: g_key,
                        channelCode: channelCode,
                        activityCode: activityCode
                    },
                    success: function (_json) {
                        if (_json && _json.SZ_HEAD && _json.SZ_HEAD.RESP_CODE == "S0000") {
                            g_key = _json.SZ_BODY.DATA;

                            //分享获券
                            share.wxShare({
                                key: g_key,
                                success: function (copy) {
                                    share.shareSuccessCallback({
                                        key: g_key,
                                        channelCode: channelCode,
                                        activityCode: activityCode,
                                        GAIN_SUCC: function (list) {
                                            share.inviteSuccessDialog.ele.find('.btn-list a:first-child').attr('href', copy.activityUrl);
                                            share.inviteSuccessDialog.show(list);
                                        }
                                    });
                                    exchangeCouponDialog.hide();
                                    share.shareTipsLayer.hide();
                                    shan.tools.statisticsPing("52002", {sourceCode: g_key});
                                }
                            });
                        }
                    }
                });
            },
            //孝心套餐获取城市列表
            getCityList: function(){
                cityinstit.run({
                    goodsCode: this.goodsCode,
                    onChoose: function () {
                        //do nothing
                    }
                });
            }
        }
    });

    var run = function () {
        f.init();
    };

//初始化函数
    exports.run = run;
});



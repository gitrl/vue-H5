define(function (require, exports, module) {
    //var $ = require('jquery');
    var shan = require('lib/shan_base');
    require('lib/vue/vue.min');
    //require('lib/share/wxshare');
    //require('lib/mustache');
    //var pop = require('lib/dialog');
    // var share = require('lib/shan_share');
    var _status = shan.tools.getUrlParam("status");
    var orderCode = shan.tools.getUrlParam("orderCode");

    var f = {
        init : function(){
            var _phase = 1;
            var toCommand = window.g_ifCommand || false;
            switch (parseInt(_status)){
                case 1:
                case 3:
                    _phase = 1;
                    break;
                case 4:
                case 5:
                    _phase = 2;
                    break;
                default:
                    _phase = 1;
                    break;
            }
            //页面展示埋点
            shan.tools.statisticsPing("54100");

            new Vue({
                el: '#content',
                data: {
                    status: _status,
                    ifCommand: toCommand,
                    noCommandObject: {
                        'no-command-btn': !toCommand
                    }
                },
                methods: {
                    //点击立即预约
                    toReserve: function(){
                        //window.location.href = "/sz/order/appointment?orderCode=" + orderCode;
                        window.location.href = "/sz/order/order_list";
                        shan.tools.statisticsPing("54102",{sourceCode:g_activityCode});
                    },
                    //跳转到定制口令
                    toCommand: function(){
                        window.location.href = "/sz/cooperate/command?orderCode=" + orderCode + "&phase=" + _phase + "&orderFrom=1";
                        shan.tools.statisticsPing("54101",{sourceCode:g_activityCode});
                    },
                    //返回主页
                    toIndex: function(){
                        window.location.href = "/sz/index/index";
                    }
                }
            });





            /*$('#toReserve').on('click', function () {
                
                window.location.href = "/sz/order/appointment?orderCode="+orderCode;
                shan.tools.statisticsPing("54014");
                shan.tools.statisticsPing("54102");
            });*/
        },
        bindEvent: function() {
            /* var _phase = 1;
            if(_status == 1 || _status == 3 || _status == 4){ //支付成功&&预约成功&&新下单支付成功
                switch(parseInt(_status)){
                    case 1:
                        _phase = 1;
                        if(shan.tools.isWeixin() == 1){
                            shan.tools.statisticsPing("52004");
                            shan.tools.statisticsPing("54011", {sourceCode:g_activityCode || ""});
                        }
                        break;
                    case 3:
                        _phase = 2;
                        shan.tools.statisticsPing("53040");
                        break;
                    case 4:
                        _phase = 1;
                        break;
                    default:
                        break;
                }*/

                // share.wxShare({
                //     key: g_key,
                //     success: function (copy) {
                //         share.shareSuccessCallback({
                //             key: g_key,
                //             channelCode : g_channelCode,
                //             activityCode : g_activityCode,
                //             GAIN_SUCC: function (list) {
                //                 //主站固定跳转链接 
                //                 share.inviteSuccessDialog.ele.find('.btn-list a:first-child').attr('href', "/sz/index/index");
                //                 share.inviteSuccessDialog.show(list);
                //             }
                //         });
                //         share.shareTipsLayer.hide();

                //         switch(_status){
                //             case 1:
                //                 shan.tools.statisticsPing("52000", {sourceCode:g_key});
                //                 break;
                //             case 3:
                //                 shan.tools.statisticsPing("53042", {sourceCode:g_key});
                //                 break;
                //             default:
                //                 break;
                //         }
                //     }
                // });

               /* $('#openShareDialog').bind('click', function (e) {
                    switch(_status){
                        case 1:
                            shan.tools.statisticsPing("52011", {sourceCode:g_key});
                            break;
                        case 3:
                            shan.tools.statisticsPing("53041", {sourceCode:g_key});
                            break;
                        default:
                            break;
                    }
                    shan.tools.statisticsPing("54101");
                    window.location.href = "/sz/cooperate/command?orderCode=" + orderCode + "&phase=" + _phase;
                    //share.shareTipsLayer.show();
                    e.preventDefault();
                });

            }

            $(".c_close").click(function(e){
                $("#c_shareApp").hide();
                $("#c_shareErwei").hide();
                e.preventDefault();
            });*/
        }
    };

    var run = function () {
        f.init();
        //f.bindEvent();
    };

    //初始化函数
    exports.run = run;
});
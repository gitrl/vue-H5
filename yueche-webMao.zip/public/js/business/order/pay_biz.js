define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/vue/vue.min');

    const orderno = shan.tools.getUrlParam("orderno");
    const PAY_HANDLER_WX = 1;
    const PAY_HANDLER_ZFB = 2;

    var f = {
        init : function(){
            shan.tools.statisticsPing("370115");
            $(".yo-mask").click(function(){
                $(this).addClass("hidden");
                $(".to-brower").addClass("hidden");
            })
        }
    };

    var pay = new Vue({
        el: "#pay",
        data: {
            isNeedWxpay: 0,
            isSelWx: true,
            isSending: false,
            payType: PAY_HANDLER_WX

        },
        created: function () {
            if(!shan.tools.isWeixin() || this.isNeedWxpay == "0"){
                this.isSelWx = false;
                $("#zfbBtn").attr("checked", true);
            }
            this.isNeedWxpay = g_isNeedWxpay;
            this.payType = (shan.tools.isWeixin() && this.isNeedWxpay == "1")?PAY_HANDLER_WX:PAY_HANDLER_ZFB;
        },
        methods: {
            goBack: function(){
                history.go(-1);
            },
            selWx: function(){
                this.isSelWx = true;
                this.payType = PAY_HANDLER_WX;
                $("#wxBtn").attr("checked", true);

            },
            selZfb: function(){
                this.isSelWx = false;
                this.payType = PAY_HANDLER_ZFB;
                $("#zfbBtn").attr("checked", true);
            },
            confirm: function(){
                
                if(this.isSelWx){ //微信支付
                    shan.tools.statisticsPing("370116");
                    if(this.isSending){
                        pop.message.show('正在支付...');
                        return;
                    }
                    else{
                        this.isSending = true;
                    }
                      
                    pay.isSending = false;
                    try{
                        var data = JSON.parse(g_wxData);

                        wx.config( {
                            appId       : data.appId, 
                            timestamp   : data.timeStamp,
                            nonceStr    : data.nonceStr, 
                            signature   : data.paySign ,
                            jsApiList   : [ "chooseWXPay" ]
                        } );

                        wx.ready( function(){
                            wx.chooseWXPay({
                                timestamp: data.timeStamp , 
                                nonceStr: data.nonceStr, 
                                package: data.packageStr,
                                signType: data.signType, 
                                paySign: data.paySign, 
                                success: function( rtn ) {
                                    var url = "/sz/order/pay_result?payType="+pay.payType+"&orderno="+orderno+"&rs=1";
                                    window.location.href = url;
                                    return;
                                },
                                fail: function(){
                                    pop.message.show("微信支付失败");
                                    return;
                                }
                            });
                        } );
                    }catch(e){   
                        pop.message.show('微信支付初始化失败');
                    }

                }
                else{ //支付宝支付
                    shan.tools.statisticsPing("370117");
                    if(shan.tools.isWeixin() ){
                        $(".yo-mask").removeClass("hidden");
                        $(".to-brower").removeClass("hidden");
                    }
                    else{
                        if(this.isSending){
                            pop.message.show('正在支付...');
                            return;
                        }
                        else{
                            this.isSending = true;
                        }
                        
                        $("#alipayForm" ).submit();
                    }
                    
                }
            }
        }
    });

    var run = function () {
        f.init();
    }

    //初始化函数
    exports.run = run;
});
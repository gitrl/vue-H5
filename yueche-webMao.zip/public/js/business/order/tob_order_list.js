/**
 * Created by wayyue05 on 2017/2/21.
 */
define(function (require, exports, module) {
    var $ = require('jquery');
    require('lib/fastclick');
    require('lib/iscroll-probe');
    require('lib/vue/vue.min');
    var pop = require('lib/dialog');
    var shan = require('lib/shan_base');


    var vm,
        dataArr = [],
        ajaxDataArr = [],
        page = 2;

    var myScroll,
        loadingStep = 0;//加载状态0默认，1显示加载状态，2执行加载数据，只有当为0时才能再次加载，这是防止过快拉动刷新

    var f = {
        init: function(){
            var _self = this;
            $(function () {
                FastClick.attach(document.body);
            });
            //渲染第一页的数据
            try{
                var initData = JSON.parse(g_data.replace( /'/g , "\"" ).replace( /\s+/g , "" ));
                var initDataArr = initData.SZ_BODY.ORDER_DS;
                var initOrderArr = _self.getData(initDataArr,dataArr);
                vm = new Vue({
                    el: '#wrapper',
                    data: {
                        items: initOrderArr,
                        noOrder: 0,
                        noPop: 0,
                        noOpen: 0,
                    },
                    methods: {
                        popup: function(index){
                            if(this.items[index].free){
                                this.noPop = 1;
                            }
                            if(this.items[index].isOpen){
                                this.noOpen = 1;
                            }
                        },
                        close: function(){
                            this.noPop = 0;
                        },
                        closeOpenLayer: function(){
                            this.noOpen = 0;
                        }
                    }
                });
                if(!initDataArr || initDataArr.length < 1){//如无订单
                    vm.noOrder = 1;
                }
            }catch(e){
                pop.alert("系统异常，请稍后重试",function(){
                    history.go(-1);
                    return false;
                });
            }
            var pullUp = $("#pullUp"),
                pullUpLabel = $(".pullUpLabel"),
                pullUpTips = $(".pullup-tips"),
                list = $('#list');

            pullUp.hide();
            myScroll = new IScroll("#wrapper", {
                scrollbars: 'custom',
                mouseWheel: true,
                interactiveScrollbars: true,
                shrinkScrollbars: 'scale',
                fadeScrollbars: true,
                probeType: 2,
                bindToWrapper: true,
                tap: true,
                click: true
            });


            //手指向上拉动
            myScroll.on("scroll", function () {
                $('#list').css('margin-top',0);
                if (loadingStep == 0 && !(pullUp.hasClass('refresh') || pullUp.hasClass('loading'))) {
                    if (this.y < (this.maxScrollY + 60)) {//上拉加载更多
                        pullUpTips.hide();
                        pullUp.addClass("refresh").show();
                        pullUpLabel.text("加载中,请稍后...");
                        loadingStep = 1;
                        myScroll.refresh();
                    }
                }
            });

            //手指放开刷新
            myScroll.on("scrollEnd",function(){
                if(loadingStep == 1 && pullUp.hasClass("refresh")){//上拉刷新操作
                    pullUp.removeClass("refresh").addClass("loading");
                    pullUpLabel.text("正在加载...");
                    loadingStep = 2;
                    _self.pullUpAction();
                }
            });

            $(document).on('touchmove', function (e) {
                e.preventDefault();
            }, false);

            $("#goBack").bind("click",function(){
                if(g_orderFrom == 1){
                    window.location.href = "/sz/user/index";
                }
                else{
                    history.go(-1);
                }
            });
        },

        //下拉刷新
        pullUpAction: function(){
            var _self = this;
            setTimeout(function(){
                //ajax请求
                shan.ajax({
                    url: '/sz/order/order_list_async',
                    async : true,
                    data: {
                        currentPage: page
                    },
                    success: function(json){
                        if(typeof json != 'undefined' && json.SZ_HEAD.RESP_CODE == 'S0000' && json.SZ_BODY.ORDER_DS.length >= 1){
                            var getDataArr = json.SZ_BODY.ORDER_DS;
                            var ajaxData = _self.getData(getDataArr,ajaxDataArr);//获取数据
                            vm.items = vm.items.concat(ajaxData);
                            $("#pullUp").attr('class','').hide();
                            $(".pullup-tips").show();
                            $('#list').css('margin-top','-0.5rem');
                            ajaxDataArr = [];
                            page++;
                        }else{
                            $(".pullup-tips").show().text("没有更多订单了");
                            $("#pullUp").hide();
                        }
                    }
                });
                myScroll.refresh();
                loadingStep = 0;
            },50);
        },

        //获取数据
        getData: function(initArr,dataArr){
            var _self = this;
            for(var i=0,len=initArr.length;i<len;i++){
                dataArr[i]=function(num){
                    return initArr[num];
                }(i);
                dataArr[i].noProblem = true;
                dataArr[i].orderCode = dataArr[i].ORDER_D.orderCode;
                dataArr[i].orderFrom = dataArr[i].ORDER_D.orderFrom;
                dataArr[i].orderAmt = dataArr[i].ORDER_D.orderAmt;
                
                dataArr[i].orderDetailHref = '#';
                
                dataArr[i].goodsName = dataArr[i].ORDER_D.goodsName;
                dataArr[i].institName = dataArr[i].INSTIT_D.institName;
                dataArr[i].institAddr = dataArr[i].INSTIT_D.institAddr;
                dataArr[i].orderHeadClass = 'blue';
                dataArr[i].orderBtnClass = 'blue';
                dataArr[i].isNewReport = dataArr[i].ORDER_D.isNewReport;
                dataArr[i].orderBtnHref = dataArr[i].orderDetailHref;
                dataArr[i].isMiguPKG = dataArr[i].PKG_D.pkgName.indexOf('咪咕') != '-1' ? 1 : 0;  //咪咕添加vip套餐标识
                dataArr[i].unifiedOrderStatus = dataArr[i].ORDER_D.unifiedOrderStatus;
                dataArr[i].free = 0;
                dataArr[i].hasReverseTime = 0;
                dataArr[i].orderAmtStr = dataArr[i].ORDER_D.orderAmtStr;
                if(dataArr[i].ORDER_D.reserveTime){
                    dataArr[i].hasReverseTime = 1;
                    dataArr[i].reserveTime = dataArr[i].ORDER_D.reserveTime.substr(0, 10);
                    dataArr[i].reserveTime += _self.getDay(dataArr[i].reserveTime);
                }
                switch (dataArr[i].unifiedOrderStatus){
                    case 'NOPAY_NORESERVE':       //待支付
                        dataArr[i].noPay = true;
                        dataArr[i].orderStatus = '待支付';
                        dataArr[i].orderHeadClass = 'red';
                        dataArr[i].orderProblemText = '遇到支付/预约问题？';
                        dataArr[i].orderPayHref = '/sz/order/pay?orderCode=' + dataArr[i].orderCode + '&orderFrom=3';
                        break;
                    case 'NEED_RESERVE_PAYED':      //待预约
                        dataArr[i].orderStatus = '待预约';
                        dataArr[i].orderBtnText = '立即预约';
                        dataArr[i].orderProblemText = '遇到支付/预约问题？';
                        if(1){
                            dataArr[i].isOpen = true; //阻挡预约
                        }
                        else if(g_orderFrom == 1 || dataArr[i].orderAmt > 0){//主站||付费订单
                            dataArr[i].orderBtnHref = '/sz/order/appointment?orderCode=' + dataArr[i].orderCode;
                        }else{//活动框架-免费订单
                            dataArr[i].free = 1;
                        }
                        break;
                    case 'RESERVE_SUCC':        //已预约
                        dataArr[i].orderStatus = '已预约';
                        dataArr[i].orderBtnText = '查看体检注意事项';
                        dataArr[i].orderProblemText = '体检/修改预约问题？';
                        //dataArr[i].orderBtnHref = '/sz/user/problem_answer?no=9';
                        break;
                    case 'CHECK_FINISHED':      //体检完成
                        dataArr[i].orderStatus = '体检完成';
                        dataArr[i].orderBtnText = '5-7个工作日后查看报告';
                        dataArr[i].noProblem = false;
                        break;
                    case 'REPORT_UPLOAD':       //报告已出
                        dataArr[i].orderStatus = '报告已出';
                        dataArr[i].orderBtnText = '查看体检报告';
                        dataArr[i].orderHeadClass = 'green';
                        dataArr[i].orderBtnClass = 'green';
                        dataArr[i].noProblem = false;
                        if(dataArr[i].isNewReport == 1){
                            dataArr[i].orderBtnHref = '/sz/report/index/orderCode/' + dataArr[i].orderCode;
                        }else{
                            dataArr[i].orderBtnHref = '/sz-health-report.php?orderCode=' + dataArr[i].orderCode;
                        }
                        break;
                    case 'ORDER_CANCEL':        //已取消
                        dataArr[i].orderStatus = '已取消';
                        dataArr[i].orderBtnText = '订单已取消';
                        dataArr[i].orderHeadClass = 'gray';
                        dataArr[i].orderBtnClass = 'gray';
                        dataArr[i].noProblem = false;
                        break;
                    case 'ISRESERVE_NOPAY':     //未支付的待预约
                        dataArr[i].orderStatus = '待预约';
                        dataArr[i].orderBtnText = '支付后完成预约';
                        dataArr[i].orderHeadClass = 'red';
                        dataArr[i].orderBtnClass = 'red';
                        dataArr[i].orderProblemText = '遇到支付/预约问题？';
                        //dataArr[i].orderPayHref = '/sz/order/pay?orderCode=' + dataArr[i].orderCode;
                        break;
                    default :       //处理中
                        dataArr[i].orderStatus = '处理中';
                        dataArr[i].orderHeadClass = 'red';
                        dataArr[i].orderBtnClass = 'red';
                        dataArr[i].orderProblemText = '遇到支付/预约问题？';
                        dataArr[i].orderBtnText = '处理中';
                        break;
                }

            }
            return dataArr;
        },

        //换算成周几
        getDay: function(date) {
            var day = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
            var _date = new Date(date);
            return ' ' + day[_date.getDay()];
        }
    };

    var run = function () {
        f.init();
    };

    //初始化函数
    exports.run = run;
});

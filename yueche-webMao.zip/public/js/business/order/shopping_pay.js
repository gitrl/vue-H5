define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/vue/vue.min');
    require("lib/webview");

    const shoppingId = shan.tools.getUrlParam("shoppingId");
    const orderFrom = shan.tools.getUrlParam("orderFrom");
    const PAY_HANDLER_WX = 1;
    const PAY_HANDLER_ZFB = 2;

    var f = {
        init : function(){
            $(".yo-mask").click(function(){
                $(this).addClass("hidden");
                $(".to-brower").addClass("hidden");
            });

            if(shan.tools.isMyApp()){
                webView.register('payCallback', function(data, responseCallback) {
                    if(data && typeof data == "string"){
                        try{
                            data = JSON.parse(data);
                        }catch(e){
                            responseCallback({'data':'Failed'});
                            return;
                        }
                    }
                    if(data.status == "Succeeded") {
                        var url = "/sz/order/pay_result?orderCode=" + pay.orderCode + "&payResultApp=1&payType=" + pay.payType;
                        window.location.href = url;
                    }
                    responseCallback({'data':'Succeeded'});
                })
            }


        }
    };

    var pay = new Vue({
        el: "#pay",
        data: {
            isSelWx: true,
            isSending: false,
            orderCode: '',
            backHref:'javascript:history.go(-1);',
            aliAction: '',
            aliMethod: '',
            aliItems: [],
            wxInitData: {},
            payType: shan.tools.isWeixin()?PAY_HANDLER_WX:PAY_HANDLER_ZFB
        },
        created: function () {
            if(shan.tools.isWeixin() == 0){
                this.isSelWx = false;
                $("#zfbBtn").attr("checked", true);
            }
        },
        methods: {
            selWx: function(){
                this.isSelWx = true;
                this.payType = PAY_HANDLER_WX;
                $("#wxBtn").attr("checked", true);

            },
            selZfb: function(){
                this.isSelWx = false;
                this.payType = PAY_HANDLER_ZFB;
                $("#zfbBtn").attr("checked", true);
            },
            confirm: function(){
                if(!this.orderCode){
                    try{
                        //生成新订单获得orderCode
                        shan.ajax({
                            url: "/sz/order/confirm_pay_async",
                            data: {
                                shoppingId: shoppingId,
                                orderFrom: orderFrom
                            },
                            success: function(_json){
                                if (_json.SZ_HEAD.RESP_CODE == 'S0000'){
                                    pay.orderCode = _json.SZ_BODY.orderCode;
                                    pay.wxInitData = _json.SZ_BODY.wxInitData;
                                    pay.backHref = '/sz/order/order_list';
                                    var zfbData = _json.SZ_BODY.zfbData;
                                    if(zfbData != ""){
                                        pay.aliAction = zfbData['actionS'];
                                        pay.aliMethod = zfbData['methodS'];
                                        pay.aliItems = zfbData['dataS'];
                                    }
                                    if(pay.wxInitData != ''){
                                        wx.config( {
                                            appId       : pay.wxInitData.appId,
                                            timestamp   : pay.wxInitData.timeStamp,
                                            nonceStr    : pay.wxInitData.nonceStr,
                                            signature   : pay.wxInitData.paySign ,
                                            jsApiList   : [ "chooseWXPay" ]
                                        } );
                                    }
                                    pay.toPay(pay.orderCode);
                                }
                                else{
                                    //pop.alert(_json.SZ_HEAD.RESP_MSG);
                                    pop.alert('支付失败，请检查网络情况后重试~');
                                }
                            }
                        });
                    }catch(e){
                        pop.alert("订单生成失败，请稍后重试",function(){
                            history.go(-1);
                            return false;
                        });
                    }
                }else{
                    pay.toPay(pay.orderCode);
                }
            },
            toPay: function(orderCode){
                if(pay.isSelWx){ //微信支付
                    if(pay.isSending){
                        pop.message.show('正在支付...');
                        return;
                    }else{
                        pay.isSending = true;
                    }

                    if(shan.tools.isMyApp() == 1){ //app支付
                        webview.callHandler('configWXPayAction',
                            {'orderCode': orderCode},
                            function(response) {}
                        );
                    }
                    else{ //微信支付
                        wx.ready( function(){
                            wx.chooseWXPay({
                                timestamp: pay.wxInitData.timeStamp ,
                                nonceStr: pay.wxInitData.nonceStr,
                                package: pay.wxInitData.packageStr,
                                signType: pay.wxInitData.signType,
                                paySign: pay.wxInitData.paySign,
                                success: function( rtn ) {
                                    var url = "/sz/order/pay_result?payType="+pay.payType+"&orderCode="+orderCode+"&rs=1";
                                    window.location.replace(url);
                                } ,
                                fail: function(){
                                    pop.message.show("支付失败，请重试~");
                                    setTimeout(function(){
                                        pop.message.hide();
                                        window.location.href = "/sz/order/order_list";
                                    },2000);
                                }
                            });
                        });  
                    }
                }else{
                    if(shan.tools.isWeixin() == 1){
                        $(".yo-mask").removeClass("hidden");
                        $(".to-brower").removeClass("hidden");
                    }else{
                        if(pay.isSending){
                            pop.message.show('正在支付...');
                            return;
                        }else{
                            pay.isSending = true;
                        }

                        if(shan.tools.isMyApp() == 1){
                            webview.callHandler('configAliPayAction',
                                {'orderCode': orderCode},
                                function(response) {}
                            );
                        }
                        else{
                            setTimeout(function(){
                                $('#alipayForm').submit();
                            },0);
                        }
                        
                    }

                }
            }
        }
    });

    var run = function () {
        f.init();
    }

    //初始化函数
    exports.run = run;
});
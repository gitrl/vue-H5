define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/fastclick');

    var f;
    f = {
        data: {
            productList: {
                'GDS110010001': {
                    goodsName: '关爱父母孝心套餐',
                    price: 0
                },
                'GDS110010002': {
                    goodsName: '关爱父母孝心升级套餐',
                    price: 99
                },
                'GDS111010002': {
                    goodsName: '关爱父母加强升级(女)套餐',
                    price: 198
                },
                'GDS111010003': {
                    goodsName: '关爱父母加强升级(男)套餐',
                    price: 198
                }
            },
            defaultProductCode: 'GDS110010001',
            goodsCode: 'GDS110010001',
            orderCode: shan.tools.getUrlParam('orderCode'),
            isApiLoading: false,
            testVersion:'',
            orderFrom:shan.tools.getUrlParam('orderFrom')
        },
        upgradeRuleDialog: pop.layer({
            ele: $('#ruleDialog')
        }),
        dom: {
            fProductName: $('#fProductName'),
            fProductPrice: $('#fProductPrice'),
            womanUp: $('#womanUp'),
            manUp: $('#manUp'),
            pietyUp: $('#pietyUp')
        },
        //writeTestVersion: function () {
        //    var _self = this;
        //    switch (_self.data.goodsCode) {
        //        case 'GDS110010001':
        //            if (shan.tools.isWeixin() == 1) {
        //                if (shan.tools.getMobileOperatingSystem() == "iOS") {
        //                    _self.data.testVersion = '12-3';
        //                }
        //                else {
        //                    _self.data.testVersion = '12-4';
        //                }
        //            }
        //            else {
        //                if (shan.tools.getMobileOperatingSystem() == "iOS") {
        //                    _self.data.testVersion = '12-7';
        //                }
        //                else {
        //                    _self.data.testVersion = '12-8';
        //                }
        //            }
        //            break;
        //        case 'GDS110010002':
        //            if (shan.tools.isWeixin() == 1) {
        //                if (shan.tools.getMobileOperatingSystem() == "iOS") {
        //                    _self.data.testVersion = '13-3';
        //                }
        //                else {
        //                    _self.data.testVersion = '13-4';
        //                }
        //            }
        //            else {
        //                if (shan.tools.getMobileOperatingSystem() == "iOS") {
        //                    _self.data.testVersion = '13-7';
        //                }
        //                else {
        //                    _self.data.testVersion = '13-8';
        //                }
        //            }
        //            break;
        //        default:
        //            if (shan.tools.isWeixin() == 1) {
        //                if (shan.tools.getMobileOperatingSystem() == "iOS") {
        //                    _self.data.testVersion = '14-3';
        //                }
        //                else {
        //                    _self.data.testVersion = '14-4';
        //                }
        //            }
        //            else {
        //                if (shan.tools.getMobileOperatingSystem() == "iOS") {
        //                    _self.data.testVersion = '14-7';
        //                }
        //                else {
        //                    _self.data.testVersion = '14-8';
        //                }
        //            }
        //            break;
        //    }
        //},
        formatBottom: function (_goodsCode) {
            var _self = this;
            _self.dom.fProductName.text(_self.data.productList[_goodsCode].goodsName);
            _self.dom.fProductPrice.text(_self.data.productList[_goodsCode].price);
        },
        confirmOrder: function () {
            var _self = this;

            //决定testVersion
            //_self.writeTestVersion();
            _self.data.isApiLoading = true;
            shan.ajax({
                    data: {
                        url: '/hporder/order_upgraded_confirm.htm',
                        goodsCode: _self.data.goodsCode,
                        orderCode: _self.data.orderCode
                        //testVersion:_self.data.testVersion
                    },
                    type: 'post',
                    success: function (_json) {
                        _self.data.isApiLoading = false;
                        if (_json.SZ_HEAD.RESP_CODE == 'S0000') {
                            if (_json.SZ_BODY.NEED_PAY) {
                                if(shan.tools.isMyApp() == 1){ //APP端
                                    dataArr[i].orderPayHref = '/sz-pay-app.php?orderCode=' + _json.SZ_BODY.PARAM_D.orderCode;
                                }else{
                                    dataArr[i].orderPayHref = '/sz/order/pay?orderCode=' + _json.SZ_BODY.PARAM_D.orderCode;
                                }
                            }
                            else {
                                if(_self.data.orderFrom=='1'){
                                    window.location.replace('/sz/order/result?status=1&orderCode=' + _json.SZ_BODY.PARAM_D.orderCode);
                                }
                                else{
                                    window.location.replace('/sz/cooperate/result?status=1&orderCode=' + _json.SZ_BODY.PARAM_D.orderCode);
                                }
                            }
                        }
                        else {
                            pop.alert(_json.SZ_HEAD.RESP_MSG);
                        }
                    }
                }
            );
            return false;
        },
        init: function () {
            var _self = this;
            $(function () {
                FastClick.attach(document.body);
                _self.formatBottom(_self.data.goodsCode);
                $('input[type="checkbox"]').prop('checked',false);
            });
        }
        ,
        bindEvent: function () {
            var _self = this;
            $('#showRuleDialog').click(function () {
                _self.upgradeRuleDialog.show();
                shan.tools.statisticsPing("53036");
            });
            $('#showMoreBtn').click(function () {
                $(this).parents('.list-box').removeClass('masking').find('input[type="checkbox"]').prop('checked', true);
                $(this).parents('.list-box').children('.header').addClass('open');
                _self.data.goodsCode = $(this).parents('.list-box').children('.header').data('code');
                _self.formatBottom(_self.data.goodsCode);
                shan.tools.statisticsPing("53035");
            });
            $('.list-box .header').click(function () {
                if ($(this).hasClass('open')) {//关闭
                    $(this).removeClass('open');
                    $(this).find('input[type="checkbox"]').prop('checked', false);
                    switch ($(this).data('code')) {
                        case 'GDS110010002':
                            $('.list-box .header').removeClass('open').find('input[type="checkbox"]').prop('checked', false);
                            $(this).parents('.list-box').addClass('masking');
                            _self.data.goodsCode = _self.data.defaultProductCode;
                            shan.tools.statisticsPing("53038");
                            break;
                        case 'GDS111010002':
                            _self.data.goodsCode = $(this).data('defaultcode');
                            shan.tools.statisticsPing("53040");
                            break;
                        case 'GDS111010003':
                            _self.data.goodsCode = $(this).data('defaultcode');
                            shan.tools.statisticsPing("53042");
                            break;
                        default:
                            break;
                    }
                }
                else {//打开
                    $(this).addClass('open');
                    $(this).find('input[type="checkbox"]').prop('checked', true);
                    switch ($(this).data('code')) {
                        case 'GDS110010002':
                            $(this).parents('.list-box').removeClass('masking');
                            _self.data.goodsCode = $(this).data('code');
                            shan.tools.statisticsPing("53037");
                            break;
                        case 'GDS111010002':
                            _self.dom.manUp.removeClass('open').find('input[type="checkbox"]').prop('checked', false);
                            _self.dom.pietyUp.addClass('open').find('input[type="checkbox"]').prop('checked', true);
                            _self.dom.pietyUp.parents('.list-box').removeClass('masking');
                            _self.data.goodsCode = $(this).data('code');
                            shan.tools.statisticsPing("53039");
                            break;
                        case 'GDS111010003':
                            _self.dom.womanUp.removeClass('open').find('input[type="checkbox"]').prop('checked', false);
                            _self.dom.pietyUp.addClass('open').find('input[type="checkbox"]').prop('checked', true);
                            _self.dom.pietyUp.parents('.list-box').removeClass('masking');
                            _self.data.goodsCode = $(this).data('code');
                            shan.tools.statisticsPing("53041");
                            break;
                        default:
                            break;
                    }
                }
                _self.formatBottom(_self.data.goodsCode);
            });
            $('#bookingBtn').click(function () {
                if (!_self.data.isApiLoading) {
                    _self.confirmOrder();
                }
            });
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    };

//初始化函数
    exports.run = run;
});



define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/jquery.tmpl');
    require('lib/fastclick');
    require('lib/mustache');
    var chooseRegion = require('lib/chooseRegion_visit');
    var chooseDate = require('lib/chooseDate_visit');
    var goodsCode = shan.tools.getUrlParam("goodsCode");
    var f = {
        loading: false,
        firstFormatDate: false,
        firstFormatArea: false,
        checkRegionAddr: function () {
            if ($.trim($('input[name="regionAddr"]').val()) != '') {
                return true;
            }
            else {
                pop.alert('请输入详细地址');
                return false;
            }
        },
        checkName: function () {
            if ($.trim($('input[name="examineeName"]').val()) != '') {
                return true;
            }
            else {
                pop.alert('请输入体检人姓名');
                return false;
            }
        },
        checkPhone: function () {
            var _val = $.trim($('input[name="examineePhone"]').val());
            if (/^1\d{10}/.test(_val)) {
                return true;
            }
            else {
                pop.alert('请输入正确的手机号码');
                return false;
            }
        },
        checkRegion: function () {
            if ($.trim($('input[name="regionCode"]').val()) != '') {
                return true;
            }
            else {
                pop.alert('请选择所在地区');
                return false;
            }
        },
        checkInfo: function () {
            if ($.trim($('input[name="examineeGender"]').val()) != '' && $.trim($('input[name="examineeAgeRange"]').val()) != '') {
                return true;
            }
            else {
                pop.alert('请选择体检人信息');
                return false;
            }
        },
        checkDate: function () {
            if ($.trim($('input[name="examineeDate"]').val()) != '') {
                return true;
            }
            else {
                pop.alert('请选择期望上门时间');
                return false;
            }
        },
        preZero: function (_num) {
            if (parseInt(_num) < 10) {
                _num = '0' + _num;
            }
            return _num;
        },
        getNow: function () {
            var now = new Date();
            var nowYear = now.getFullYear();
            var nowMonth = parseInt(now.getMonth()) + 1;
            var nowDate = now.getDate();
            var end = new Date(parseInt(now.getTime()) + 60 * 24 * 60 * 60 * 1000);
            var endYear = end.getFullYear();
            var endMonth = parseInt(end.getMonth()) + 1;
            var endDate = end.getDate();

            return {
                START_DATE_D: nowYear + '-' + f.preZero(nowMonth) + '-' + f.preZero(nowDate),
                END_DATE_D: endYear + '-' + f.preZero(endMonth) + '-' + f.preZero(endDate)
            };

        },
        initChooseDate: function () {
            var _self = this;
            var _date = f.getNow();
            return chooseDate.init({
                target: '#datePicker-area',
                templateId: '#datePicker-template',
                START_DATE_D: _date.START_DATE_D,
                END_DATE_D: _date.END_DATE_D,
                goodsCode: $('input[name="goodsCode"]').val(),
                onChooseDate: function (result) {
                    console.log(result);
                    $('#status-area').show();
                    $('#dateBtn').data('date', result.reserveTime);
                },
                onClose: function () {
                    $('#datePicker-area').hide();
                    $('#status-area').hide();
                }
            });
        },
        initChooseRegion: function (goodsCode) {
            var _self = this;
            return chooseRegion.init({
                target: '#region-area',
                goodsCode: goodsCode,
                templateId: '#region-template',
                callback: function (result) {
                    $('#chooseAreaShow').html($('#L1-list').children('.selected').text() + ' ' + result);
                    $('input[name="regionCode"]').val($('#L1-list').children('.selected').text()+''+result);
                    $('#region-area').hide();
                }
            });
        },
        checkOrder: function () {
            var _self = this;
            if (_self.checkRegion() && _self.checkRegionAddr() && _self.checkInfo() && _self.checkDate() && _self.checkName() && _self.checkPhone()) {
                return true;
            }
            else {
                return false;
            }
        },
        confirmOrder: function () {
            var _self = this;
            _self.loading = true;
            shan.ajax({
                data: {
                    url: '/preset/home_medical_reserve.htm',
                    orderCode: $('input[name="orderCode"]').val(),
                    goodsCode: $('input[name="goodsCode"]').val(),
                    regionCode: $('input[name="regionCode"]').val(),
                    regionAddr: $('input[name="regionAddr"]').val(),
                    examineeName: $('input[name="examineeName"]').val(),
                    examineeGender: $('input[name="examineeGender"]').val(),
                    examineePhone: $('input[name="examineePhone"]').val(),
                    examineeAgeRange: $('input[name="examineeAgeRange"]').val(),
                    reserveTime: $('input[name="examineeDate"]').val()
                },
                type: 'POST',
                success: function (_json) {
                    if (goodsCode == 'GDS937585397' || goodsCode == 'GDS287895427') {
                        var _data = {};
                        switch (_json.SZ_HEAD.RESP_CODE) {
                            case 'S0000' :
                                _data = _json.SZ_BODY;
                                _data.error = 0;
                                break;
                            case 'B0302' :
                                _data.error = 3;
                                _data.message = '订单不能进行当前操作';
                                break;
                            case 'B701' :
                                _data.error = 4;
                                _data.message = '预约日期不正确';
                                break;
                            case 'B801' :
                                _data.error = 8;
                                _data.message = "您已预约过此订单,请前往个人中心查看";
                                break;
                            default:
                                _data.error = 9;
                                _data.message = _json.SZ_HEAD.RESP_MSG;
                                break;
                        }
                        if (_data.error == 0) {
                            pop.alert("预约成功", function () {
                                window.location.replace('/sz/order/result?status=3&orderCode=' + $("input[name='orderCode']").val());
                            });

                        }
                        else if (_data.error != 0) {
                            if (_data.error == 8) {
                                pop.alert(_data.message, function () {
                                    window.location.replace('/user-order-list.php');
                                    return;
                                });
                            }
                            else {
                                pop.alert(_data.message);
                            }
                        }
                    }
                    else {
                        pop.alert('抱歉哦，当前上门服务仅支持部分区域，请尝试其他方式预约。', function () {
                            history.back();
                        })
                    }
                    _self.loading = false;
                }
            });


        },
        init: function () {
            var _self = this;
            FastClick.attach(document.body);
        },
        bindEvent: function () {
            var _self = this;
            //日期选择
            $('#date').click(function () {
                if (!f.firstFormatArea) {
                    f.initChooseDate();
                    f.firstFormatArea = true;
                }
                else {
                    $('#datePicker-area').show();
                }

            });
            $('#dateBtn').click(function () {
                if ($(this).data('date') != '') {
                    $('#dateSpan').html($(this).data('date'));
                    $('input[name="examineeDate"]').val($(this).data('date'));
                    $('#status-area').hide();
                    $('#datePicker-area').hide();
                }
            });
            //性别选择
            $('#userInfo').click(function () {
                $('#personInfo').removeClass('hidden');
            });
            $('#personInfoAge').on('click', 'li', function () {
                $('#userInfoShow').html($('#personInfoSex').children('.selected').text() + ' ' + $(this).text());
                $('input[name="examineeGender"]').val($('#personInfoSex').children('.selected').text());
                $('input[name="examineeAgeRange"]').val($(this).text());
                $('#personInfo').addClass('hidden');
            });
            $('#personInfoSex').on('click', 'li', function () {
                if (!$(this).hasClass('selected')) {
                    $(this).addClass('selected').siblings().removeClass('selected');
                }
            });
            $('#personInfo').on('click', '.sz-icon-close,.yo-mask', function () {
                $('#personInfo').addClass('hidden');
            });
            //地区选择
            $('#chooseArea').click(function () {
                if (!f.firstFormatDate) {
                    if (f.initChooseRegion($('input[name="goodsCode"]').val())) {
                        $('#region-area').show();
                        f.firstFormatDate = true;
                    }
                }
                else {
                    $('#region-area').show();
                }

            });
            //下单
            $('#sOrderBtn').click(function () {
                if (!_self.loading) {
                    if (_self.checkOrder()) {
                        _self.confirmOrder();
                    }
                }
                else {
                    pop.alert('请不要频繁提交订单！');
                    return false;
                }
            });
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});
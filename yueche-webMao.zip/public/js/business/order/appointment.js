define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/jquery.tmpl');
    require('lib/fastclick');
    require('lib/mustache');
    require('lib/vue/vue');

    var chooseRegion = require('lib/chooseRegion');
    var chooseInstit = require('lib/chooseInstit');
    var chooseDate = require('lib/chooseDate');
    var institStatus = require('lib/institStatus');
    var recommendInstit = require('lib/recommendInstit');

    var orderCode = shan.tools.getUrlParam("orderCode");
    var IDValidator = require('lib/idvalidator');
    var GB2260 = require('lib/gb2260');
    var idValidator = new IDValidator(GB2260);
    var cR, cI, cD;
    var $smSelectDialog = $('#sm-select-dialog'),
        $smOrderDialog = $('#sm-order-dialog'),
        $pMask = $('.pMask');


    var f = {
        init: function () {
            var _self = this;
            $(function () {
                FastClick.attach(document.body);
                //点击上门体检的关闭按钮或到店体检
                $smSelectDialog.find('.sz-icon-close,.dd-select-box').on('click', function (e) {
                    $smSelectDialog.addClass('hidden');
                    $pMask.addClass('hidden');
                });

                //点击上门体检方式
                $smSelectDialog.find('.sm-select-box').on('click', function (e) {
                    $smSelectDialog.addClass('hidden');
                    $smOrderDialog.removeClass('hidden');
                    shan.tools.statisticsPing("230011");
                });

                $('.pMask,#sDealBox .pCloseBtn').click(function () {
                    $('.pMask').addClass('hidden');
                    $('#sDealBox').hide();
                });

            });
            if (!orderCode) {
                window.location.replace('/sz/user/index');
            }
        }
    };

    Vue.component('order-paralle', {
        data: function () {
            return {
                isOpenAdded1: false,
                isOpenAdded2: false,
                isOpenAdded3: false
            };
        },
        methods: {
            openAdded1: function () {
                if (this.isOpenAdded1) { //取消选中
                    this.isOpenAdded1 = false;
                    this.isOpenAdded2 = false;
                    this.isOpenAdded3 = false;
                    this.$emit("sel-goods", 0);
                    shan.tools.statisticsPing("53020");
                }
                else { //选中
                    this.isOpenAdded1 = true;
                    this.isOpenAdded2 = false;
                    this.isOpenAdded3 = false;
                    this.$emit("sel-goods", 1);
                    shan.tools.statisticsPing("53019");
                }
            },
            openAdded2: function () {
                if (this.isOpenAdded2) { //取消选中
                    this.isOpenAdded1 = false;
                    this.isOpenAdded2 = false;
                    this.isOpenAdded3 = false;
                    this.$emit("sel-goods", 0);
                    shan.tools.statisticsPing("53022");
                }
                else { //选中
                    this.isOpenAdded1 = false;
                    this.isOpenAdded2 = true;
                    this.isOpenAdded3 = false;
                    this.$emit("sel-goods", 2);
                    shan.tools.statisticsPing("53021");
                }
            },
            openAdded3: function () {
                if (this.isOpenAdded3) { //取消选中
                    this.isOpenAdded1 = false;
                    this.isOpenAdded2 = false;
                    this.isOpenAdded3 = false;
                    this.$emit("sel-goods", 0);
                    shan.tools.statisticsPing("53024");
                }
                else { //选中
                    this.isOpenAdded1 = false;
                    this.isOpenAdded2 = false;
                    this.isOpenAdded3 = true;
                    this.$emit("sel-goods", 3);
                    shan.tools.statisticsPing("53023");
                }
            }
        }
    });


    var vm = new Vue({
        el: '#app',
        data: {//数据
            ensureGoodsCodeArr: ['GDS110010001', 'GDS432607373', 'GDS460441692', 'GDS62515127522', 'GDS706993422', 'GDS811884932'],//需缴纳1元保证金的商品组
            isNotGirls: true,//false为未婚女
            defaultGoodsCode: '',//下单时初始商品code
            goodsCode: '',//商品code
            orderCode: '',//订单code
            activityProd: '',//活动套餐标识
            ageLimit: '',//活动套餐年龄限制
            regionCode: '',//一级地区code
            subRegionCode: '',//二级地区code
            institCode: '',//机构code
            reserveTime: '',//预约时间
            pkgType: '',//性别
            goodsName: '',//商品名称
            orderAmtStr: '',//订单实付价
            examineeName: '',//体检人姓名
            examineeIcno: '',//体检人身份证
            examineePhone: '',//体检人手机号码
            hasExamineeInfo: false,//后台是否已带体检人信息
            sexs: [],//商品可支持的体检人性别
            sexMap: {'M': '男性', 'MW': '已婚女', 'UW': '未婚女'},//商品可支持的体检人性别对应中文表
            institName: '',//机构名称
            institAddr: '',//机构地址
            institDate: '',//机构日期
            isHiddenInstitInfo: true,//是否隐藏用户选择的机构信息
            isShowUserDeal: false,//是否显示善诊用户体检协议
            isHideUserDealCheck: false,//是否不同意体检协议
            isSm: false,//是否开启上门逻辑
            isWaitApi: false,//是否等待接口返回
            isAbledOpenUserDeal: true,//是否取消 我已阅读并同意《善诊用户体检协议》
            pkgTypeIndex: 0,//用户选择性别位置
            goodsData: [
                {
                    'goodsCode': 'GDS110010001',
                    'addedPrice': 0,
                    'goodsName': '关爱父母孝心套餐'
                },
                {
                    'goodsCode': 'GDS110010002',
                    'addedPrice': 99,
                    'goodsName': '关爱父母孝心升级套餐'
                },
                {
                    'goodsCode': 'GDS111010002',
                    'addedPrice': 198,
                    'goodsName': '关爱父母加强升级(女)套餐'
                },
                {
                    'goodsCode': 'GDS111010003',
                    'addedPrice': 198,
                    'goodsName': '关爱父母加强升级(男)套餐'
                }
            ], // 升级项的数据
            isHideEnsureDialog: true,//是否隐藏1元保证金弹层
            IS_POP_WINDOW: 0,//1：需要1元预约保证金；0：不需要1元保证金


        },
        computed: {//计算属性
            getInstitDate: function () {
                if (!this.reserveTime) return '';
                var _temp = this.reserveTime.split('-'),
                    year = _temp[0],
                    month = _temp[1],
                    day = _temp[2],
                    weekList = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'],
                    i = new Date(this.reserveTime).getDay();
                return year + '年' + month + '月' + day + '日' + ' ' + weekList[i];
            }
        },
        methods: {//方法
            addedGoods: function (index) {
                if (typeof this.goodsData[index] != 'undefined') {
                    this.goodsCode = this.goodsData[index].goodsCode;
                    this.goodsName = this.goodsData[index].goodsName;
                    this.orderAmtStr = this.goodsData[index].addedPrice;
                }
                else {
                    this.goodsCode = this.goodsData[0].goodsCode;
                    this.goodsName = this.goodsData[0].goodsName;
                    this.orderAmtStr = this.goodsData[0].addedPrice;
                }
                this.setOrderPrice();
                this.formatInstit();
            },
            setOrderPrice: function () {
                this.orderAmtStr = parseInt(this.orderAmtStr);
                var _$btn = $('#sOrderBtn');
                if (this.orderAmtStr == 0) {
                    _$btn.find('.text-yellow').text(0).addClass('hidden');
                    _$btn.find('.sBtnWords').text('完成');
                } else {
                    _$btn.find('.text-yellow').text('￥' + this.orderAmtStr).removeClass('hidden');
                    _$btn.find('.sBtnWords').text('支付后完成预约');
                }
            },
            formatInstit: function (_data) {
                var _orderInfo = {
                        regionCode: '',
                        subRegionCode: '',
                        institCode: '',
                        reserveTime: '',
                        institName: '',
                        institAddr: '',
                        institDate: ''
                    },
                    _self = this;
                if (!!_data) {
                    $.extend(_orderInfo, _data);
                    _self.isHiddenInstitInfo = false;
                }
                else {
                    _self.isHiddenInstitInfo = true;
                    //机构初始化
                    _self.initInstitDialog();
                    _self.getGoodsSexType();
                }
                _self.regionCode = _orderInfo.regionCode;
                _self.subRegionCode = _orderInfo.subRegionCode;
                _self.institCode = _orderInfo.institCode;
                _self.reserveTime = _orderInfo.reserveTime;
                _self.institName = _orderInfo.institName;
                _self.institAddr = _orderInfo.institAddr;
                //预约机构为爱康，展示善诊用户体检协议
                _self.checkDeal();
            },
            getGoodsSexType: function () {
                var _self = this;
                _self.isWaitApi = true;
                shan.ajax({
                    data: {
                        url: '/prod/querySexListByGoodsCode.htm',
                        goodsCode: this.goodsCode
                    },
                    success: function (_json) {
                        if (_json.SZ_HEAD.RESP_CODE != 'S0000') {
                            pop.alert('系统异常，请刷新该页面重试！');
                        }
                        else {
                            _self.sexs.splice(0, _self.sexs.length);
                            for (var i = 0; i < _json.SZ_BODY.SEX_D.length; i++) {
                                _self.sexs.splice(i, 0, _json.SZ_BODY.SEX_D[i]);
                            }
                            _self.pkgType = '';
                            _self.isNotGirls = true;
                            $('.type-item').removeClass('item-on');
                        }
                        _self.isWaitApi = false;
                    }
                });
            },
            checkDeal: function () {
                var _self = this;
                _self.isShowUserDeal = _self.institName.indexOf('爱康') >= 0 ? true : false;
                _self.isHideUserDealCheck = false;
            },
            initInstitDialog: function () {
                var _self = this;
                cR = _self.initChooseRegion(_self.goodsCode);
                cR.hide();
            },
            initChooseRegion: function (goodsCode) {
                var _self = this;
                return chooseRegion.init({
                    target: '#region-area',
                    goodsCode: goodsCode,
                    templateId: '#region-template',
                    onBack: function () {
                        institStatus.hide();
                    },
                    onClose: function () {
                        institStatus.hide();
                    },
                    callback: function (result) {
                        cI = _self.initChooseInstit(result);
                        cI.show();
                        cR.hide();
                    }
                });
            },
            initChooseInstit: function (result) {
                var _self = this;
                return chooseInstit.init({
                    target: '#instit-area',
                    goodsCode: result.goodsCode,
                    subRegionCode: result.subRegionCode,
                    templateId: '#instit-template',
                    onBack: function () {
                        institStatus.hide();
                    },
                    onClose: function () {
                        institStatus.hide();
                    },
                    onChooseDate: function (result) {
                        if (result.status == 'status-able') {
                            _self.onChooseDate(result);
                        } else {
                            result.onChooseDate = _self.onChooseDate;
                            institStatus.show(result);
                        }
                    },
                    onMore: function (institInfo) {
                        cD = _self.initChooseDate(institInfo);
                        cD.show();
                        cI.hide();
                    }
                });
            },
            onChooseDate: function (result) {
                var _self = this;
                _self.formatInstit(result);
                cI.hide();
                cR.hide();
                if (cD) {
                    cD.hide();
                }
            },
            initChooseDate: function (institInfo) {
                var _self = this;
                return chooseDate.init({
                    target: '#datePicker-area',
                    templateId: '#datePicker-template',
                    institInfo: institInfo,
                    goodsCode: _self.goodsCode,
                    onChooseDate: function (result) {
                        result.onChooseDate = _self.onChooseDate;
                        institStatus.show(result);
                    },
                    onBack: function () {
                        institStatus.hide();
                        cI.show();
                    },
                    onClose: function () {
                        institStatus.hide();
                    }
                });
            },
            changeInstit: function () {
                if (cI) {
                    cI.show();
                }
            },
            chooseInstitAndDate: function () {
                if (this.isSm == 1) {
                    $smSelectDialog.removeClass('hidden');
                    $pMask.removeClass('hidden');
                    shan.tools.statisticsPing("230010");
                }
                else {
                    if (this.checkGender()) {
                        if (this.institCode != '') {
                            this.changeInstit();
                        }
                        else {
                            cR.show();
                        }
                    }
                }
            },
            smChooseGoToInstit: function () {
                //是否二次选取
                if (this.institCode != '') {
                    this.changeInstit();
                }
                else {
                    cR.show();
                }
            },
            smSubmit: function () {
                shan.tools.statisticsPing("230012");
                window.location.replace('/sz/order/visitoffline/orderCode/' + orderCode + '/goodsCode/' + this.goodsCode);
            },
            choosePkgType: function (index) {
                if (!$($('.type-item')[index]).hasClass('item-on')) {
                    $($('.type-item')[index]).addClass('item-on').siblings().removeClass('item-on');
                    this.pkgType = $($('.type-item')[index]).attr('data-val');

                    if (this.pkgType == 'UW') {
                        this.isNotGirls = false;
                    }
                    else {
                        this.isNotGirls = true;
                    }
                }
            },
            isEnsureGoodsCode: function () {
                var _len = this.ensureGoodsCodeArr.length;
                var _bool = false;
                if (_len > 0) {
                    for (var i = 0; i < _len; i++) {
                        if (this.goodsCode == this.ensureGoodsCodeArr[i]) {
                            _bool = true;
                            break;
                        }
                    }
                }
                return _bool;
            },
            submitOrder: function (_obj) {
                if ($(_obj.currentTarget).hasClass('disabled')) {
                    pop.alert('同意《善诊用户体检协议》才能进行预约');
                    return false;
                }
                else {
                    if (!this.isWaitApi) {
                        if (this.checkOrder()) {
                            if (this.IS_POP_WINDOW == '1' && this.isEnsureGoodsCode()) {
                                this.isHideEnsureDialog = false;
                                shan.tools.statisticsPing("32001");
                            }
                            else {
                                this.confirmOrder();
                            }
                        }
                    }
                    else {
                        pop.alert('请不要频繁提交订单！');
                        return false;
                    }
                }
            },
            checkName: function () {
                if (this.examineeName != '' && this.examineeName != undefined) {
                    return true;
                }
                else {
                    pop.alert('请输入体检人姓名');
                    return false;
                }
            },
            checkCode: function () {
                if (this.examineeIcno != '' && this.examineeIcno != undefined) {
                    var _code = this.examineeIcno,
                        _gender = this.pkgType,
                        _activeProd = this.activityProd,
                        _ageLimit = this.ageLimit,
                        _codeInfo = false,
                        _age,
                        sex;
                    if (!idValidator.isValid(_code)) {
                        pop.alert('身份证号不正确');
                        return false;
                    }
                    else {
                        if (_gender == "") {
                            pop.alert('请点击选择性别!');
                            return false;
                        }

                        if (_gender == 'MW' || _gender == 'UW') {
                            sex = 0;
                        }
                        else {
                            sex = 1;
                        }
                        _codeInfo = idValidator.getInfo(_code);
                        if (!_codeInfo || typeof _codeInfo.sex == "undefined" || typeof _codeInfo.birth == "undefined") {
                            pop.alert('请输入合法的身份证号');
                            return false;
                        }
                        if (_codeInfo.sex != sex) {
                            pop.alert('体检套餐性别与身份证号不符');
                            return false;
                        }

                        if (_activeProd != '') { //活动套餐
                            _age = new Date(g_date).getFullYear() - parseInt(_codeInfo.birth.substring(0, 4), 10);
                            if (typeof _ageLimit != "undefined" && _ageLimit > 0 && _age < _ageLimit) {
                                pop.alert('体检人年龄不能小于' + _ageLimit + '周岁');
                                return false;
                            }
                        }
                        return true;
                    }
                }
                else {
                    pop.alert('请输入体检人身份证');
                    return false;
                }

            },
            checkGender: function () {
                if (this.pkgType != '' && this.pkgType != undefined) {
                    return true;
                }
                else {
                    pop.alert('请选择体检人性别');
                    return false;
                }
            },
            checkPhone: function () {
                var _val = this.examineePhone;
                if (/^1\d{10}/.test(_val)) {
                    return true;
                }
                else {
                    pop.alert('请输入正确的手机号码');
                    return false;
                }
            },
            checkInstitDate: function () {
                var _institCode = this.institCode,
                    _reserveTime = this.reserveTime;
                if (_institCode != '' && _reserveTime != '') {
                    return true;
                }
                else {
                    pop.alert('请选择体检机构及时间');
                    return false;
                }
            },
            checkOrder: function () {
                var _self = this;
                if (_self.checkName() && _self.checkPhone() && _self.checkGender() && _self.checkCode() && _self.checkInstitDate()) {
                    return true;
                }
                else {
                    return false;
                }
            },
            confirmOrder: function () {
                var _self = this;
                _self.isWaitApi = true;
                _self.isHideEnsureDialog = true;
                var _goodsCode = _self.goodsCode;
                var testVersion = "";
                //testVersion只会在选择了升级项才会被后台覆盖
                if (_self.defaultGoodsCode == 'GDS110010001') {//孝心套餐进入预约
                    if (_goodsCode == 'GDS110010002') {//升级产品
                        if (shan.tools.isWeixin() == 1) {
                            if (shan.tools.getMobileOperatingSystem() == "iOS") {
                                testVersion = '5-1';
                            }
                            else {
                                testVersion = '5-2';
                            }
                        }
                        else {
                            if (shan.tools.getMobileOperatingSystem() == "iOS") {
                                testVersion = '5-5';
                            }
                            else {
                                testVersion = '5-6';
                            }
                        }
                    } else if (_goodsCode == 'GDS111010002' || _goodsCode == 'GDS111010003') {//妇科或男科
                        if (shan.tools.isWeixin() == 1) {
                            if (shan.tools.getMobileOperatingSystem() == "iOS") {
                                testVersion = '6-1';
                            }
                            else {
                                testVersion = '6-2';
                            }
                        }
                        else {
                            if (shan.tools.getMobileOperatingSystem() == "iOS") {
                                testVersion = '6-5';
                            }
                            else {
                                testVersion = '6-6';
                            }
                        }
                    }
                }
                else if (_self.defaultGoodsCode == 'GDS110010002') {//孝心升级套餐进入预约
                    if (_goodsCode == 'GDS111010002' || _goodsCode == 'GDS111010003') {//妇科或男科
                        if (shan.tools.isWeixin() == 1) {
                            if (shan.tools.getMobileOperatingSystem() == "iOS") {
                                testVersion = '4-1';
                            }
                            else {
                                testVersion = '4-2';
                            }
                        }
                        else {
                            if (shan.tools.getMobileOperatingSystem() == "iOS") {
                                testVersion = '4-5';
                            }
                            else {
                                testVersion = '4-6';
                            }
                        }
                    }
                }
                shan.tools.statisticsPing("32003");
                shan.ajax({
                    data: {
                        url: '/preset/setexamineeinfo.htm',
                        goodsCode: _self.goodsCode,
                        orderCode: _self.orderCode,
                        activityProd: _self.activityProd,
                        regionCode: _self.regionCode,
                        subRegionCode: _self.subRegionCode,
                        institCode: _self.institCode,
                        reserveTime: _self.reserveTime,
                        pkgType: _self.pkgType,
                        examineeName: _self.examineeName,
                        examineeIcno: _self.examineeIcno,
                        examineePhone: _self.examineePhone,
                        testVersion: testVersion
                    },
                    type: 'POST',
                    success: function (_json) {
                        var _data = {};
                        switch (_json.SZ_HEAD.RESP_CODE) {
                            case 'S0000' :
                                _data = _json.SZ_BODY;
                                _data.error = 0;
                                break;
                            case 'B0302' :
                                _data.error = 3;
                                _data.message = '订单不能进行当前操作';
                                break;
                            case 'B701' :
                                _data.error = 4;
                                _data.message = '预约日期不正确';
                                break;
                            case 'B801' :
                                _data.error = 8;
                                _data.message = "您已预约过此订单,请前往个人中心查看";
                                break;
                            case 'B805' :
                                _data.error = 8;
                                _data.message = "您已预约成功,请前往个人中心查看";
                                break;
                            default:
                                _data.error = 9;
                                _data.message = _json.SZ_HEAD.RESP_MSG;
                                break;
                        }
                        if (_data.error == 0) {
                            if (_data.needPay) {
                                window.location.replace('/sz/order/pay?orderCode=' + _self.orderCode);
                            }
                            else {
                                pop.alert("预约成功", function () {
                                    window.location.replace('/sz/order/result?status=5&orderCode=' + _self.orderCode);
                                });
                            }
                        }
                        else if (_data.error != 0) {

                            if (_data.error == 8) {
                                pop.alert(_data.message, function () {
                                    window.location.replace('/user-order-list.php');
                                    return;
                                });
                            }
                            else {
                                pop.alert(_data.message);
                            }
                        }
                        _self.isWaitApi = false;
                    }
                });

            },
            watchUserDeal: function (_obj) {
                var _self = this;
                if (_self.isAbledOpenUserDeal) {
                    _self.isAbledOpenUserDeal = false;
                    var $_self = $(_obj.currentTarget);
                    shan.ajax({
                        url: '/getdate.php',
                        success: function (_rtn) {
                            var _name = _self.examineeName,
                                _code = _self.examineeIcno;
                            $('#sDealYear').html('[' + _rtn.year + ']');
                            $('#sDealMonth').html('[' + _rtn.month + ']');
                            $('#sDealDate').html('[' + _rtn.date + ']');
                            if (_self.examineeName != '') {
                                $('.pDealUserName').addClass('done').html(_name);
                            }
                            else {
                                $('.pDealUserName').removeClass('done').html(_name);
                            }
                            if (_self.examineeIcno) {
                                $('.pDearUserCode').addClass('done').html(_code);
                            }
                            else {
                                $('.pDearUserCode').removeClass('done').html(_code);
                            }
                            $('#sDealBox').show();
                            $('.pMask').removeClass('hidden');
                            _self.isAbledOpenUserDeal = true;
                        }
                    });
                }

            },
            chooseUserDeal: function () {
                if (this.isHideUserDealCheck) {
                    this.isHideUserDealCheck = false;
                    this.isHideUserDealCheck = false;
                }
                else {
                    this.isHideUserDealCheck = true;
                    this.isHideUserDealCheck = true;
                }
            },
            closeEnsureDialog: function () {
                this.isHideEnsureDialog = true;
                shan.tools.statisticsPing("32002");
            }
        },
        created: function () {//创建实例后
            try {
                this.defaultGoodsCode = g_orderDetail.GOODS_D.goodsCode;
                if(this.defaultGoodsCode == "GDS807168351"
                    || this.defaultGoodsCode == "GDS172859584"
                    || this.defaultGoodsCode == "GDS357711094"
                    || this.defaultGoodsCode == "GDS467482874"
                    || this.defaultGoodsCode == "GDS887251836"
                    || this.defaultGoodsCode == "GDS778124688"
                    || this.defaultGoodsCode == "GDS612037083"
                    || this.defaultGoodsCode == "GDS403282209"
                    || this.defaultGoodsCode == "GDS575315529"
                    || this.defaultGoodsCode == "GDS309054348"
                    || this.defaultGoodsCode == "GDS536893824"){
                    pop.alert("预约异常请致电客服:400-6762-960",function(){
                        window.href.location = "/sz/user/index";
                        return;
                    });
                }
                this.goodsCode = g_orderDetail.GOODS_D.goodsCode;
                this.orderCode = g_orderDetail.ORDER_D.orderCode;
                this.activityProd = g_orderDetail.GOODS_D.activityProd;
                this.ageLimit = g_orderDetail.AGE_LIMIT;
                this.regionCode = g_orderDetail.INSTIT_D.regionCode;
                this.subRegionCode = g_orderDetail.INSTIT_D.subRegionCode;
                this.institCode = g_orderDetail.INSTIT_D.institCode;
                this.pkgType = g_orderDetail.PKG_D.pkgType;
                this.goodsName = g_orderDetail.GOODS_D.goodsName;
                this.orderAmtStr = g_orderDetail.ORDER_D.orderAmtStr;
                this.examineeName = g_orderDetail.ORDER_D.examineeName;
                this.examineeIcno = g_orderDetail.ORDER_D.examineeIcno;
                this.examineePhone = g_orderDetail.ORDER_D.examineePhone;
                this.IS_POP_WINDOW = g_orderDetail.IS_POP_WINDOW;
                if (g_orderDetail.ORDER_D.examineeIcno && g_orderDetail.ORDER_D.examineeIcno != '') {
                    this.hasExamineeInfo = true;
                }
                this.sexs = g_orderDetail.SEX_D;
                this.isSm = g_isSm == '1' ? true : false;
            }
            catch (e) {
                console.log(e);
            }

        },
        mounted: function () {//创建dom后
            this.formatInstit();
        }
    });

    var run = function () {
        f.init();
    }

    //初始化函数
    exports.run = run;
});
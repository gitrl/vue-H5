define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/carousel.js');
    var orderCode = shan.tools.getUrlParam("orderCode");
    var defineImg = {
        "BLOOD_GLUCOSE_PKG_A": "/static/images/report/product/product-a.png",
        "BLOOD_GLUCOSE_PKG_B": "/static/images/report/product/product-b.png",
        "BLOOD_GLUCOSE_METER": "/static/images/report/product/product-1.png",
        "BLOOD_PRESSURE_METER": "/static/images/report/product/product-2.png",
        "HYPERTENSION": "/static/images/report/product/product-5.png",
        "HIGH_BLOOD_LIPID": "/static/images/report/product/product-5.png",
        "MORE_CARE_PZ": "/static/images/product/desc_xuetang.png",
        "MORE_CARE_PZ_SERVICE": "/static/images/product/accompanying.png"
    };
    var definePayStatus = {
        1: "未支付",
        2: "已支付"
    };
    var f = {
        init: function () {
            shan.ajax({
                data: {
                    url: "/szreportorder/order_detail.htm",
                    orderCode: orderCode
                },
                success: function (json) {
                    if (json && json.SZ_HEAD && json.SZ_HEAD.RESP_CODE == "S0000") {
                        if (json && json.SZ_BODY && json.SZ_BODY && json.SZ_BODY.ORDER_DETAIL_D) {
                            f.showDetail(json.SZ_BODY.ORDER_DETAIL_D);
                        }
                    }
                    else {
                        pop.alert("获取商品详情失败!");
                    }
                }
            });
        },
        showDetail: function (data) {

            $(".c_recver").text("收货人:" + typeof data.memberName != "undefined" ? data.memberName : "无");
            $(".c_address").text("收货地址:" + typeof data.memberAddress != "undefined" ? data.memberAddress : "无");
            $(".c_name").text(data.serviceName || "");
            $(".c_desc").text(data.serviceDesc || "");
            $(".c_number").text(data.personCount || "0");
            $(".c_mainPrice").text("￥" + data.orderAmtInt || "1");
            $(".c_orderCode").text("订单号:" + data.orderCode || "");
            $(".c_creatTime").text("创建时间：" + data.createTime || "");
            //如果价格为0，不显示订单状态
            if (data.orderAmt == 0) {
                $(".c_payState").text('');
            }
            else {
                $(".c_payState").text(definePayStatus[data.payStatus]);
            }

            $(".c_img").attr("src", defineImg[data.serviceCode]);
        },
        bindEvent: function () {
            $(".c_pageBack").click(function () {
                history.back();
                return false;
            });
            $('#productCarousel').swipeSlide({
                continuousScroll: true,
                speed: 3000,
                transitionType: 'cubic-bezier(0.22, 0.69, 0.72, 0.88)',
                autoSwipe: false,
                firstCallback: function (i, sum, me) {
                    me.find('.dot').children().first().addClass('cur');
                },
                callback: function (i, sum, me) {
                    me.find('.dot').children().eq(i).addClass('cur').siblings().removeClass('cur');
                }
            });
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});
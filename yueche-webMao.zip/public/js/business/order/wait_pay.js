define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/vue/vue.min');
    var f = {
        init : function(){
            var timestamp = 61,
            time = setInterval(function () {
                var _m = Math.floor((timestamp / 60) % 60),
                    _s = Math.floor(timestamp % 60);
                if(_s < 10){
                    _s = "0" + _s;
                }
                if(_m < 10){
                    _m = "0" + _m;
                }
                $('.time-content').text(_m + ":" + _s);
                timestamp --;
                if(_m == 0 && _s == 0){
                    clearInterval(time);
                    $('.fixBtn').addClass('disabled');
                }
            },1000);
        }
    };


    var run = function () {
        f.init();
    };

    //初始化函数
    exports.run = run;
});
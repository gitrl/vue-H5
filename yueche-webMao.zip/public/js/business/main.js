define(function(require, exports, module) {
	var $ =require('jquery');
	var main = {
		defaultController:'index',
		defaultAction:'index',
		locationRoute:function()
		{
			var location_url = window.location.href;

			var pos=location_url.indexOf('#');
			if(pos!=-1)
			{
				location_url=location_url.substr(0,pos);
			}

			pos=location_url.indexOf('?');
			if(pos!=-1)
			{
				location_url=location_url.substr(0,pos);
			}
			pos=location_url.indexOf('.html');
			if(pos!=-1)
			{
				location_url=location_url.substr(0,pos);
			}

			var path = location_url.replace( new RegExp( "(^(https)|(http))://.+?[^/]+|/$", "g" ), "" );
			if(path.indexOf('/sz/')==0)
			{
				path=path.substr(2);
			}
			path = path.split('/');
			return [(path[1])?path[1].toLowerCase():this.defaultController,(path[2])?path[2].toLowerCase():this.defaultAction];
		},
		requireController:function(controllerName,actionName,callback)
		{
			return require.async('./'+controllerName+'/'+actionName,callback);
		},
		run:function()
		{
			var route = main.locationRoute();
			var controllerName = route[0];
			var actionName = route[1];

			this.requireController(controllerName,actionName,function(controller){
				if(controller==null)return;
				controller.run&&controller.run();
			});
		}
	}

	$(function(){
		main.run();
	});
});

define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/webviewbridge');
    require('lib/fastclick');
    require('lib/jquery.tmpl');
    var CURRENTPAGE = 1,
        PAGESIZE = 15,
        PAGECOUNT = 1,
        PAGESCROLLHEIGHT = 0,
        PAGEHEIGHT = $('.flex').height(),
        STANDARD = 60,
        isApiLoading = false;
    var f = {
            init: function () {
                var _self = this;
                FastClick.attach(document.body);
                _self.getInfo(CURRENTPAGE, PAGESIZE);
            },
            getInfo: function (_currentPage, _pageSize) {
                if (!isApiLoading) {
                    isApiLoading = true;
                    shan.ajax({
                        data: {
                            url: '/reportmedia/reportlist.htm',
                            currentPage: _currentPage,
                            pageSize: _pageSize
                        },
                        success: function (_json) {
                            console.log(_json);
                            try {
                                if (_json && _json.SZ_HEAD.RESP_CODE == 'S0000' && _json.SZ_BODY.MONTH_READ_COUNT_D) {
                                    $('#readedNum').text(_json.SZ_BODY.MONTH_READ_COUNT_D);
                                }
                                else {
                                    $('#readedNum').text('0');
                                }
                                if (_json && _json.SZ_HEAD.RESP_CODE == 'S0000' && _json.SZ_BODY.REPORT_D) {
                                    $('#infoList').append($('#dInfoList').tmpl(_json.SZ_BODY.REPORT_D));
                                    PAGESCROLLHEIGHT = $('.flex').get(0).scrollHeight;
                                    PAGECOUNT = _json.SZ_BODY.PAGER_D.pageCount;
                                    CURRENTPAGE++;
                                }

                            }
                            catch (e) {
                                console.log(e);
                            }
                            isApiLoading = false;
                        }
                    })
                }

            }
            ,
            bindEvent: function () {
                $('#infoList').on('click', '.item', function () {
                    var orderCode=$(this).attr("data-code") + '';
                    var examineeName=$(this).data('name');
                    var isUploadFinished=$(this).data('isuploadfinished') + '';
                    var amrAudioURL=$(this).data('amraudiourl');
                    var doctorCode=$(this).data('doctorcode');
                    shan.ajax({
                        data: {
                            url: '/examreport/queryReportFileForDoctor.htm',
                            orderCode: orderCode
                        },
                        success: function (_json) {
                            try {
                                if (_json.SZ_HEAD.RESP_CODE == 'S0000') {
                                    webView.callHandler("configAudioRecorderAction", {
                                        examOrderCode: orderCode,
                                        examineeName: examineeName,
                                        isUploadFinished: isUploadFinished,
                                        amrAudioURL: amrAudioURL,
                                        reportURL: '/sz-health-report-detail-app.php?orderCode=' + orderCode,
                                        szMemberToken: _szMemberToken,
                                        memberCode: _memberCode + '',
                                        doctorCode: doctorCode,
                                        reportId: _json.SZ_BODY.REPORT_FILE_BO.reportCode,
                                        reportSignature: _json.SZ_BODY.REPORT_ACCESS_SIGN,
                                        reportPages: _json.SZ_BODY.REPORT_FILE_BO.reportPages
                                    });
                                }
                                else {
                                    pop.alert(_json.SZ_HEAD.RESP_MSG);
                                }
                            }
                            catch (e) {
                                console.log(_json);
                            }
                        }
                    })
                });

                $('.flex').scroll(function () {
                    if ((PAGESCROLLHEIGHT - PAGEHEIGHT - $('.flex')[0].scrollTop) <= STANDARD) {
                        if (CURRENTPAGE <= PAGECOUNT) {
                            f.getInfo(CURRENTPAGE, PAGESIZE);
                        }

                    }
                });
            }
        }
        ;

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});

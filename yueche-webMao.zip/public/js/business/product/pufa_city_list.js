define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    require('lib/fastclick');
    var cityinstit = require('lib/cityinstit');

    var f = {

        init: function () {
            FastClick.attach(document.body);
            cityinstit.linkCss();
        },
        bindEvent: function () {
            $('.goods-info').on('click', function (e) {
                var goodsCode = $(this).attr('data-goods');
                cityinstit.run({
                    goodsCode: goodsCode,
                    onChoose: function () {
                        //do nothing
                    }
                });
            });

            $(".c_goBack").click(function () {
                history.go(-1);
            });

        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    };

    //初始化函数
    exports.run = run;
});

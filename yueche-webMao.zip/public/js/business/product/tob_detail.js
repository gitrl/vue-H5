define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/fastclick');
    var cityinstit = require('lib/cityinstit');
    require('lib/jquery.tmpl');
    require('lib/iscroll');
    require('lib/draggabilly.pkgd.min');
    var reffer = document.referrer;
    var tag = shan.tools.getUrlParam("tag");
    var goodsCode = shan.tools.getUrlParam("goodsCode");

    var f = {
        data: {
            goodsCode: shan.tools.getUrlParam("goodsCode"),
            activityCode: shan.tools.getUrlParam("activityCode"),
            orderFrom: shan.tools.getUrlParam("orderFrom"),
            mainUrl: "/sz/order/tob_confirm?",
            $forPeopleItems: $('#forPeopleItems'),
            $comboLightList: $('#comboLightList'),
            $goodsName: $('#goodsName'),
            $actPrice: $('#actPrice'),
            $szPrice: $('#szPrice'),
            activityPrice: shan.tools.getUrlParam("price"),
            $actPriceBottom: $('#actPriceBottom'),
            $szPriceBottom: $('#szPriceBottom')
        },
        getProductInfo: function () {
            var _self = this,
                _product = {},
                _forPeople = [],
                _goodsFeatures = [],
                _temp = [];
            shan.ajax({
                data: {
                    url: '/szactivity/getActProdDetail.htm',
                    activityCode: _self.data.activityCode,
                    goodsCode: goodsCode
                },
                success: function (_json) {
                    if (_json.SZ_HEAD.RESP_CODE == 'S0000' && _json.SZ_BODY.SZ_ACT_PROD_D) {
                        _product = _json.SZ_BODY.SZ_ACT_PROD_D;
                        _forPeople = _product.forPeople.split('#');
                        for (var i = 0; i < _forPeople.length; i++) {
                            _temp = _forPeople[i].split('@');
                            _forPeople[i] = {};
                            _forPeople[i].name = _temp[0];
                            _forPeople[i].img = _temp[1];
                        }
                        _goodsFeatures = _product.goodsFeatures.split('#');
                        for (var i = 0; i < _goodsFeatures.length; i++) {
                            _temp = _goodsFeatures[i].split('@');
                            _goodsFeatures[i] = {};
                            _goodsFeatures[i].name = _temp[0];
                            _goodsFeatures[i].tips = _temp[1];
                            _goodsFeatures[i].img = _temp[2];
                        }
                        _self.data.$forPeopleItems.empty().append($('#dforPeopleItems').tmpl(_forPeople)).css('width', (_self.data.$forPeopleItems.find('li').length * 0.83) + 'rem');
                        _self.data.$comboLightList.empty().append($('#dcomboLightList').tmpl(_goodsFeatures));
                        setTimeout(function () {
                            var people = new IScroll('#forPeopleItemsWrapper', {
                                scrollX: true,
                                scrollY: false,
                                mouseWheel: true,
                                preventDefault: false
                            }, 100);
                        });
                    }
                    else {
                        window.location.replace('/sz/system/error');
                    }
                }
            });
        },
        init: function () {
            var _self = this;
            FastClick.attach(document.body);
            if (f.data["activityPrice"] != "") {
                $("#actPrice").text(f.data["activityPrice"]);
                $('#nextBtn').attr('href', f.data["mainUrl"] +
                    "price=" + f.data["activityPrice"] +
                    "&goodsCode=" + f.data["goodsCode"]+
                    "&orderFrom=" + f.data["orderFrom"]+"&activityCode="+f.data["activityCode"]);
            }
            cityinstit.linkCss();
            _self.getProductInfo();

        },
        bindEvent: function () {
            var _self = this;
            $('#viewCity,#cityBox').on('click', function (e) {
                shan.tools.statisticsPing(11113);
                cityinstit.run({
                    goodsCode: goodsCode,
                    onChoose: function () {
                        //do nothing
                    }
                });
            });
            if (typeof reffer == "undefined" || reffer == "") {
                $(".c_goBack").click(function () {
                    shan.tools.statisticsPing(11114);
                    history.go(-1);
                });
            } else {
                $(".c_goBack").click(function () {
                    shan.tools.statisticsPing(11114);
                    if (reffer.indexOf('?') > 0) {
                        if (reffer.indexOf('?tag=') > 0) {
                            window.location.href = reffer.replace(/\?tag=[0-9]/g, "") + "?tag=" + tag;
                        }
                        else {
                            window.location.href = reffer.replace(/&tag=[0-9]/g, "") + "&tag=" + tag;
                        }
                    }
                    else {
                        window.location.href = reffer + "?tag=" + tag;
                    }
                });
            }

            $('#moreInfoTab li').click(function () {
                if (!$(this).hasClass('item-on')) {
                    $('.moreInfoItem').addClass('hidden');
                    $(this).addClass('item-on').siblings().removeClass('item-on');
                    $('#' + $(this).data('code')).removeClass('hidden');
                    shan.tools.statisticsPing(11111);
                }else{
                    shan.tools.statisticsPing(11112);
                }
            });

            switch(goodsCode){
                case "GDS110010001":
                    shan.tools.statisticsPing(1111);
                break;

                case "GDS110010002":
                    shan.tools.statisticsPing(1112);
                break;

                case "GDS110010003":
                    shan.tools.statisticsPing(1113);
                break;

                case "GDS110010004":
                    shan.tools.statisticsPing(1114);
                break;

                case "GDS110010005":
                    shan.tools.statisticsPing(1115);
                break;

                case "GDS110010101":
                    shan.tools.statisticsPing(1121);
                break;

                case "GDS110010102":
                    shan.tools.statisticsPing(1122);
                break;

                case "GDS110010103":
                    shan.tools.statisticsPing(1123);
                break;

                case "GDS110010104":
                    shan.tools.statisticsPing(1124);
                break;

                case "GDS110010105":
                    shan.tools.statisticsPing(1125);
                break;

                case "GDS110010011":
                    shan.tools.statisticsPing(1131);
                break;

                case "GDS110010012":
                    shan.tools.statisticsPing(1132);
                break;

                case "GDS110010013":
                    shan.tools.statisticsPing(1133);
                break;

                case "GDS110010014":
                    shan.tools.statisticsPing(1134);
                break;
            }

            //商品服务弹出层
            $('#tags').on('click','.sign',function(){
                shan.tools.statisticsPing('190024');
                if($('.yo-mask').hasClass('hidden')){
                    $('.yo-mask').removeClass('hidden');
                }
                if($('.yo-dialog-sign').hasClass('hidden')){
                    $('.yo-dialog-sign').removeClass('hidden');
                }
            });

            $('.close,.yo-mask,.yo-btn-dialog-sign').click(function(){
                $('.yo-mask').addClass('hidden');
                $('.yo-dialog-sign').addClass('hidden');
            });

            //孝心套餐详情页添加推荐浮标
            var $to_suggest = $('#to-suggest');
            if(_self.data.goodsCode == 'GDS110010001' && _self.data.orderFrom == 1){
                $to_suggest.removeClass('hidden');
            }

            var $toSuggest = $to_suggest.draggabilly();
            $toSuggest.on('staticClick',function (event,pointer) {
                window.location.href='/sz/suggest/suggest_1';
            });



        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    };

    //初始化函数
    exports.run = run;
});

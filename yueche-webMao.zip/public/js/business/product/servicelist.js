define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    require('lib/jquery.lazyload.min.js');

    var f = {
        init: function () {
            $("img.lazy").lazyload({
                placeholder: "/static/images/blank.gif",
                container : $(".flex"),
                threshold: 200
            });   
        },
        bindEvent : function(){
            $(".c_pageBack").click(function(){
                history.back();
                return false;
            });
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});

define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/fastclick');
    require('lib/swiper.min.js');


    var f = {
        init: function () {
            var _self = this;
            shan.tools.statisticsPing('130012');
            FastClick.attach(document.body);
            var swiper = new Swiper('.swiper-container', {
                pagination: '.swiper-pagination',
                paginationClickable: true
            });
            shan.ajax({
                url: '/sz/article/getpraise',
                data: {
                    articleID: $('#goodsCode').val()
                },
                success: function (_json) {
                    console.log(_json);
                    if (_json.SZ_HEAD && _json.SZ_HEAD.RESP_CODE == 'S0000') {
                        $('#wantsNum').text(_json.SZ_BODY.DATA.totalPraise);
                        if (_json.SZ_BODY.DATA.praised == '1') {
                            $('#wants').parent().addClass('cur');
                        }
                    }
                    else {
                        $('#wantsNum').text(0);
                    }
                }
            });

        },
        bindEvent: function () {
            var _self = this;
            $('#wants').click(function () {
                if (!$(this).hasClass('cur')) {
                    shan.tools.statisticsPing('130013');
                    $(this).addClass('cur');
                    $('#wantsNum').text(parseInt($('#wantsNum').text()) + 1);
                    shan.ajax({
                        url: '/sz/article/praise',
                        data: {
                            articleID: $('#goodsCode').val()
                        },
                        success: function (_json) {
                            console.log(_json);
                        }
                    })
                }
            });
            $('.pay-btn').click(function(){
                shan.tools.statisticsPing('130022');
            });
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    };

    //初始化函数
    exports.run = run;
});

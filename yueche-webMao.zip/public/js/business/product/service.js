define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');

    require('lib/jquery.lazyload.min.js');
    var serviceCode = shan.tools.getUrlParam("serviceCode");

    var define = {
        "service1" : "43013",
        "service1_NEXT" : "43014"
    }
    var defineCode = {
        "service1" : "GDS94300111111120"
    }
    var f = {
    	init : function(){
            $("img.lazy").lazyload({
                placeholder: "/static/images/blank.gif",
                container : $(".flex"),
                threshold: 200
            });
            shan.tools.statisticsPing(define[serviceCode]);
    	},
        bindEvent:function(){
            $(".c_open").bind("touchend",function(){
                $('#mask').removeClass('hidden');
                $('#ruleDialog').removeClass('hidden');
            });
            
            $(".c_close").bind("touchend",function(){
                $('#mask').addClass('hidden');
                $('#ruleDialog').addClass('hidden');
            });

            $(".c_next").click(function(){
                shan.tools.statisticsPing(define[serviceCode+"_NEXT"]);
                window.location.href = "/activity-newsale-order-make.php?goodsCode="+defineCode[serviceCode];
            });
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});

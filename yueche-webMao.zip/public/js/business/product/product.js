define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/carousel');
    require('lib/jquery.lazyload.min.js');
    var serviceCode = shan.tools.getUrlParam("serviceCode");
    var orderCode = shan.tools.getUrlParam("orderCode");
    var define = {
        "BLOOD_GLUCOSE_PKG_A_BACK" : "301004",
        "BLOOD_GLUCOSE_PKG_B_BACK" : "301005",
        "BLOOD_GLUCOSE_METER_BACK" : "301006",
        "BLOOD_GLUCOSE_PKG_A_NEXT" : "301007",
        "BLOOD_GLUCOSE_PKG_B_NEXT" : "301008",
        "BLOOD_GLUCOSE_METER_NEXT" : "301009",
        "BLOOD_PRESSURE_METER" : "301022",
        "HYPERTENSION" : "301023",
        "HIGH_BLOOD_LIPID" : "301024",
        "BLOOD_PRESSURE_METER_BACK" : "301025",
        "HYPERTENSION_BACK" : "301026",
        "HIGH_BLOOD_LIPID_BACK" : "301027",
        "BLOOD_PRESSURE_METER_NEXT" : "301028",
        "HYPERTENSION_NEXT" : "301029",
        "HIGH_BLOOD_LIPID_NEXT" : "301030"
    }
    var f = {
    	init : function(){
    		shan.ajax({
                data : {
                    url : "/szreportorder/service_detail.htm",
                    serviceCode : serviceCode
                },
                success: function(json){
                    if(json &&json.SZ_HEAD && json.SZ_HEAD.RESP_CODE == "S0000" && json.SZ_BODY.SERVICE_D){
                        f.showItem(json.SZ_BODY.SERVICE_D);
                    }
                    else{
                        pop.alert("获取商品详情失败!");
                    }
                }
            });
            $("img.lazy").lazyload({
                placeholder: "/static/images/blank.gif",
                container : $(".flex"),
                threshold: 200
            });
            //shan.tools.statisticsPing(define[serviceCode]);
    	},
        showItem : function(data){
            $(".c_shorTitle").text(data.serviceName || "");
            $(".c_desc").text(data.serviceDesc || "");
            $(".c_mainPrice").text("￥"+data.servicePriceVal || "0");
            $(".c_subPrice").text("￥"+data.servicePriceVal || "0");
        },
        bindEvent:function(){
            $('#productCarousel').swipeSlide({
                continuousScroll:true,
                speed : 3000,
                transitionType : 'cubic-bezier(0.22, 0.69, 0.72, 0.88)',
                autoSwipe : false,
                firstCallback : function(i,sum,me){
                    me.find('.dot').children().first().addClass('cur');
                },
                callback : function(i,sum,me){
                    me.find('.dot').children().eq(i).addClass('cur').siblings().removeClass('cur');
                }
            });
            $(".c_next").attr("href","/sz/order/order/serviceCode/"+serviceCode+"?DATA="+define[serviceCode+"_NEXT"]);
            $(".c_pageBack").attr("href","/sz/product/servicelist?DATA=43004");
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});

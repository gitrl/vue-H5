define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/fastclick');
    var cityinstit = require('lib/cityinstit');
    require('lib/jquery.tmpl');
    var reffer = document.referrer;
    var tag = shan.tools.getUrlParam("tag");

    var compareDialog = pop.layer({
        ele: $('#compareDialog')
    });

    var f = {
        data: {
            goodsCode: shan.tools.getUrlParam("goodsCode"),
            activityCode: shan.tools.getUrlParam("activityCode"),
            orderFrom : shan.tools.getUrlParam("orderFrom"),
            mainUrl : "/sz/order/confirm?",
            activityUrl : "/sz/order/confirm2?",
            activityPrice : shan.tools.getUrlParam("price"),
            isFirstCompare: true
        },
        getCompareData: function (opt) {
            shan.ajax({
                data: {
                    url: '/recommend/queryRecommendProductList.htm',
                    activityCode: opt.activityCode,
                    goodsCode: opt.goodsCode
                },
                success: function (_json) {
                    if (_json && _json.SZ_HEAD && _json.SZ_HEAD.RESP_CODE == "S0000") {
                        $('#myProductInfo').empty().append($('#dmyProductInfo').tmpl(_json.SZ_BODY.PROD_LIST));
                        $('#myProductTags').empty().append($('#dmyProductTags').tmpl(_json.SZ_BODY.PROD_LIST));
                        $('#myProductBtn').empty().append($('#dmyProductBtn').tmpl(_json.SZ_BODY.PROD_LIST));
                        compareDialog.init();
                    }
                }

            });
        },
        init: function () {
            FastClick.attach(document.body);
            if (f.data["activityPrice"] != "") {
                $("#activityPrice").text("口令价：￥" + f.data["activityPrice"]);
                $("#actPrice").text("口令价 ￥" + f.data["activityPrice"]);
                if(f.data["orderFrom"] == 1){
                    $('#nextBtn').attr('href', f.data["mainUrl"]+"price="+f.data["activityPrice"]+"&goodsCode="+f.data["goodsCode"]);
                }
                else{
                    $('#nextBtn').attr('href', f.data["activityUrl"]+"price="+f.data["activityPrice"]+"&goodsCode="+f.data["goodsCode"]);
                }
            }
            cityinstit.linkCss();
        },
        bindEvent: function () {
            var _self = this;
            $('#viewCity').on('click', function (e) {
                cityinstit.run({
                    goodsCode: $(this).data('code'),
                    onChoose: function () {
                        //do nothing
                    }
                });
            });

            $('#compareBtn').click(function () {
                if (_self.data.isFirstCompare) {
                    _self.data.isFirstCompare = false;
                    $(this).removeClass('redPoint');
                    _self.getCompareData(_self.data);
                }
                compareDialog.show();

                switch (_self.data.goodsCode){
                    case 'GDS110010001':
                        shan.tools.statisticsPing("56001");
                        break;
                    case 'GDS110010003':
                        shan.tools.statisticsPing("56002");
                        break;
                    case 'GDS110010004':
                        shan.tools.statisticsPing("56003");
                        break;
                    default:
                        break;
                }
            });

            if((typeof reffer == "undefined" || reffer == "") && tag == ""){
                $(".c_goBack").click(function(){
                    history.go(-1);
                });
            }else{
                $(".c_goBack").click(function(){
                    window.location.href = reffer.replace(/&tag=[0-9]/g,"") + "&tag=" + tag;
                });
            }
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    };

    //初始化函数
    exports.run = run;
});

/**
 * Created by wayyue05 on 2017/3/26.
 */
define(function (require, exports, module) {
    var $ = require('jquery');
    require('lib/fastclick');
    require('lib/vue/vue.min');
    require('lib/share/wxshare');
    var pop = require('lib/dialog');
    var shan = require('lib/shan_base');
    var szAudio = require('lib/sz-audio');

    var f = {
        init: function() {
            var _self = this;
            $(function () {
                FastClick.attach(document.body);
            });

            var resultData = JSON.parse(g_data.replace(/\r\n/g,'<br/>').replace(/\n/g,'<br/>').replace(/\t/g,"").replace( /'/g , "\"" )) || null;
            var vm = new Vue({
                el: '#my_ask_result',
                data: {
                    questionDetailInfo: null,   //问题详情
                    reportAbnormalItems: [],    //异常项详情
                    answerTime: '',     //解答时间
                    answerContent: '',      //解答内容（老，不需解码）
                    answerContentEncoded: '',      //解答内容（新，需要解码）
                    answerVoiceUrl: '',     //解答语音的链接
                    answerVoiceLength: '',      //解答语音时长
                    doctorInfo: null,   //医生详情
                    commentRating: 0,   //评论星级
                    comments: '',       //评论内容（老，不需解码）
                    commentsEncoded: '',    //评论内容（新，需要解码）
                    myComment: '',      //用户提交的评论
                    myScore: 0,     //用户评价星级
                    items:[
                        {score:2,isActive:false},
                        {score:4,isActive:false},
                        {score:6,isActive:false},
                        {score:8,isActive:false},
                        {score:10,isActive:false}
                    ]
                },
                created: function(){
                    //问题详情
                    if(resultData.questionDetailInfo){
                        this.questionDetailInfo = resultData.questionDetailInfo;
                    }
                    //根据是否有解答显示
                    if(resultData.answerInfo){
                        this.answerTime = resultData.answerInfo.createTime;
                        if(resultData.answerInfo.answerVoiceUrl){
                            this.answerVoiceUrl = resultData.answerInfo.answerVoiceUrl;
                            this.answerVoiceLength = resultData.answerInfo.answerVoiceLength;
                        }else{
                            if(typeof resultData.answerInfo.answerContent != 'undefined'){
                                this.answerContent = resultData.answerInfo.answerContent;
                            }
                            if(typeof resultData.answerInfo.answerContentEncoded != 'undefined'){
                                this.answerContentEncoded = resultData.answerInfo.answerContentEncoded;
                            }
                        }
                        if(typeof resultData.answerInfo.comments != 'undefined' || typeof resultData.answerInfo.commentsEncoded != 'undefined'){
                            this.commentRating = resultData.answerInfo.commentRating;
                            //显示评论星级
                            var stars = Math.ceil(this.commentRating / 2);
                            for(var i = 0; i < stars;i++){
                                $('.J-get-score').find('.item').find('span').eq(i).addClass('active');
                            }
                        }
                        if(typeof resultData.answerInfo.comments != 'undefined'){
                            this.comments = resultData.answerInfo.comments;
                        }
                        if(typeof resultData.answerInfo.commentsEncoded != 'undefined'){
                            this.commentsEncoded = resultData.answerInfo.commentsEncoded;
                        }
                    }
                    //根据是否有医生信息显示
                    if(resultData.doctorInfo){
                        this.doctorInfo = resultData.doctorInfo;
                    }
                    //根据是否有异常项显示
                    if(resultData.questionDetailInfo.reportAbnormalItems && resultData.questionDetailInfo.reportAbnormalItems.length > 0){
                        shan.tools.statisticsPing("253015");
                        this.reportAbnormalItems = resultData.questionDetailInfo.reportAbnormalItems;
                    }else{
                        shan.tools.statisticsPing("253017");
                    }
                },
                filters: {
                    to_minute: function (value) {
                        var minute = Math.floor((value / 60) % 60);
                        var second = Math.floor(value % 60);
                        if(second < 10){
                            second = '0' + second;
                        }
                        return minute + ":" + second + '"';
                    },
                    deCode: function(value) {
                        return shan.tools.deCodeUrl(value);
                    }
                },
                methods: {
                    doctorDetailsUrl: function(){
                        window.location.href = '/sz/ask/doctor_details?doctorCode=' + this.doctorInfo.doctorCode;
                    },
                    setScore: function(index){
                        for(var i = 0; i< this.items.length;i++){
                            this.items[i].isActive = false;
                        }
                        for(var i = 0; i <= index;i++){
                            this.items[i].isActive = true;
                        }
                        this.myScore = this.items[index].score;
                        shan.tools.statisticsPing("311008");
                    },
                    writeComment: function(){
                        shan.tools.statisticsPing("311009");
                    },
                    submitComment: function(){
                        shan.tools.statisticsPing("311010");
                        //验证星级不为空
                        if(!this.myScore){
                            pop.alert('先打分才能提交哦~');
                            return false;
                        }
                        //验证评论内容不为空
                        if(!this.myComment){
                            pop.alert('请对医生说点鼓励的话吧~');
                            return false;
                        }
                        if(this.myComment.length > 200){
                            pop.alert('最好不要超过200个字哦~');
                            return false;
                        }
                        //提交内容
                        shan.ajax({
                            url: '/sz/ask/my_comment_async',
                            type: 'post',
                            data: {
                                orderCode: this.questionDetailInfo.orderCode,
                                doctorCode: this.doctorInfo.doctorCode,
                                score: this.myScore,
                                comments: this.myComment
                            },
                            success: function(json){
                                if(json.SZ_HEAD.RESP_CODE == 'S0000'){
                                    //刷新页面显示结果
                                    window.location.reload();
                                }else{
                                    pop.alert('系统繁忙，请稍后再试~');
                                }
                            }
                        });
                    }
                }
            });

            //语音播放
            var opt = {
                ele: $('#szAudio').get(0),
                min: 0,
                step: 1,
                audioDuration: vm.answerVoiceLength,
                firstPingID: '311006',
                thirdPingID: '311007'
            };
            szAudio.init(opt);
            $('#szAudio').on('click',function(){
                shan.tools.statisticsPing("311005");
            });

            var options = {
                title: '善诊健康问医生',
                desc: vm.questionDetailInfo.questionContent,
                imgUrl: "https://"+window.location.host+"/static/images/ask/share_icon.png"
            };
            if(!options.desc){
                options.desc = shan.tools.deCodeUrl(vm.questionDetailInfo.questionContentEncoded);

            }

            //配置微信分享
            var controller = new wxController();
            controller.init(
                ['onMenuShareTimeline', 'onMenuShareAppMessage'],
                function () {
                    controller.configShareTimeline({
                        title: options.title, // 分享标题
                        desc:  options.desc, // 分享描述
                        imgUrl: options.imgUrl, //分享图标
                        success: function () {
                            shan.tools.statisticsPing("311012");
                        },
                        cancel: function () {
                        }
                    });
                    controller.configShareAppMessage({
                        title: options.title, // 分享标题
                        desc:  options.desc, // 分享描述
                        imgUrl: options.imgUrl, //分享图标
                        type: '', // 分享类型,music、video或link，不填默认为link
                        dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
                        success: function () {
                            shan.tools.statisticsPing("311011");
                        },
                        cancel: function () {
                        }
                    });
                }
            );

        }
    };

    var run = function () {
        f.init();
    };

    //初始化函数
    exports.run = run;
});

define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/iscroll-probe');
    require('lib/fastclick');
    require('lib/vue/vue.min');
    var SCROLL = require('lib/sz_scroll');

    var f = {
        init: function () {
            $(function () {
                FastClick.attach(document.body);
            });
            $(document).on('touchmove', function (e) {
                e.preventDefault();
            }, false);


            var doctorInfo = JSON.parse(g_doctorInfo) || null;
            var historyAnswers = JSON.parse(g_historyAnswers) || [];

            var vm = new Vue({
                el: '#scroller',
                data:{
                    doctorName: doctorInfo.doctorName,
                    headPortrait: doctorInfo.headPortrait,
                    jobTitles: doctorInfo.jobTitles,
                    institName: doctorInfo.institName,
                    deptName: doctorInfo.deptName,
                    commonScore: doctorInfo.commonScore,
                    items: historyAnswers,
                    page: 2,
                    myScroll: null,
                    listObject: {
                        marginTop: '0'
                    },
                    loadingStep: 0,
                    pullUpStatus: {
                        refresh: false,
                        loading: false
                    },
                    pullUpTipsShow: true,
                    pullUpLabelText: '',
                    pullUpTips: '上拉加载更多...'
                },
                created: function(){
                    //还未有用户评分时
                    if(!doctorInfo.commonScore || doctorInfo.commonScore <= 0){
                        this.commonScore = '暂未评价';
                    }
                    //根据评分显示星级数
                    var stars = Math.ceil(this.commonScore / 2);
                    for(var i = 0; i < stars;i++){
                        $('.yo-rating-doctor').find('.item').find('span').eq(i).addClass('active');
                    }
                    //先判断现有数据是否小于5
                    if(historyAnswers.length < 5){
                        this.pullUpTipsShow = true;
                        this.pullUpTips = '—— 已经到底了 ——';
                        $('#pullUp').hide();
                    }
                },
                filters: {
                    deCode: function(value) {
                        return shan.tools.deCodeUrl(value);
                    }
                },
                mounted: function(){
                    this.initMyScroll();
                },
                methods: {
                    questionDetailsUrl: function (index) {
                        window.location.href = '/sz/ask/answer_doctor?detailFrom=4&orderCode=' + this.items[index].questionInfo.orderCode;
                    },
                    initMyScroll: function(){
                        $('#pullUp').hide();
                        //iScroll初始化
                        this.myScroll = new IScroll("#wrapper",SCROLL.initData());
                        //手指向上拉动
                        this.myScroll.on('scroll', SCROLL.scrollTop(this));
                        //手指松开刷新
                        this.myScroll.on('scrollEnd',SCROLL.scrollLoosen(this));
                    },
                    pullUpAction: function(){
                        setTimeout(function(){
                            shan.ajax({
                                url: '/sz/ask/history_list_async',
                                async : true,
                                data: {
                                    currentPage: vm.page,
                                    doctorCode: shan.tools.getUrlParam('doctorCode')
                                },
                                success: function(json){
                                    if(json.SZ_HEAD.RESP_CODE == 'S0000'){
                                        if(json.SZ_BODY.historyAnswers.length >= 1){
                                            var moreAnswers = json.SZ_BODY.historyAnswers;
                                            vm.items = vm.items.concat(moreAnswers);
                                            SCROLL.pullSuccess(vm,'-0.5rem');
                                            vm.page++;
                                        }else{
                                            vm.pullUpTipsShow = true;
                                            vm.pullUpTips = '—— 已经到底了 ——';
                                            $('#pullUp').hide();
                                        }

                                    }else{
                                        pop.alert('系统异常，请稍后再试');
                                    }

                                }
                            });
                        },100);
                    }
                }
            });
        }
    };



    var run = function () {
        f.init();
    };

    //初始化函数
    exports.run = run;
});
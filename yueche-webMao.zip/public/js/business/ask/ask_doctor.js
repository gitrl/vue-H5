define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/iscroll-probe');
    require('lib/share/wxshare');
    require('lib/fastclick');
    require('lib/vue/vue.min');
    require('lib/vue/vue-router.min.js');
    require('lib/vue/vue-lazyload');
    var SCROLL = require('lib/sz_scroll');
    Vue.use(VueRouter);
    var scrollSave = 0;
    var cache_items = {};
    var f = {
        init: function () {
            shan.tools.statisticsPing("33020");
            $(function () {
                FastClick.attach(document.body);
            });
            $(document).on('touchmove', function (e) {
                e.preventDefault();
            }, false);

            //获取并处理问题分类数据
            var tagLists = f.getData(JSON.parse(g_tagLists)) || [];
            var questionLists = JSON.parse(g_questionLists) || [];
            Vue.use(VueLazyload, {
                preLoad: 1.3,
                error: '/static/images/ask/icon_logo.png',
                loading: '/static/images/avatar.jpg',
                attempt: 1
            });
            var tag_template= { 
                    template: '#ask-template',
                    mounted: function(){
                        this.initMyScroll();
                    },
                    activated: function(){
                        this.tabTag(this.$route.fullPath.replace('/',''));
                        if(scrollSave == 0){
                            scrollSave = $((document.getElementsByClassName('question-list-area'))[0]).css("transform");
                        }
                        $(".flex").css(scrollSave);
                    },
                    data: function(){
                        return {
                            imgBanner: '/static/images/ask/index/banner_ask.jpg',
                            tag_items: tagLists,
                            items: {},
                            tagCode:'',
                            isPicked: true,
                            dialogShow: false,
                            page: 2,
                            myScroll: null,
                            listObject: {marginTop: '0'},
                            loadingStep: 0,
                            pullUpStatus: {refresh: false, loading: false},
                            pullUpTipsShow: true,
                            pullUpLabelText: '',
                            pullUpTips: '上拉加载更多...',
                            pullUpMore: true
                        };
                    },
                    filters: {
                        to_minute: function (value) {
                            var minute = Math.floor((value / 60) % 60);
                            var second = Math.floor(value % 60);
                            if(second < 10){
                                second = '0' + second;
                            }
                            return minute + ":" + second + '"';
                        },
                        deCode: function(value) {
                            return shan.tools.deCodeUrl(value);
                        }
                    },
                    methods: {
                        tabPicked: function(){ //切换精选标签
                            shan.tools.statisticsPing('33010');
                        },
                        tabTag: function(index){ //切换其它标签
                            this.page = 2;
                            this.tagCode = this.tag_items[index].tagCode;
                            this.isPicked = false;
                            for(var i = 0,len=this.tag_items.length;i<len;i++){
                                this.tag_items[i].isActive = false;
                            }
                            this.tag_items[index].isActive = true;

                            //判断是读取缓存还是获取新数据
                            if(typeof cache_items[this.tagCode] != "undefined" && cache_items[this.tagCode].length != 0){
                                this.items = cache_items[this.tagCode];
                                this.pullUpMore = true;
                                return;
                            }
                            cache_items[this.tagCode] = [];
                            this.pullUpStatus.refresh = false;
                            this.pullUpStatus.loading = false;
                            this.loadingStep = 0;
                            
                            //ajax请求切换问题列表
                            shan.ajax({
                                 url: '/sz/ask/ask_question_list_async',
                                 async : true,
                                 data: {
                                     tagCode: tagLists[index].tagCode
                                 },
                                 success: function(json){
                                     if(json.SZ_HEAD.RESP_CODE == 'S0000'){
                                        window_vue.$refs.vm.items = json.SZ_BODY.QUESTION_ORDER_D;
                                        if(window_vue.$refs.vm.items.length == 0){
                                            window_vue.$refs.vm.pullUpTipsShow = true;
                                            window_vue.$refs.vm.pullUpTips = '—— 已经到底了 ——';
                                            return;
                                        }
                                        cache_items[window_vue.$refs.vm.tagCode] = cache_items[window_vue.$refs.vm.tagCode].concat(json.SZ_BODY.QUESTION_ORDER_D);
                                        
                                     }else{
                                         pop.alert('系统繁忙,请稍后再试');
                                     }
                                 }
                             });

                            shan.tools.statisticsPing('3301' + (index + 1));
                        },
                        initMyScroll: function(){
                            $('#pullUp').hide();
                            //iScroll初始化
                            this.myScroll = new IScroll("#wrapper",SCROLL.initData());
                            //手指向上拉动
                            this.myScroll.on('scroll', SCROLL.scrollTop(this));
                            //手指松开刷新
                            this.myScroll.on('scrollEnd',SCROLL.scrollLoosen(this));
                        },
                        pullUpAction: function(){
                            setTimeout(function(){
                                //翻页时根据是否选中的是精选问题，请求不同接口
                                var pageUrl ='',
                                    pageData = {};
                                if(window_vue.$refs.vm.isPicked){
                                    pageUrl = '/sz/index/ask_list_async';
                                    pageData = {
                                        currentPage: window_vue.$refs.vm.page
                                    }
                                }else{
                                    pageUrl = '/sz/ask/ask_more_question_list_async';
                                    pageData = {
                                        currentPage: window_vue.$refs.vm.page,
                                        tagCode: window_vue.$refs.vm.tagCode
                                    }
                                }
                                shan.ajax({
                                     url: pageUrl,
                                     async : true,
                                     data: pageData,
                                     success: function(json){
                                         if(json.SZ_HEAD.RESP_CODE == 'S0000'){
                                             $('#pullUp').hide();
                                             if(json.SZ_BODY.QUESTION_ORDER_D.length >= 1){
                                                 var moreData = json.SZ_BODY.QUESTION_ORDER_D;
                                                 window_vue.$refs.vm.items = window_vue.$refs.vm.items.concat(moreData);
                                                 cache_items[window_vue.$refs.vm.tagCode] = cache_items[window_vue.$refs.vm.tagCode].concat(moreData);
                                                 SCROLL.pullSuccess(window_vue.$refs.vm,'-2rem');
                                                 window_vue.$refs.vm.page++;
                                             }else{
                                                 window_vue.$refs.vm.pullUpTipsShow = true;
                                                 window_vue.$refs.vm.pullUpTips = '—— 已经到底了 ——';
                                             }
                                         }else{
                                            pop.alert('系统繁忙，请稍后再试');
                                         }
                                    }
                                 });
                            },100);
                        },
                        fastAskUrl: function(){
                            shan.tools.statisticsPing("33019");
                            //请求是否有权限提问接口
                            shan.ajax({
                                url: '/sz/ask/ask_fasking_async',
                                async : true,
                                data: {},
                                success: function(json){
                                    if(json.SZ_HEAD.RESP_CODE == 'S0000'){
                                        if(json.SZ_BODY.ASKING_AUTH == '1'){
                                            window.location.href = '/sz/order/fast_ask';
                                        }else{
                                            window_vue.$refs.vm.dialogShow = true;
                                            shan.tools.statisticsPing('33023');
                                        }
                                    }else{
                                        pop.alert('系统繁忙，请稍后再试');
                                    }
                                }
                            });
                        },
                        toBuy: function(){
                            shan.tools.statisticsPing('33024');
                        },
                        closeDialog: function(){
                            this.dialogShow = false;
                        },
                        questionDetailsUrl: function(index){
                            window.location.href = '/sz/ask/answer_doctor?detailFrom=2&orderCode=' + this.items[index].orderCode;
                            shan.tools.statisticsPing('311002');
                        }
                    }
                };

            function TagObject(templateObj){
                this.data = templateObj.data;
                this.template = templateObj.template;
                this.activated = templateObj.activated;
                this.mounted = templateObj.mounted;
                this.methods = templateObj.methods;
                this.filters = templateObj.filters;
            }

            var tag_0 = new TagObject(tag_template);
            var tag_1 = new TagObject(tag_template);
            var tag_2 = new TagObject(tag_template);
            var tag_3 = new TagObject(tag_template);
            var tag_4 = new TagObject(tag_template);
            var tag_5 = new TagObject(tag_template);
            var tag_6 = new TagObject(tag_template);
            var tag_7 = new TagObject(tag_template);

            var first_components = {
                template: '#ask-template',
                data: function(){
                    return {
                        imgBanner: '/static/images/ask/index/banner_ask.jpg',
                        tag_items: tagLists,
                        items: questionLists,
                        tagCode:'',
                        isPicked: true,
                        dialogShow: false,
                        page: 2,
                        myScroll: null,
                        listObject: {marginTop: '0'},
                        loadingStep: 0,
                        pullUpStatus: {refresh: false, loading: false},
                        pullUpTipsShow: true,
                        pullUpLabelText: '',
                        pullUpTips: '上拉加载更多...',
                        pullUpMore: true,
                        cache_tagCode: "first",
                        cache_items: {"first":questionLists}
                    }
                },
                filters: {
                    to_minute: function (value) {
                        var minute = Math.floor((value / 60) % 60);
                        var second = Math.floor(value % 60);
                        if(second < 10){
                            second = '0' + second;
                        }
                        return minute + ":" + second + '"';
                    },
                    deCode: function(value) {
                        return shan.tools.deCodeUrl(value);
                    }
                },
                mounted: function(){
                    this.initMyScroll();
                },
                activated: function(){
                    for(var i = 0,len=this.tag_items.length;i<len;i++){
                        this.tag_items[i].isActive = false;
                    }
                    $(".flex").scrollTop(scrollSave);
                },
                methods: {
                    tabPicked: function(){ //切换精选标签
                        shan.tools.statisticsPing('33010');
                    },
                    tabTag: function(index){ //切换其它标签
                        shan.tools.statisticsPing('3301' + (index + 1));
                    },
                    fastAskUrl: function(){
                        //请求是否有权限提问接口
                        shan.ajax({
                            url: '/sz/ask/ask_fasking_async',
                            async : true,
                            data: {},
                            success: function(json){
                                if(json.SZ_HEAD.RESP_CODE == 'S0000'){
                                    if(json.SZ_BODY.ASKING_AUTH == '1'){
                                        window.location.href = '/sz/order/fast_ask?orderSource=1';
                                    }else{
                                        window_vue.$refs.vm.dialogShow = true;
                                    }
                                }else{
                                    pop.alert('系统繁忙，请稍后再试');
                                }
                            }
                        });
                    },
                    closeDialog: function(){
                        this.dialogShow = false;
                    },
                    toBuy: function(){
                        shan.tools.statisticsPing('33024');
                    },
                    questionDetailsUrl: function(index){
                        window.location.href = '/sz/ask/answer_doctor?detailFrom=2&orderCode=' + this.items[index].orderCode;
                        shan.tools.statisticsPing('311002');
                    },
                    initMyScroll: function(){
                        $('#pullUp').hide();
                        //iScroll初始化
                        this.myScroll = new IScroll("#wrapper",SCROLL.initData());
                        //手指向上拉动
                        this.myScroll.on('scroll', SCROLL.scrollTop(this));
                        //手指松开刷新
                        this.myScroll.on('scrollEnd',SCROLL.scrollLoosen(this));
                    },
                    pullUpAction: function(){
                        setTimeout(function(){
                            //翻页时根据是否选中的是精选问题，请求不同接口
                            var pageUrl ='',
                                pageData = {};
                            if(window_vue.$refs.vm.isPicked){
                                pageUrl = '/sz/index/ask_list_async';
                                pageData = {
                                    currentPage: window_vue.$refs.vm.page
                                }
                            }else{
                                pageUrl = '/sz/ask/ask_more_question_list_async';
                                pageData = {
                                    currentPage: window_vue.$refs.vm.page,
                                    tagCode: window_vue.$refs.vm.tagCode
                                }
                            }
                            shan.ajax({
                                 url: pageUrl,
                                 async : true,
                                 data: pageData,
                                 success: function(json){
                                     if(json.SZ_HEAD.RESP_CODE == 'S0000'){
                                         $('#pullUp').hide();
                                         if(json.SZ_BODY.QUESTION_ORDER_D.length >= 1){
                                             var moreData = json.SZ_BODY.QUESTION_ORDER_D;
                                             window_vue.$refs.vm.items = window_vue.$refs.vm.items.concat(moreData);
                                             SCROLL.pullSuccess(window_vue.$refs.vm,'-2rem');
                                             window_vue.$refs.vm.page++;
                                         }else{
                                             window_vue.$refs.vm.pullUpTipsShow = true;
                                             window_vue.$refs.vm.pullUpTips = '—— 已经到底了 ——';
                                         }
                                     }else{
                                        pop.alert('系统繁忙，请稍后再试');
                                     }
                                }
                             });
                        },100);
                    }
                }
            };

            var router = new VueRouter({
                routes: [
                    {path: '/0', component: tag_0},
                    {path: '/1', component: tag_1},
                    {path: '/2', component: tag_2},
                    {path: '/3', component: tag_3},
                    {path: '/4', component: tag_4},
                    {path: '/5', component: tag_5},
                    {path: '/6', component: tag_6},
                    {path: '/7', component: tag_7},
                    {path: '/', component: first_components}
                ]
            });

            var window_vue = new Vue({
                el: "#window",
                router: router
            });

            router.beforeEach( function(to, from, next){
                //scrollSave = (document.getElementsByClassName('question-list-area'))[0].scrollTop;
                scrollSave = $((document.getElementsByClassName('question-list-area'))[0]).css("transform");
                next();
            });

            $('#index').click(function(){
                shan.tools.statisticsPing('130000');
            });
            $('#activity').click(function(){
                shan.tools.statisticsPing('130001');
            });
            $('#report').click(function(){
                shan.tools.statisticsPing('130002');
            });
            $('#user').click(function(){
                shan.tools.statisticsPing('130003');
            });
            $('#ask').click(function(){
                shan.tools.statisticsPing('33025');
            });

            var options = {
                title: '善诊健康问医生',
                desc: '善诊精选，为您的健康保驾护航！',
                imgUrl: "https://"+window.location.host+"/static/images/ask/share_icon.png"
            };

            //配置微信分享
            var controller = new wxController();
            controller.init(
                ['onMenuShareTimeline', 'onMenuShareAppMessage'],
                function () {
                    controller.configShareTimeline({
                        title: options.title, // 分享标题
                        desc:  options.desc, // 分享描述
                        imgUrl: options.imgUrl, //分享图标
                        success: function () {
                            shan.tools.statisticsPing("311016");
                        },
                        cancel: function () {}
                    });
                    controller.configShareAppMessage({
                        title: options.title, // 分享标题
                        desc:  options.desc, // 分享描述
                        imgUrl: options.imgUrl, //分享图标
                        type: '', // 分享类型,music、video或link，不填默认为link
                        dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
                        success: function () {
                            shan.tools.statisticsPing("311015");
                        },
                        cancel: function () {}
                    });
                }
            );
        },
        getData: function(initArr){
            var dataArr = [];
            for(var i=0,len=initArr.length;i<len;i++) {
                dataArr[i] = function (num) {
                    return initArr[num];
                }(i);
                dataArr[i].isActive = false;
            }
            return dataArr;
        }
    };

    var run = function () {
        f.init();
    };

    //初始化函数
    exports.run = run;
});
/**
 * Created by wayyue05 on 2017/3/26.
 */
define(function (require, exports, module) {
    var $ = require('jquery');
    require('lib/fastclick');
    require('lib/vue/vue.min');
    var shan = require('lib/shan_base');

    var orderCode = shan.tools.getUrlParam('orderCode'),
        status = shan.tools.getUrlParam('status'),
        createTime = decodeURI(shan.tools.getUrlParam('createTime')),
        interpretationDoctorInfo = shan.tools.getUrlParam('interpretationDoctorInfo'),
        reportBrief = decodeURI(shan.tools.getUrlParam('reportBrief')),
        relatedReportCode = shan.tools.getUrlParam('relatedReportCode');

    var f = {
        init: function() {
            $(function () {
                FastClick.attach(document.body);
            });
            var vm = new Vue({
                el: '#my_ask_result',
                data: {
                    orderCode: orderCode,    //订单号
                    status: status,     //解读状态
                    createTime: createTime,     //提交时间
                    interpretationDoctorInfo: '',   //医生信息
                    reportBrief: reportBrief,   //报告标识
                    reportLink: '/sz/report/index?orderCode=' + relatedReportCode   //查看报告链接
                },
                created: function(){
                    shan.tools.statisticsPing("253016");
                    //根据已解答显示
                    if(status == 1 && typeof interpretationDoctorInfo != 'undefined'){
                        this.interpretationDoctorInfo = JSON.parse(decodeURI(interpretationDoctorInfo));
                    }
                },
                methods: {
                    //查看医生详情
                    doctorDetailsUrl: function(){
                        window.location.href = '/sz/ask/doctor_details?doctorCode=' + this.interpretationDoctorInfo.doctorCode;
                    }
                }
            });
        }
    };

    var run = function () {
        f.init();
    };

    //初始化函数
    exports.run = run;
});

define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/fastclick');
    require('lib/vue/vue.min');
    require('lib/share/wxshare');
    require('lib/vue/vue-lazyload');
    var szAudio = require('lib/sz-audio');

    var detailFrom = shan.tools.getUrlParam("detailFrom");
    var f = {
        init: function () {
            shan.tools.statisticsPing("311004",{sourceCode: detailFrom});
            $(function () {
                FastClick.attach(document.body);
            });

            var questionDetailInfo = JSON.parse(g_questionDetailInfo) || null;
            var doctorInfo = JSON.parse(g_doctorInfo) || null,
                answerInfo = JSON.parse(g_answerInfo) || null;
            var similarQuestions = JSON.parse(g_similarQuestions) || [];
            Vue.use(VueLazyload, {
                preLoad: 1.3,
                error: '/static/images/ask/icon_logo.png',
                loading: '/static/images/avatar.jpg',
                attempt: 1
            });
            var vm = new Vue({
                el: '#question-list',
                data: {
                    username: "匿名用户",
                    questionContent: questionDetailInfo.questionContent,
                    questionContentEncoded: questionDetailInfo.questionContentEncoded,
                    questionTime: questionDetailInfo.createTime.substring(0,10),
                    headPortrait: doctorInfo.headPortrait,
                    doctorName: doctorInfo.doctorName,
                    jobTitles: doctorInfo.jobTitles,
                    institName: doctorInfo.institName,
                    deptName: doctorInfo.deptName,
                    doctorCode: doctorInfo.doctorCode,
                    answerContent: answerInfo.answerContent,
                    answerContentEncoded: answerInfo.answerContentEncoded,
                    answerVoiceUrl: answerInfo.answerVoiceUrl,
                    answerVoiceLength: answerInfo.answerVoiceLength,
                    answerTime: answerInfo.createTime.substring(0,10),
                    items: similarQuestions
                },
                filters: {
                    to_minute: function (value) {
                        var minute = Math.floor((value / 60) % 60);
                        var second = Math.floor(value % 60);
                        if(second < 10){
                            second = '0' + second;
                        }
                        return minute + ":" + second + '"';
                    },
                    deCode: function(value) {
                        return shan.tools.deCodeUrl(value);
                    }
                },
                methods: {
                    doctorDetailsUrl: function(){
                        window.location.href = '/sz/ask/doctor_details?doctorCode=' + doctorInfo.doctorCode;
                    },
                    questionDetailsUrl: function(index){
                        window.location.href = '/sz/ask/answer_doctor?detailFrom=3&orderCode=' + this.items[index].orderCode;
                    }
                }
            });


            var options = {
                title: '善诊健康问医生',
                desc: questionDetailInfo.questionContent,
                imgUrl: "https://"+window.location.host+"/static/images/ask/share_icon.png"
            };

            //语音播放
            var opt = {
                ele: $('#szAudio').get(0),
                min: 0,
                step: 1,
                audioDuration: vm.answerVoiceLength,
                firstPingID: '311006',
                thirdPingID: '311007'
            };
            szAudio.init(opt);
            $('#szAudio').on('click',function(){
                shan.tools.statisticsPing("311005");
            });

            //配置微信分享
            var controller = new wxController();
            controller.init(
                ['onMenuShareTimeline', 'onMenuShareAppMessage'],
                function () {
                    controller.configShareTimeline({
                        title: options.title, // 分享标题
                        desc:  options.desc, // 分享描述
                        imgUrl: options.imgUrl, //分享图标
                        success: function () {
                            shan.tools.statisticsPing("311014");
                        },
                        cancel: function () {
                        }
                    });
                    controller.configShareAppMessage({
                        title: options.title, // 分享标题
                        desc:  options.desc, // 分享描述
                        imgUrl: options.imgUrl, //分享图标
                        type: '', // 分享类型,music、video或link，不填默认为link
                        dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
                        success: function () {
                            shan.tools.statisticsPing("311013");
                        },
                        cancel: function () {
                        }
                    });
                }
            );
        }
    };




    var run = function () {
        f.init();
    };

    //初始化函数
    exports.run = run;
});
/**
 * Created by wayyue05 on 2017/2/21.
 */
define(function (require, exports, module) {
    var $ = require('jquery');
    require('lib/fastclick');
    require('lib/iscroll-probe');
    require('lib/vue/vue.min');
    var pop = require('lib/dialog');
    var shan = require('lib/shan_base');
    var SCROLL = require('lib/sz_scroll');

    var f = {
        init: function(){
            shan.tools.statisticsPing(312001);
            $(function () {
                FastClick.attach(document.body);
            });
            $(document).on('touchmove', function (e) {
                e.preventDefault();
            }, false);

            var report_ask_list = JSON.parse(g_report_ask_list) || [];    //报告解读数据初始化
            var question_list = JSON.parse(g_question_list.replace(/\r\n/g,'<br/>').replace(/\n/g,'<br/>').replace(/\t/g,"").replace( /'/g , "\"" )) || []; //问答列表数据初始化
            //渲染第一页的数据
            var vm = new Vue({
                el: '#wrapper',
                data: {
                    report_ask_list: [],    //报告解读列表
                    dataArr: [],    //问题列表
                    noOrder: 0,     //无订单样式
                    noPop: 0,
                    page: 2,
                    pageSize: 5,
                    myScroll: {},
                    listObject: {
                        marginTop: '0'
                    },
                    pullUpStatus: {
                        refresh: false,
                        loading: false
                    },
                    pullUpTipsShow: false,
                    pullUpLabelText: '',
                    pullUpTips: '上拉加载更多...',
                    loadingStep: 0  //加载状态0默认，1显示加载状态，2执行加载数据，只有当为0时才能再次加载，这是防止过快拉动刷新
                },
                created: function(){
                    if((!question_list || question_list.length == 0) && (!report_ask_list || report_ask_list.length == 0)){//如无订单
                        this.noOrder = 1;
                        return;
                    }
                    if(report_ask_list.length > 0){
                        this.report_ask_list = report_ask_list;
                    }
                    if(question_list.length > 0){
                        this.dataArr = this.formatData(question_list);
                    }
                },
                filters: {
                    to_minute: function (value) {
                        var minute = Math.floor((value / 60) % 60);
                        var second = Math.floor(value % 60);
                        if(second < 10){
                            second = '0' + second;
                        }
                        return minute + ":" + second + '"';
                    },
                    deCode: function(value) {
                        return shan.tools.deCodeUrl(value);
                    },
                    status_to_text: function(value){
                        switch (value){
                            case 0:
                                value = '待解答';
                                break;
                            case 1:
                                value = '已解答';
                                break;
                            case -1:
                                value = '解答失败';
                                break;
                        }
                        return value;
                    }
                },
                mounted: function(){
                    this.initMyScroll();
                },
                methods: {
                    detailUrl: function(orderCode,questionStatus){
                        window.location.href = '/sz/ask/my_ask_details?orderCode=' + orderCode;
                        switch (parseInt(questionStatus)){
                            case 0:
                            case 1:
                                shan.tools.statisticsPing("311001");
                                break;
                            case 2:
                                shan.tools.statisticsPing("3110011");
                                break;
                            case -1:
                                shan.tools.statisticsPing("3110012");
                                break;
                        }
                    },
                    detailReportAsk: function(orderCode,status,createTime,interpretationDoctorInfo,reportBrief,relatedReportCode){
                        window.location.href = encodeURI('/sz/ask/my_report_ask_details?orderCode=' + orderCode +
                                                                        '&status=' + status +
                                                                        '&createTime=' + createTime +
                                                                        '&interpretationDoctorInfo=' + JSON.stringify(interpretationDoctorInfo) +
                                                                        '&reportBrief=' + reportBrief +
                                                                        '&relatedReportCode=' + relatedReportCode);
                    },
                    formatData: function(initArr){
                        var dataArr = [];
                        for(var i=0, len=initArr.length; i<len;i++){
                            var item = initArr[i];
                            switch (item.questionStatus){
                                case 0:       //未解答未分配
                                case 1:       //未解答已分配
                                    item.questionStatusText = "待解答";
                                    item.questionStatusTextClass = "text-red";
                                    item.hasAnswer = false;
                                    break;
                                case 2:      //已解答
                                    item.questionStatusText="已解答";
                                    item.questionStatusTextClass = "text-blue";
                                    item.hasAnswer = true;
                                    break;
                                case -1:      //解答失败
                                    item.questionStatusText="解答失败";
                                    item.questionStatusTextClass = "text-gray";
                                    item.hasAnswer = false;
                                    break;
                            }
                            if(item.hasAnswer && typeof item.doctorAssign == "undefined"){
                                item.doctorAssign = {};
                                item.doctorAssign.headPortrait = "";
                            }
                            if(!item.reportAbnormalItems || item.reportAbnormalItems.length == 0){
                                item.questionTypeClass = 'ask';
                                item.questionType = '快问医生';
                            }else{
                                item.questionTypeClass = 'abnormal';
                                item.questionType = '异常解读'
                            }
                            dataArr.push(item);
                        }
                        return dataArr;
                    },
                    initMyScroll: function(){
                        $('#pullUp').hide();
                        //iScroll初始化
                        this.myScroll = new IScroll("#wrapper",SCROLL.initData());
                        //手指向上拉动
                        this.myScroll.on('scroll', SCROLL.scrollTop(this));
                        //手指松开刷新
                        this.myScroll.on('scrollEnd',SCROLL.scrollLoosen(this));
                    },
                    pullUpAction: function(){
                        setTimeout(function(){
                            //ajax请求
                            shan.ajax({
                                url: '/sz/ask/my_ask_list_async',
                                async : true,
                                data: {
                                    currentPage: vm.page,
                                    pageSize: vm.pageSize
                                },
                                success: function(json){
                                    if(typeof json != 'undefined' && json.SZ_HEAD.RESP_CODE == 'S0000'){
                                        $('#pullUp').hide();
                                        if(json.SZ_BODY.QUESTION_ORDER_D.length >= 1){
                                            var ajaxData = vm.formatData(json.SZ_BODY.QUESTION_ORDER_D);//获取数据
                                            vm.dataArr = vm.dataArr.concat(ajaxData);
                                            SCROLL.pullSuccess(vm,'-2rem');
                                            vm.page++;
                                        }else{
                                            vm.pullUpTipsShow = true;
                                            vm.pullUpTips = '—— 已经到底了 ——';
                                        }
                                    }else{
                                        pop.alert(json.SZ_HEAD.RESP_MSG);
                                    }
                                }
                            });
                        },100);
                    }
                }
            });
        }

    };

    var run = function () {
        f.init();
    };

    //初始化函数
    exports.run = run;
});

define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/fastclick');
    require('lib/vue/vue.min');
    require('lib/share/wxshare');

    var f = {
        init: function () {
            $(function () {
                FastClick.attach(document.body);
            });
            shan.tools.statisticsPing('250106');
            var bId = shan.tools.getUrlParam('bId');
            var card_count = 0;
            if(typeof g_count!= 'undefined' && g_count){
                card_count = g_count;
            }

            var vm = new Vue({
                el: '#app',
                data: {
                    count: card_count,      //剩余优惠券数量
                    phone: '',              //用户输入手机号
                    showBefore: true,       //领取成功前界面
                    showAfter: false,       //领取成功后界面
                    cardPrice: '',          //抵扣券价格
                    deadLine: '',           //有效日期
                    phoneNumber: ''         //部分显示的手机号
                },
                methods: {
                    getCard: function(){
                        shan.tools.statisticsPing('250107');
                        var phoneRep = /^1(3|4|5|7|8)\d{9}$/;
                        if(!phoneRep.test(this.phone)){
                            pop.alert('手机号输入有误，请重新输入');
                            shan.tools.statisticsPing('250113');
                            return false;
                        }
                        //请求问答券接口
                        shan.ajax({
                            url: '/sz/ask/get_share_ask_async',
                            data: {
                                phone: this.phone,
                                bId: bId
                            },
                            success: function(_json){
                                var resp_code = _json.SZ_HEAD.RESP_CODE;
                                if(resp_code == 'S0000'){
                                    if(_json.SZ_BODY.OBTAIN_RESULT){
                                        var resultData = _json.SZ_BODY.OBTAIN_RESULT;
                                        vm.showBefore = false;
                                        vm.showAfter = true;
                                        vm.cardPrice = Math.floor((resultData.assignAmt)/1000);
                                        vm.deadLine = resultData.expireTime.substring(0,10);
                                        vm.phoneNumber = resultData.memberPhone.slice(0,3) + '****' + resultData.memberPhone.slice(-4);
                                        shan.tools.statisticsPing('250108');
                                    }
                                }else if(resp_code == 'BC0002'){
                                    pop.alert('优惠券已过期');
                                    shan.tools.statisticsPing('250111');
                                }else if(resp_code == 'BC0003'){
                                    pop.alert('已经分享过了');
                                }else if(resp_code == 'BC0004'){
                                    pop.alert('已经领取过优惠券了');
                                    shan.tools.statisticsPing('250110');
                                }else if(resp_code == 'BC0005'){
                                    pop.alert('不能领取自己分享的优惠券');
                                    shan.tools.statisticsPing('250109');
                                }else if(resp_code == 'BC0006'){
                                    pop.alert('优惠券已领完');
                                    shan.tools.statisticsPing('250112');
                                }
                                else{
                                    pop.alert('系统繁忙，请稍后再试');
                                }
                            }
                        });
                    },
                    toFastAsk: function(){
                        window.location.href= '/sz/ask/ask_doctor';
                        shan.tools.statisticsPing('250114');
                    },
                    enterSz: function(){
                        shan.tools.statisticsPing('250115');
                    }
                }
            });

            //初始化分享浮层
            var controller = new wxController();
            controller.init(
                ['onMenuShareTimeline', 'onMenuShareAppMessage'],
                function () {
                    controller.configShareTimeline({
                        title: "问医生，不花钱！", // 分享标题
                        link: "https://"+window.location.host+"/sz/ask/share_ask?bId=" + bId, // 分享链接
                        imgUrl: "https://"+window.location.host+"/static/images/ask/fast-ask/share.png", // 分享图标
                        success: function () {
                            shan.tools.statisticsPing('250119');
                        },
                        cancel: function () {

                        }
                    });
                    controller.configShareAppMessage({
                        title: "问医生，不花钱！", // 分享标题
                        desc:  "一键领券，极速问诊。善诊精选公立医院全职医生为您答疑解惑~", // 分享描述
                        link: "https://"+window.location.host+"/sz/ask/share_ask?bId=" + bId, // 分享链接
                        imgUrl: "https://"+window.location.host+"/static/images/ask/fast-ask/share.png", // 分享图标
                        type: '', // 分享类型,music、video或link，不填默认为link
                        dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
                        success: function () {
                            shan.tools.statisticsPing('250120');
                        },
                        cancel: function () {
                        }
                    });
                }
            );

        }
    };




    var run = function () {
        f.init();
    };

    //初始化函数
    exports.run = run;
});
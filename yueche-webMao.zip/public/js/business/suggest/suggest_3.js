define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    require('lib/fastclick');
    require('business/suggest/suggest_share');

    var JS = (function () {
        var status = window.initStatus || '',
            dataSelectArr = $('li[data-select]');

        var $progress_title = $('#progress_title');
        return {
            init: function () {
                this.inits(); //初始化
                this.bindEvents(); //绑定事件
            },

            //初始化
            inits: function () {
                $(function () {
                    FastClick.attach(document.body);
                });
            },

            //绑定事件
            bindEvents: function () {
                var _self = this;
                //选项
                $('#choose-box').on('click','li',function (e) {
                    var index = parseInt($(this).index());
                    if($(this).hasClass('checked')){
                        $(this).removeClass('checked').attr('data-select','0');
                        return;
                    }
                    $(this).addClass('checked').attr('data-select','1');
                    switch (index){
                        case 0:
                            $progress_title.html('高血糖控制不佳会引起致命并发症。<span>糖化血红蛋</span>白水平可反映近期血糖变化，预测微血管并发症。');
                            break;
                        case 1:
                            $progress_title.html('可通过<span>血流变检测，血脂四项，心电图</span>及<span>眼底检查</span>诊断动脉硬化、冠心病、心肌梗塞、脑中风等。');
                            break;
                        default:
                            $progress_title.html('针对Ta的<span>心脑血管</span>状况，请选出所有符合的描述？');
                            break;
                    }
                });
                //下一步
                $('#next-btn').on('click',function (e) {
                    shan.tools.statisticsPing("31001004");
                    if(status.length != 6){
                        status = '000000000';
                    }else{
                        status += _self.getStatus();
                    }
                    window.location.href = '/sz/suggest/suggest_4?status='+ status;
                });
            },

            //获取status
            getStatus: function () {
                var result = [];
                for(var i=0,len=dataSelectArr.length;i<len;i++){
                    result[i] = dataSelectArr[i].getAttribute('data-select');
                }
                return result.join('');
            }
        }
    })();

    $(function () {
        JS.init();
    });


});
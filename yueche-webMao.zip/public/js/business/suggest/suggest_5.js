define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    require('lib/fastclick');
    require('business/suggest/suggest_share');

    var JS = (function () {
        var status = window.initStatus || '',
            dataSelectArr = $('li[data-select]');

        var $progress_title = $('#progress_title');
        return {
            init: function () {
                this.inits(); //初始化
                this.bindEvents(); //绑定事件
            },

            //初始化
            inits: function () {
                $(function () {
                    FastClick.attach(document.body);
                });
            },

            //绑定事件
            bindEvents: function () {
                var _self = this;
                //选项
                $('#choose-box').on('click','li',function (e) {
                    var index = parseInt($(this).index());
                    if($(this).hasClass('checked')){
                        $(this).removeClass('checked').attr('data-select','0');
                        return;
                    }
                    $(this).addClass('checked').attr('data-select','1');
                    switch (index){
                        case 0:
                            $progress_title.html('老年人暴露于致癌因素的时间较长，是癌症高发人群。应至少检查<span>癌胚抗原</span>及<span>甲胎蛋白</span>。');
                            break;
                        case 1:
                            $progress_title.html('不良生活习惯，易导致头颈癌、胃癌、肝癌、结肠癌等多种癌症，应至少检查<span>癌胚抗原</span>与<span>甲胎蛋白</span>。');
                            break;
                        case 2:
                            $progress_title.html('老年人缺乏运动，体质弱，免疫力下降，易受肿瘤细胞侵犯，应至少检查<span>癌胚抗原</span>与<span>甲胎蛋白</span>。');
                            break;
                        case 3:
                            $progress_title.html('若无糖尿病及慢性肝病，近期体重明显下降，往往与某些早期癌症相关。应进行<span>肿瘤因子全面筛查</span>。');
                            break;
                        case 4:
                            $progress_title.html('癌症往往具有家族遗传特性，建议进行<span>肿瘤因子全面筛查</span>。');
                            break;
                        default:
                            $progress_title.html('针对Ta的<span>肿瘤、癌症风险</span>状况，请选出所有符合的描述？');
                            break;
                    }
                });
                //下一步
                $('#next-btn').on('click',function (e) {
                    shan.tools.statisticsPing("31001006");
                    if(status.length != 12){
                        status = '00000000000000000';
                    }else{
                        status += _self.getStatus();
                    }
                    window.location.href = '/sz/suggest/suggest_6?status='+ status;
                });
            },

            //获取status
            getStatus: function () {
                var result = [];
                for(var i=0,len=dataSelectArr.length;i<len;i++){
                    result[i] = dataSelectArr[i].getAttribute('data-select');
                }
                return result.join('');
            }
        }
    })();

    $(function () {
        JS.init();
    });


});
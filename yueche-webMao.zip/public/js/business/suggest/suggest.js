define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    require('lib/fastclick');
    require('business/suggest/suggest_share');
    var f = {
        init: function () {
            $(function () {
                FastClick.attach(document.body);
                shan.tools.statisticsPing("310010000");
            });
        },
        bindEvent: function () {
            $('#start_buy').on('click',function (e) {
                shan.tools.statisticsPing("31001001");
            });
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    };

    //初始化函数
    exports.run = run;
});
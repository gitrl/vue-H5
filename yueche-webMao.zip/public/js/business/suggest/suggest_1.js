define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    require('lib/fastclick');
    require('business/suggest/suggest_share');

    var JS = (function () {
        var status = window.initStatus || '',
            dataSelectArr = $('li[data-select]');
        var $nextBtn = $('#next-btn');
        return {
            init: function () {
                this.inits(); //初始化
                this.bindEvents(); //绑定事件
            },

            //初始化
            inits: function () {
                var _self = this;
                $(function () {
                    FastClick.attach(document.body);
                    shan.tools.statisticsPing("310010001");
                });
                if($('#parents-box li').hasClass('checked')){
                    $nextBtn.removeClass('disabled');
                }
            },

            //绑定事件
            bindEvents: function () {
                var _self = this;
                //父母选项、是否体检选项
                $('#parents-box').add('#if-checked').on('click','li',function (e) {
                    $(this).addClass('checked').siblings().removeClass('checked');
                    $(this).attr('data-select','1').siblings().attr('data-select','0');
                    if($('#parents-box li').hasClass('checked')){
                        $nextBtn.removeClass('disabled');
                    }
                });
                //下一步
                $nextBtn.on('click',function (e) {
                    if($(this).hasClass('disabled')){
                        return;
                    }
                    shan.tools.statisticsPing("31001002");

                    status += _self.getStatus();
                    if(status.length!=4){
                        status = '0000';
                    }
                    window.location.href = '/sz/suggest/suggest_2?status='+ status;
                });
            },

            //获取status
            getStatus: function () {
                var result = [];
                for(var i=0,len=dataSelectArr.length;i<len;i++){
                    result[i] = dataSelectArr[i].getAttribute('data-select');
                }
                return result.join('');
            }
        }
    })();

    $(function () {
        JS.init();
    });


});
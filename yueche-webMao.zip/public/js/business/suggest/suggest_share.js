
define(function (require, exports, module) {
    require('lib/share/wxshare');

    (function () {
            var controller = new wxController();
            controller.init(
                ['onMenuShareTimeline','onMenuShareAppMessage'],
                function () {
                    controller.configShareTimeline({
                        title: "关爱父母健康从这里开始", // 分享标题
                        desc: "根据父母日常身体状况，为父母推荐合适的孝心套餐。不给疾病可乘之机。",
                        link: 'http://m.shanzhen.me/sz/suggest/suggest_1', // 分享链接
                        imgUrl: "http://m.shanzhen.me/static/images/suggest/suggest_share.png", // 分享图标
                        success: function () {
                            // 用户确认分享后执行的回调函数
                        },
                        cancel: function () {
                            // 用户取消分享后执行的回调函数
                        }
                    });
                    controller.configShareAppMessage({
                        title: "关爱父母健康从这里开始", // 分享标题
                        desc: "根据父母日常身体状况，为父母推荐合适的孝心套餐。不给疾病可乘之机", // 分享描述
                        link: 'http://m.shanzhen.me/sz/suggest/suggest_1', // 分享链接
                        imgUrl: "http://m.shanzhen.me/static/images/suggest/suggest_share.png", // 分享图标
                        type: '', // 分享类型,music、video或link，不填默认为link
                        dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
                        success: function () {
                            // 用户确认分享后执行的回调函数

                        },
                        cancel: function () {
                            // 用户取消分享后执行的回调函数

                        }
                    });
                });
        })();


});
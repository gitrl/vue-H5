define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    require('lib/fastclick');
    require('business/suggest/suggest_share');

    var JS = (function () {
        var status = window.initStatus || '',
            dataSelectArr = $('li[data-select]');
        return {
            init: function () {
                this.inits(); //初始化
                this.bindEvents(); //绑定事件
            },

            //初始化
            inits: function () {
                $(function () {
                    FastClick.attach(document.body);
                });
            },

            //绑定事件
            bindEvents: function () {
                var _self = this;
                //选项
                $('#choose-box').on('click','li',function (e) {
                    if($(this).hasClass('checked')){
                        $(this).removeClass('checked').attr('data-select','0');
                        return;
                    }
                    $(this).addClass('checked').attr('data-select','1');
                });
                //下一步
                $('#next-btn').on('click',function (e) {
                    if(status.length != 17){
                        status = '000000000000000000000';
                    }else{
                        status += _self.getStatus();
                    }
                    window.location.href = '/sz/suggest/suggest_result?status='+ status+'&DATA=31001007';
                });
            },

            //获取status
            getStatus: function () {
                var result = [];
                for(var i=0,len=dataSelectArr.length;i<len;i++){
                    result[i] = dataSelectArr[i].getAttribute('data-select');
                }
                return result.join('');
            }
        }
    })();

    $(function () {
        JS.init();
    });


});
define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/share/wxshare');
    require('lib/fastclick');
    require('lib/jquery.lazyload.min.js');
    var tag = shan.tools.getUrlParam("tag");

    function triggerImgLoad() {
        document.querySelector('.flex').scrollTop += 1;
        document.querySelector('.flex').scrollTop -= 1;
    }
    
    var f = {
        $comboOld: $('#comboOld'),
        $comboYoungster: $('#comboYoungster'),
        $comboPublic: $('#comboPublic'),
        $oldBtn: $('#oldBtn'),
        $youngBtn: $('#youngBtn'),
        $publicBtn: $('#publicBtn'),
        init: function () {
            var _self = this;
            
            $(function () {
                FastClick.attach(document.body);
                $('img.lazy').lazyload({
                    container: $(".flex"),
                    effect: 'fadeIn',
                    placeholder: "/static/images/avatar.jpg"
                });
            });
            shan.tools.statisticsPing("112");
        },
        bindEvent: function () {
            var _self = this;
            var $suggest_footer = $('#suggest-footer');
            //关闭推荐套餐浮标
            $('#footer-close').on('click',function(e){
                $suggest_footer.addClass('hidden');
                e.preventDefault();
            });
            $('#oldBtn').click(function () {
                $(this).addClass('item-on');
                _self.$youngBtn.removeClass('item-on');
                _self.$publicBtn.removeClass('item-on');

                _self.$comboOld.removeClass('hidden');
                _self.$comboYoungster.addClass('hidden');
                _self.$comboPublic.addClass('hidden');
                shan.tools.statisticsPing("54030");
                triggerImgLoad();

                //显示推荐套餐浮标
                if($suggest_footer.hasClass('hidden')){
                    $suggest_footer.removeClass('hidden');
                }
            });

            $('#youngBtn').click(function () {
                $(this).addClass('item-on');
                _self.$oldBtn.removeClass('item-on');
                _self.$publicBtn.removeClass('item-on');

                _self.$comboYoungster.removeClass('hidden');
                _self.$comboPublic.addClass('hidden');
                _self.$comboOld.addClass('hidden');

                shan.tools.statisticsPing("112");
                $('.c_pointYoung').addClass('hidden');
                triggerImgLoad();

                //关闭推荐套餐浮标
                if(!$suggest_footer.hasClass('hidden')){
                    $suggest_footer.addClass('hidden');
                }
            });

            $('#publicBtn').click(function () {
                $(this).addClass('item-on');
                _self.$oldBtn.removeClass('item-on');
                _self.$youngBtn.removeClass('item-on');

                _self.$comboPublic.removeClass('hidden');
                _self.$comboYoungster.addClass('hidden');
                _self.$comboOld.addClass('hidden');

                shan.tools.statisticsPing("113");
                $('.c_pointPublic').addClass('hidden');
                triggerImgLoad();

                //关闭推荐套餐浮标
                if(!$suggest_footer.hasClass('hidden')){
                    $suggest_footer.addClass('hidden');
                }
            });

            if (tag == 1) {
                $('#oldBtn').click();
            }
            else if (tag == 3) {
                $('#publicBtn').click();
            }
            else {
                $('#youngBtn').click();
            }

            //配置微信分享
            var controller = new wxController();
            controller.init(
                ['onMenuShareTimeline', 'onMenuShareAppMessage'],
                function () {
                    controller.configShareTimeline({
                        title: "每逢佳节倍思亲，送份体检表孝心", // 分享标题
                        link: window.location.href, // 分享链接
                        imgUrl: "http://"+window.location.host+"/static/images/redPacket/sharefree.png", // 分享图标
                        success: function () {
                        },
                        cancel: function () {
                        }
                    });
                    controller.configShareAppMessage({
                        title: "每逢佳节倍思亲，送份体检表孝心", // 分享标题
                        desc:  "送给爸妈的「免费体检」已经准备好，快来领取！", // 分享描述
                        link: window.location.href, // 分享链接
                        imgUrl: "http://"+window.location.host+"/static/images/redPacket/sharefree.png", // 分享图标
                        type: '', // 分享类型,music、video或link，不填默认为link
                        dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
                        success: function () {
                        },
                        cancel: function () {
                        }
                    });
                }
            );
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});

define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/fastclick');
    require('lib/vue/vue');
    require('lib/share/wxshare');
    
    var f = {
        init: function () {
            
            $(function () {
                FastClick.attach(document.body);
            });

            //配置微信分享
            var controller = new wxController();
            controller.init(
                ['onMenuShareTimeline', 'onMenuShareAppMessage'],
                function () {
                    controller.configShareTimeline({
                        title: options.title, // 分享标题
                        desc:  options.desc, // 分享描述
                        imgUrl: options.imgUrl, //分享图标
                        success: function () {
                            shan.tools.statisticsPing("311016");
                        },
                        cancel: function () {
                        }
                    });
                    controller.configShareAppMessage({
                        title: options.title, // 分享标题
                        desc:  options.desc, // 分享描述
                        imgUrl: options.imgUrl, //分享图标
                        type: '', // 分享类型,music、video或link，不填默认为link
                        dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
                        success: function () {
                            shan.tools.statisticsPing("311015");
                        },
                        cancel: function () {
                        }
                    });
                }
            );
        }
    };

    var vm = new Vue({
        el: '#vue',
        data: {//数据
            status: 1,
            productStatus: "",
            productButtonStatus: "",
            productButtonName: "查看套餐",
            gotoHref:{
                "1": "/sz/biz/order_demo",
                "2": "/sz/biz/detail_demo",
                "3": "/sz/report/demo?years=0",
            }
        },
        methods: {//方法
            goto: function(){
                window.location.href = this.gotoHref[this.status];
            },
            goto1: function(){
                window.location.href = "/sz/report/demo?years=1";
            },
            goto2: function(){
                window.location.href = "http://v1.rabbitpre.com/m/ij7IZf6mJ?lc=1&sui=UMDNqO6Z#from=share";
            }
        },
        created: function () {//创建实例后
            try {
                var status = shan.tools.getUrlParam("status");
                if(status != ""){
                    this.status = status;
                }
                if(this.status == 1){ //未预约
                    this.productStatus = "unreserved";
                    this.productButtonStatus = "yo-btn-reserve";
                    this.productButtonName = "查看套餐";
                }
                else if(this.status == 2){ //已预约
                    this.productStatus = "reserved";
                    this.productButtonStatus = "yo-btn-reserve";
                    this.productButtonName = "查看套餐";
                }
                else if(this.status == 3){ //报告已出
                    this.productStatus = "reported";
                    this.productButtonStatus = "yo-btn-report";
                    this.productButtonName = "查看报告";
                }

                
            }
            catch (e) {
                pop.alert('SORRY,订单错误！');
            }

        }
    });

    var run = function () {
        f.init();
    }

    //初始化函数
    exports.run = run;
});
define(function (require, exports, module) {
    var shan = require('lib/shan_base');
    require('lib/vue/vue.min');
    var status = shan.tools.getUrlParam("status");

    var f = {
        init : function(){
            if(status == 3){
                shan.tools.statisticsPing("370134");
            }
            else{
                shan.tools.statisticsPing("370135");
            }
            new Vue({
                el: '#content',
                data: {
                    status: shan.tools.getUrlParam("status"),
                    orderCode: shan.tools.getUrlParam("orderCode")
                },
                methods: {
                    toHref: function(){
                        window.location.href = g_href;
                    },
                    //返回主页
                    toIndex: function(){
                        window.location.href = "/sz/biz/index";
                    }
                }
            });
        }
    };

    var run = function () {
        f.init();
    };

    //初始化函数
    exports.run = run;
});
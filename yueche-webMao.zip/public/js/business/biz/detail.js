define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/fastclick');
    require('lib/vue/vue');
    require('lib/clipboard');

    var f = {
        init: function () {

            $(function () {
                FastClick.attach(document.body);
            });

            var clipboard = new Clipboard('#btn-clipboard');
            clipboard.on('success', function(e) {
                shan.tools.statisticsPing("370129");
                pop.message.show("复制成功");
            });

            clipboard.on('error', function(e) {
                pop.message.show("复制失败");
            });
        }
    };

    Vue.component("calendar", {
        template: "#calendar-template",
        data: function () {
            return {
                isShowDate: false,
                months: []
            };
        },
        methods: {
            getMonths: function (rowDateArr) {
                var now = new Date();
                var nowYear = now.getFullYear();
                var nowMonth = now.getMonth() + 1;
                var nowDay = now.getDate();

                var months = [];
                months.push(this.getDaysByMonth(nowYear, nowMonth));

                var curYear = nowYear, curMonth = nowMonth;

                do {
                    var next = this.nextMonth(curYear, curMonth, rowDateArr.END_DATE_D);

                    curYear = next.year;
                    curMonth = next.month;

                    months.push(this.getDaysByMonth(next.year, next.month));

                } while (!next.isEnd);

                for (var i = months.length - 1; i >= 0; i--) {
                    this.dateStatusClass(rowDateArr, months[i]);
                }

                return months;
            },
            isInList: function (date, list) {
                if (!list) return false;
                var date = date.split('-'),
                    dateStr = date[0] + '-' + this.preZero(date[1]) + '-' + this.preZero(date[2]);
                for (var i = list.length - 1; i >= 0; i--) {
                    if (list[i] == dateStr)
                        return true;
                }
                return false;
            },
            getDaysByMonth: function (year, month) {
                var firstDay = new Date(year, month - 1, 1).getDay(); //该月第一天是星期几
                //day = day == 0 ? 7 : day;
                var totalDay = this.getDaysInMonth(year, month);//该月总共有多少天
                var arr = [];
                var weekNum = Math.ceil((firstDay + totalDay) / 7);//该月有多少个星期
                for (var i = 0, length = weekNum * 7; i < length; i++) {
                    if (i >= firstDay + 1 && i <= (firstDay + totalDay)) { //给这个月内的元素加日期字符串
                        arr.push({
                            i: i - firstDay,
                            day: i - firstDay,
                            fullDate: year + '-' + this.preZero(month) + '-' + this.preZero(i - firstDay)
                        });
                    } else {
                        arr.push({i: i, day: ''});
                    }
                }
                arr.shift();
                return {
                    year: year,
                    month: month,
                    days: arr
                };
            },
            compareDate: function (date1, date2) {
                var arr1 = date1.split('-');
                var arr2 = date2.split('-');
                var date1Time = new Date(arr1[0], arr1[1] - 1, arr1[2]);
                var date2Time = new Date(arr2[0], arr2[1] - 1, arr2[2]);
                var diff = parseInt((date2Time - date1Time) / (24 * 60 * 60 * 1000));
                return diff;
            },
            getDaysInMonth: function (year, month) {
                month = Math.min(month, 12);
                month = Math.max(month, 1);
                var days = 0;
                var arr = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
                if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) {
                    arr[1] = 29; // 闰年2月29天
                }

                days = arr[month - 1];

                return days;
            },
            preZero: function (num) {
                num = parseInt(num);
                if (num < 10) {
                    return '0' + num;
                }
                else {
                    return num;
                }
            },
            nextMonth: function (year, month, endDate) {
                var newItem = {};
                newItem.month = (month % 12) + 1;
                newItem.year = year + parseInt(month / 12);

                var endDate = endDate.split('-');

                if (newItem.month == parseInt(endDate[1], 10) && newItem.year == parseInt(endDate[0], 10)) {
                    newItem.isEnd = true;
                } else {
                    newItem.isEnd = false;
                }
                return newItem;
            },
            dateStatusClass: function (rowDateArr, monthsArr) {
                var now = new Date();
                var nowYear = now.getFullYear();
                var nowMonth = now.getMonth() + 1;
                var nowDay = now.getDate();

                for (i in monthsArr.days) {
                    var item = (monthsArr.days)[i];
                    if (typeof item.fullDate == "undefined") {
                        continue;
                    }
                    item.status = 'free';
                    var compareStartDate = this.compareDate(rowDateArr.START_DATE_D, item.fullDate);
                    var compareEndDate = this.compareDate(rowDateArr.END_DATE_D, item.fullDate);
                    if (compareStartDate < 0) {
                        item.status = 'disabled';
                    }
                    if (compareEndDate > 0) {
                        item.status = 'disabled';
                    }
                    if (this.isInList(item.fullDate, rowDateArr.UNAVAILABLE_DATE_D)) {
                        item.status = 'disabled';
                    }
                    if (this.isInList(item.fullDate, rowDateArr.FULL_DATE_D)) {
                        item.status = 'full';
                    }
                    if (this.isInList(item.fullDate, rowDateArr.MANY_DATE_D)) {
                        item.status = 'busy';
                    }
                    if (this.isInList(item.fullDate, rowDateArr.UNAVAILABLE_DATE_D)) {
                        item.status = 'disabled';
                    }
                    var compareToday = this.compareDate(nowYear + '-' + nowMonth + '-' + nowDay, item.fullDate);
                    if (compareToday == 0) {
                        item.status = 'today';
                    }
                }
            },
            showMoreDate: function (institCode, orderCode) {
                //选择更多的触发函数
                var _self = this;
                shan.ajax({
                    url: "/sz/biz/get_work_date_async",
                    data: {
                        institCode: institCode,
                        orderCode: orderCode
                    },
                    success: function (json) {
                        if (json && json.SZ_HEAD && json.SZ_HEAD.RESP_CODE == "S0000") {
                            _self.initDate(json.SZ_BODY);
                        } else {
                            pop.alert("获取日期失败!");
                        }
                    }
                });
            },
            initDate: function (dateObject) {
                this.months = this.getMonths(dateObject);
                this.isShowDate = true;
            },
            chooseDate: function (_obj, _type) {
                if (!$(_obj.currentTarget).hasClass('disabled') && !$(_obj.currentTarget).hasClass('today')) {
                    var _data = {
                        curDate: '',
                        institCode: '',
                        institName: '',
                        institAddr: '',
                        status: '',
                        isHideSubmitBtn: true,
                        isHideCalendarInstitInfo: true
                    };
                    if (!$(_obj.currentTarget).hasClass('item-on')) {
                        $('.dateModule-date').find('li').removeClass('item-on');
                        $(_obj.currentTarget).addClass('item-on');
                        _data.curDate = $(_obj.currentTarget).attr('data-date');
                        _data.isHideSubmitBtn = false;
                        _data.isHideCalendarInstitInfo = false;
                        switch (_type) {
                            case 'free':
                                _data.status = 'OPEN';
                                break;
                            case 'busy':
                                _data.status = 'MANY';
                                break;
                            case 'full':
                                _data.status = 'FULL';
                                break;
                            default:
                                _data.status = 'FULL';
                                break;
                        }
                    }
                    else {
                        $(_obj.currentTarget).removeClass('item-on');
                        _data.isHideSubmitBtn = true;
                        _data.isHideCalendarInstitInfo = true;
                    }
                    this.$emit('choose-date', _data);

                }
            },
            closeCalendar: function () {
                $('.dateModule-date').find('li').removeClass('item-on');
                this.isShowDate = false;
                this.$emit('close-calendar');
            }
        }
    });

    var vm = new Vue({
        el: '#vue',
        data: {//数据
            curDate: '',
            reserveTime:'',
            isHideSubmitBtn: true,//是否隐藏提交按钮
            submitBtnClass: 'full',//提交按钮样式
            submitBtnWordsLib: {'OPEN': '确定', 'MANY': '确定（当天拥挤，建议改日）', 'FULL': '抱歉，当天已约满'},//提交按钮文案库
            submitBtnWords: '',//提交按钮文案
            isHideCalendarInstitInfo:true
        },
        methods: {//方法
            goback: function(){
                history.go(-1);
            },
            clipboard: function () {

            },
            changeReserveDate: function () {
                shan.tools.statisticsPing("370128");
                this.$refs.calendar.showMoreDate(this.institCode, this.orderCode);
            },
            submitOrder: function () {
              var _self=this;
                shan.ajax({
                   url:'/sz/biz/modify_appointment_time_async',
                    data:{
                        orderCode:this.orderCode,
                        newReserveDate:this.curDate,
                        oldReserveDate:this.reserveTime
                    },
                    success:function(json){
                        console.log(json);
                        if(typeof json !='undefined' && json.SZ_HEAD.RESP_CODE=='S0000'){
                            _self.reserveTime=_self.curDate;
                            _self.$refs.calendar.isShowDate=false;
                            _self.isHideSubmitBtn=true;
                            _self.isHideCalendarInstitInfo=true;
                            pop.message.show('体检时间已修改');
                        }
                        else{
                            pop.message.show('抱歉，体检时间修改失败。请联系客服！');
                        }
                    }
                });

            },
            chooseDate: function (data) {
                if (data.curDate != '') {
                    this.curDate = data.curDate;
                }
                if (data.institCode != '') {
                    this.curInstitCode = data.institCode;
                }
                if (data.institName != '') {
                    this.curInstitName = data.institName;
                }
                if (data.institAddr != '') {
                    this.curInstitAddr = data.institAddr;
                }
                this.isHideSubmitBtn = data.isHideSubmitBtn;
                this.isHideCalendarInstitInfo = data.isHideCalendarInstitInfo;
                switch (data.status) {
                    case 'OPEN':
                        this.submitBtnClass = 'free';
                        break;
                    case 'MANY':
                        this.submitBtnClass = 'busy';
                        break;
                    case 'FULL':
                        this.submitBtnClass = 'full';
                        break;
                    default:
                        this.submitBtnClass = 'full';
                        break;
                }
                this.submitBtnWords = this.submitBtnWordsLib[data.status];
            },
            closeCalendar: function () {
                this.curDate = '';
                this.isHideSubmitBtn = true;
                this.isHideCalendarInstitInfo = true;
            }

        },
        computed: {
            isShowModifyTime: function () {
                return this.canModifyTime == '1' ? true : false;
            },
            formatCurDate: function () {
                return new Date(this.curDate).Format('yyyy年MM月dd日');
            },
           reserveTimeStr:function(){
               return new Date(this.reserveTime).Format('yyyy年MM月dd日');
           }
        },
        created: function () {//创建实例后
            try {
                var obj = JSON.parse(g_data);
                this.examineeIcno = obj.examineeIcno;
                this.examineeName = obj.examineeName;
                this.examineePhone = obj.examineePhone;
                this.goodsName = obj.goodsName;
                this.institName = obj.institName;
                this.curDate = this.reserveTime = obj.reserveTime.split(' ')[0];
                this.pkgType = obj.pkgType;
                this.institAddr = obj.institAddr;
                this.canModifyTime = obj.canModifyTime;
                shan.tools.setDateFormat();
                this.institCode = obj.institCode;
                this.orderCode = obj.orderCode;
                
                this.examineeType = "身份证";
                if(obj.certificateType == 2){ // 证件类型(1.身份证 2.护照 3.台胞证 4.港澳通行证)
                    this.examineeType = "护照";
                }
                else if(obj.certificateType == 3){
                    this.examineeType = "台胞证";
                }
                else if(obj.certificateType == 4){
                    this.examineeType = "港澳通行证";
                }

                var additionItemArr = [];
                for (key in obj.PKG_GROUP_D) {
                    additionItemArr.push((obj.PKG_GROUP_D)[key].pkgGroupShowName);
                }
                this.additionItemText = additionItemArr.join(",");

                if (obj.pkgType == "M") {
                    this.pkgType = "男";
                }
                else if (obj.pkgType == "UW") {
                    this.pkgType = "未婚女";
                }
                else {
                    this.pkgType = "已婚女";
                }
            }
            catch (e) {
                pop.alert('SORRY,订单错误！');
            }

        }
    });

    var run = function () {
        f.init();
    }

    //初始化函数
    exports.run = run;
});
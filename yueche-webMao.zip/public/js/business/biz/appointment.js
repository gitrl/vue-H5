define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/fastclick');
    require('lib/vue/vue');
    require('lib/vue/vue-router.min.js');
    var IDValidator = require('lib/idvalidator');
    var GB2260 = require('lib/gb2260');
    var idValidator = new IDValidator(GB2260);
    Vue.use(VueRouter);

    var publicData = {
        goodsCode: '',
        goodsName: '',
        date: '',
        location: '',
        institution: '',
        institCode: '',
        orderCode: '',
        attr1: '',
        attr2: '',
        attr3: '',
        examineeName: '',
        examineeIcno: '',
        examineePhone: '',
        sexText: '',
        examineeType: '' //证件类型(1.身份证 2.护照 3.台胞证 4.港澳通行证)
    };

    var f = {
        init: function () {
            var _self = this;
            shan.tools.statisticsPing("370118");

            $(function () {
                FastClick.attach(document.body);
            });

            try {
                g_city = JSON.parse(g_city);
                g_order = JSON.parse(g_order.replace(/'/g, "\"").replace(/\s+/g, ""));
                if (typeof g_city != 'undefined' && g_city.SZ_HEAD.RESP_CODE == 'S0000' && typeof g_city.SZ_BODY.L2_CITY_D != 'undefined' && typeof g_city.SZ_BODY.L1_CITY_D != 'undefined' && g_city.SZ_BODY.L1_CITY_D.length > 0) {
                }
                else {
                    pop.alert('SORRY,订单错误！')
                }
                if (typeof g_order != 'undefined' && g_order.SZ_HEAD.RESP_CODE == 'S0000' && typeof g_order.SZ_BODY.ORDER_D != 'undefined' && typeof g_order.SZ_BODY.PRODUCT_D != 'undefined') {
                    publicData.examineeName = g_order.SZ_BODY.ORDER_D.examineeName;
                    publicData.examineePhone = g_order.SZ_BODY.ORDER_D.examineePhone;
                    publicData.examineeIcno = g_order.SZ_BODY.ORDER_D.examineeIcno;
                    publicData.examineeType = g_order.SZ_BODY.ORDER_D.certificateType;
                }
                else {
                    pop.alert('SORRY,订单初始化错误！')
                }
            }
            catch (e) {
                pop.alert('SORRY,订单错误！');
            }

            Vue.component('later-days', {
                template: '#laterDays',
                data: function () {
                    return {}
                },
                methods: {
                    chooseDate: function (_obj) {
                        var _data = {
                            curDate: '',
                            institCode: '',
                            institName: '',
                            institAddr: '',
                            status: '',
                            isHideSubmitBtn: true,
                            isHideCalendarInstitInfo:true
                        };
                        if (!$(_obj.currentTarget).hasClass('item-on')) {
                            $('.date-fast-box').find('.item').removeClass('item-on');
                            $(_obj.currentTarget).addClass('item-on');
                            _data.curDate = $(_obj.currentTarget).attr('data-date');
                            _data.institCode = this.institCode;
                            _data.institName = this.institName;
                            _data.institAddr = this.institAddr;
                            _data.status = this.status;
                            _data.isHideSubmitBtn = false;
                        }
                        else {
                            $(_obj.currentTarget).removeClass('item-on');
                            _data.isHideSubmitBtn = true;

                        }
                        this.$emit('choose-date', _data);

                    }
                },
                props: ['date', 'status', 'institCode', 'institName', 'institAddr'],
                computed: {
                    day: function () {
                        var _list = this.date.split('-');
                        return _list[1]+'/'+_list[2];
                    },
                    dateStatusStr: function () {
                        var _status;
                        switch (this.status) {
                            case 'OPEN':
                                _status = '可约';
                                break;
                            case 'MANY':
                                _status = '拥挤';
                                break;
                            case 'FULL':
                                _status = '约满';
                                break;
                            default:
                                _status = '可约';
                                break;
                        }
                        return _status;
                    },
                    dateStatusClass: function () {
                        var _status;
                        switch (this.status) {
                            case 'OPEN':
                                _status = 'item-free';
                                break;
                            case 'MANY':
                                _status = 'item-busy';
                                break;
                            case 'FULL':
                                _status = 'item-full';
                                break;
                            default:
                                _status = 'item-free';
                                break;
                        }
                        return _status;
                    }
                }
            });

            Vue.component("calendar", {
                template: "#calendar-template",
                data: function () {
                    return {
                        isShowDate: false,
                        months: []
                    };
                },
                methods: {
                    getMonths: function (rowDateArr) {
                        var now = new Date();
                        var nowYear = now.getFullYear();
                        var nowMonth = now.getMonth() + 1;
                        var nowDay = now.getDate();

                        var months = [];
                        months.push(this.getDaysByMonth(nowYear, nowMonth));

                        var curYear = nowYear, curMonth = nowMonth;

                        do {
                            var next = this.nextMonth(curYear, curMonth, rowDateArr.END_DATE_D);

                            curYear = next.year;
                            curMonth = next.month;

                            months.push(this.getDaysByMonth(next.year, next.month));

                        } while (!next.isEnd);

                        for (var i = months.length - 1; i >= 0; i--) {
                            this.dateStatusClass(rowDateArr, months[i]);
                        }

                        return months;
                    },
                    isInList: function (date, list) {
                        if (!list) return false;
                        var date = date.split('-'),
                            dateStr = date[0] + '-' + this.preZero(date[1]) + '-' + this.preZero(date[2]);
                        for (var i = list.length - 1; i >= 0; i--) {
                            if (list[i] == dateStr)
                                return true;
                        }
                        return false;
                    },
                    getDaysByMonth: function (year, month) {
                        var firstDay = new Date(year, month - 1, 1).getDay(); //该月第一天是星期几
                        //day = day == 0 ? 7 : day;
                        var totalDay = this.getDaysInMonth(year, month);//该月总共有多少天
                        var arr = [];
                        var weekNum = Math.ceil((firstDay + totalDay) / 7);//该月有多少个星期
                        for (var i = 0, length = weekNum * 7; i < length; i++) {
                            if (i >= firstDay + 1 && i <= (firstDay + totalDay)) { //给这个月内的元素加日期字符串
                                arr.push({
                                    i: i - firstDay,
                                    day: i - firstDay,
                                    fullDate: year + '-' + this.preZero(month) + '-' + this.preZero(i - firstDay)
                                });
                            } else {
                                arr.push({i: i, day: ''});
                            }
                        }
                        arr.shift();
                        return {
                            year: year,
                            month: month,
                            days: arr
                        };
                    },
                    compareDate: function (date1, date2) {
                        var arr1 = date1.split('-');
                        var arr2 = date2.split('-');
                        var date1Time = new Date(arr1[0], arr1[1] - 1, arr1[2]);
                        var date2Time = new Date(arr2[0], arr2[1] - 1, arr2[2]);
                        var diff = parseInt((date2Time - date1Time) / (24 * 60 * 60 * 1000));
                        return diff;
                    },
                    getDaysInMonth: function (year, month) {
                        month = Math.min(month, 12);
                        month = Math.max(month, 1);
                        var days = 0;
                        var arr = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
                        if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) {
                            arr[1] = 29; // 闰年2月29天
                        }

                        days = arr[month - 1];

                        return days;
                    },
                    preZero: function (num) {
                        num = parseInt(num);
                        if (num < 10) {
                            return '0' + num;
                        }
                        else {
                            return num;
                        }
                    },
                    nextMonth: function (year, month, endDate) {
                        var newItem = {};
                        newItem.month = (month % 12) + 1;
                        newItem.year = year + parseInt(month / 12);

                        var endDate = endDate.split('-');

                        if (newItem.month >= parseInt(endDate[1], 10) && newItem.year == parseInt(endDate[0], 10)) {
                            newItem.isEnd = true;
                        } else {
                            newItem.isEnd = false;
                        }
                        return newItem;
                    },
                    dateStatusClass: function (rowDateArr, monthsArr) {
                        var now = new Date();
                        var nowYear = now.getFullYear();
                        var nowMonth = now.getMonth() + 1;
                        var nowDay = now.getDate();

                        for (i in monthsArr.days) {
                            var item = (monthsArr.days)[i];
                            if (typeof item.fullDate == "undefined") {
                                continue;
                            }
                            item.status = 'free';
                            var compareStartDate = this.compareDate(rowDateArr.START_DATE_D, item.fullDate);
                            var compareEndDate = this.compareDate(rowDateArr.END_DATE_D, item.fullDate);
                            if (compareStartDate < 0) {
                                item.status = 'disabled';
                            }
                            if (compareEndDate > 0) {
                                item.status = 'disabled';
                            }
                            if (this.isInList(item.fullDate, rowDateArr.UNAVAILABLE_DATE_D)) {
                                item.status = 'disabled';
                            }
                            if (this.isInList(item.fullDate, rowDateArr.FULL_DATE_D)) {
                                item.status = 'full';
                            }
                            if (this.isInList(item.fullDate, rowDateArr.MANY_DATE_D)) {
                                item.status = 'busy';
                            }
                            if (this.isInList(item.fullDate, rowDateArr.UNAVAILABLE_DATE_D)) {
                                item.status = 'disabled';
                            }
                            var compareToday = this.compareDate(nowYear + '-' + nowMonth + '-' + nowDay, item.fullDate);
                            if (compareToday == 0) {
                                item.status = 'today';
                            }
                        }
                    },
                    showMoreDate: function (institCode, orderCode) {
                        //选择更多的触发函数
                        var _self = this;
                        shan.ajax({
                            url: "/sz/biz/get_work_date_async",
                            data: {
                                institCode: institCode,
                                orderCode: orderCode
                            },
                            success: function (json) {
                                if (json && json.SZ_HEAD && json.SZ_HEAD.RESP_CODE == "S0000") {
                                    _self.initDate(json.SZ_BODY);
                                } else {
                                    pop.alert("获取日期失败!");
                                }
                            }
                        });
                    },
                    initDate: function (dateObject) {
                        this.months = this.getMonths(dateObject);
                        this.isShowDate = true;
                    },
                    chooseDate: function (_obj, _type) {
                        if (!$(_obj.currentTarget).hasClass('disabled') && !$(_obj.currentTarget).hasClass('today')) {
                            var _data = {
                                curDate: '',
                                institCode: '',
                                institName: '',
                                institAddr: '',
                                status: '',
                                isHideSubmitBtn: true,
                                isHideCalendarInstitInfo:true
                            };
                            if (!$(_obj.currentTarget).hasClass('item-on')) {
                                $('.dateModule-date').find('li').removeClass('item-on');
                                $(_obj.currentTarget).addClass('item-on');
                                _data.curDate = $(_obj.currentTarget).attr('data-date');
                                _data.isHideSubmitBtn = false;
                                _data.isHideCalendarInstitInfo=false;
                                switch (_type) {
                                    case 'free':
                                        _data.status = 'OPEN';
                                        break;
                                    case 'busy':
                                        _data.status = 'MANY';
                                        break;
                                    case 'full':
                                        _data.status = 'FULL';
                                        break;
                                    default:
                                        _data.status = 'FULL';
                                        break;
                                }
                            }
                            else {
                                $(_obj.currentTarget).removeClass('item-on');
                                _data.isHideSubmitBtn = true;
                                _data.isHideCalendarInstitInfo=true;
                            }
                            this.$emit('choose-date', _data);

                        }
                    },
                    closeCalendar: function () {
                        $('.dateModule-date').find('li').removeClass('item-on');
                        this.isShowDate = false;
                        this.$emit('close-calendar');
                    }
                }
            });

            const vm = {
                template: '#appointment',
                data: function () {
                    return {//数据
                        //isFirstFormatRegion:true,//是否初始化机构列表
                        isHideRegionDialog: false,//是否隐藏城市选择列表
                        isNotChosedRegion: true,//未选择省市区域
                        L1_CITY_D: g_city.SZ_BODY.L1_CITY_D,//一级城市数据
                        L2_CITY_D: g_city.SZ_BODY.L2_CITY_D,//二级城市数据
                        waitChoose_L2_CITY_D: [],//已选一级城市对应可选的二级城市列表
                        institList: [],//机构列表
                        orderCode: g_order.SZ_BODY.ORDER_D.orderCode,//订单code
                        goodsCode: g_order.SZ_BODY.ORDER_D.goodsCode,//商品code
                        goodsName: g_order.SZ_BODY.ORDER_D.goodsName,//商品名字
                        activityProd: g_order.SZ_BODY.PRODUCT_D.activityProd,//商品类型
                        cur_L1_CITY_D: '',//已选中一级城市
                        cur_L2_CITY_D: [],//已选中二级城市
                        cur_L2_CITY_D_Name: [],//已选中二级城市中文名字
                        curDate: '',//选定日期
                        curInstitCode: '',//选定机构code
                        curInstitName: '',//选定机构名字
                        curInstitAddr: '',//选定机构地址
                        isHideSubmitBtn: true,//是否隐藏提交按钮
                        submitBtnClass: 'full',//提交按钮样式
                        submitBtnWordsLib: {'OPEN': '确定', 'MANY': '当天拥挤，继续预约', 'FULL': '抱歉，当天已约满'},//提交按钮文案库
                        submitBtnWords: '',//提交按钮文案
                        isSending: false,//提交预约组件的api请求标识
                        isHideCalendarInstitInfo: true,//是否隐藏日历控件机构信息
                    }
                },
                computed: {//计算属性
                    showRegionName: function () {
                        return this.cur_L2_CITY_D_Name.join('/');
                    },
                    formatCurDate: function () {
                        var _arr = this.curDate.split('-');
                        return _arr[0] + '年' + _arr[1] + '月' + _arr[2] + '日';
                    }
                },
                methods: {//方法
                    chooseIRegion: function (_obj) {
                        if (!$(_obj.currentTarget).hasClass('item-on')) {
                            this.waitChoose_L2_CITY_D = this.L2_CITY_D[$(_obj.currentTarget).attr('data-regioncode')];
                            $(_obj.currentTarget).addClass('item-on').siblings().removeClass('item-on');
                            $('#regionRight').children('.item').removeClass('item-on');
                            this.cur_L2_CITY_D = [];
                            this.cur_L2_CITY_D_Name = [];
                            this.isNotChosedRegion = true;
                        }
                    },
                    chooseIIRegion: function (_obj) {
                        if ($(_obj.currentTarget).hasClass('item-on')) {
                            $(_obj.currentTarget).removeClass('item-on');
                        }
                        else {
                            $(_obj.currentTarget).addClass('item-on');
                            if ($(_obj.currentTarget).attr('data-style') != '1') {
                                $(_obj.currentTarget).siblings().removeClass('item-on');
                            }
                        }
                        this.computeIIRegion();
                    },
                    computeIIRegion: function () {
                        var _self = this;
                        _self.cur_L2_CITY_D = [];
                        _self.cur_L2_CITY_D_Name = [];
                        $('#regionRight').children('.item').each(function () {
                            if ($(this).hasClass('item-on')) {
                                _self.cur_L2_CITY_D.push($(this).attr('data-regioncode'));
                                _self.cur_L2_CITY_D_Name.push($(this).attr('data-name'));
                            }
                        });
                        if (_self.cur_L2_CITY_D.length > 0) {
                            _self.isNotChosedRegion = false;
                        }
                        else {
                            _self.isNotChosedRegion = true;
                        }
                    },
                    requireInstit: function (_obj) {
                        shan.tools.statisticsPing("370120");
                        var _self = this;
                        if (!$(_obj.currentTarget).hasClass('disabled')) {
                            shan.ajax({
                                url: '/sz/biz/get_instits_async',
                                data: {
                                    orderCode: _self.orderCode,
                                    regionCode: _self.cur_L2_CITY_D.join(',')
                                },
                                success: function (json) {
                                    if (typeof json != 'undefined' && json.SZ_HEAD.RESP_CODE == 'S0000' && typeof json.SZ_BODY.INSTIT_D != 'undefined' && json.SZ_BODY.INSTIT_D.length > 0) {
                                        _self.institList = json.SZ_BODY.INSTIT_D;
                                        //$('.organ-date').removeClass('show');
                                        $('.date-fast-box').children('.item').removeClass('item-on');
                                        _self.isHideRegionDialog = true;
                                    }
                                    else {
                                        pop.alert('请重新选择城市或地区！')
                                    }
                                }
                            });
                        }
                    },
                    chooseDate: function (data) {
                        if (data.curDate != '') {
                            this.curDate = data.curDate;
                        }
                        if (data.institCode != '') {
                            this.curInstitCode = data.institCode;
                        }
                        if (data.institName != '') {
                            this.curInstitName = data.institName;
                        }
                        if (data.institAddr != '') {
                            this.curInstitAddr = data.institAddr;
                        }
                        this.isHideSubmitBtn = data.isHideSubmitBtn;
                        this.isHideCalendarInstitInfo=data.isHideCalendarInstitInfo;
                        switch (data.status) {
                            case 'OPEN':
                                this.submitBtnClass = 'free';
                                break;
                            case 'MANY':
                                this.submitBtnClass = 'busy';
                                break;
                            case 'FULL':
                                this.submitBtnClass = 'full';
                                break;
                            default:
                                this.submitBtnClass = 'full';
                                break;
                        }
                        this.submitBtnWords = this.submitBtnWordsLib[data.status];
                    },
                    againChooseRegion: function () {
                        this.isHideRegionDialog = false;
                        this.isHideSubmitBtn = true;
                    },
                    showLaterDays: function (_obj) {
                        if ($(_obj.currentTarget).parent().hasClass('show')) {
                            $(_obj.currentTarget).parent().removeClass('show');
                        }
                        else {
                            $(_obj.currentTarget).parent().addClass('show');
                        }
                    },
                    submitOrder: function () {
                        var _self = this;
                        if (_self.submitBtnClass != 'full') {
                            shan.ajax({
                                url: '/sz/biz/appointment_save_async',
                                data: {
                                    goodsCode: _self.goodsCode,
                                    goodsName: _self.goodsName,
                                    date: _self.curDate,
                                    location: _self.curInstitAddr,
                                    institution: _self.curInstitName,
                                    institCode: _self.curInstitCode,
                                    orderCode: _self.orderCode
                                },
                                success: function (json) {
                                    if (typeof json != 'undefined' && json.SZ_HEAD.RESP_CODE == 'S0000') {
                                        //window.location.href = "/sz/biz/appointment_commit";
                                        publicData.goodsCode = _self.goodsCode;
                                        publicData.goodsName = _self.goodsName;
                                        publicData.date = _self.curDate;
                                        publicData.location = _self.curInstitAddr;
                                        publicData.institution = _self.curInstitName;
                                        publicData.institCode = _self.curInstitCode;
                                        publicData.orderCode = _self.orderCode;
                                        router.push({path: '/commit'});
                                    }
                                    else {
                                        pop.alert(json.SZ_HEAD.RESP_MSG)
                                    }
                                }
                            })
                        }
                    },
                    moreDate: function (_obj) {
                        $('.date-fast-box').find('.item').removeClass('item-on');
                        this.isHideSubmitBtn = true;
                        this.curInstitCode = $(_obj.currentTarget).attr('data-institcode');
                        this.curInstitName = $(_obj.currentTarget).attr('data-institname');
                        this.curInstitAddr = $(_obj.currentTarget).attr('data-institaddr');
                        this.$refs.calendar.showMoreDate(this.curInstitCode, this.orderCode);
                        shan.tools.statisticsPing("370123");
                    },
                    selDate: function () {

                    },
                    closeCalendar: function () {
                        this.curDate = '';
                        this.isHideSubmitBtn = true;
                        this.isHideCalendarInstitInfo=true;
                    }

                },
                created: function () {//创建实例后
                },
                mounted: function () {//创建dom后
                    $($('#regionLeft').children('.item')[0]).click();
                },
                activated: function () {
                    $('html').removeClass('bgfff');
                }
            };

            const commit = {
                template: '#commit',
                data: function () {
                    return {//数据
                        institCode: "", //机构ID
                        reserveTime: "", //预约时间
                        pkgType: "", //性别
                        examineeName: "", //体检人姓名
                        examineeIcno: "", //体检人身份证
                        examineePhone: "", //体检人电话号码
                        testVersion: "", //上报字段
                        goodsName: "", //商品名称
                        location: "", //机构地址
                        institution: "", //机构名称
                        attr1: "", //特性1
                        attr2: "", //特性2
                        attr3: "", //特性3
                        orderCode: "", //订单号
                        goodsCode: "", //商品ID
                        isShowSex: false, //选择性别
                        hasM: false,
                        hasUW: false,
                        hasMW: false,
                        selM: false,
                        selUW: false,
                        selMW: false,
                        sexText: "",
                        isSending: false,//提交预约组件的api请求标识
                        date: '',
                        isShowType: false, //选择证件
                        typeText: "身份证",
                        zjType: "1",
                        examineeDate: "",
                        demoExamineePhone: [],
                        hasBirthDay: false
                    }
                },
                created: function () {//创建实例后
                    //this.initPage();
                    try{
                        this.demoExamineePhone = JSON.parse(g_demoPhone);
                    }
                    catch(e){}
                    
                },
                methods: {
                    selSex: function (sex) {
                        if (this.isShowSex) {
                            if (sex == "M") {
                                this.pkgType = sex;
                                this.sexText = "男";
                            }
                            else if (sex == "UW") {
                                this.pkgType = sex;
                                this.sexText = "未婚女";
                            }
                            else if (sex == "MW") {
                                this.pkgType = sex;
                                this.sexText = "已婚女";
                            }
                            this.isShowSex = false;
                            $('html').removeClass('scrollFix');
                        }
                        else {
                            this.isShowSex = true;
                            $('html').addClass('scrollFix');
                        }
                    },
                    selType: function (type) {
                        if (this.isShowType) {
                            
                            if (type == "1") {
                                this.typeText = "身份证";
                                this.hasBirthDay = false;
                                this.zjType = type;
                            }
                            else if (type == "2") {
                                this.typeText = "护照";
                                this.hasBirthDay = true;
                                this.zjType = type;
                            }
                            else if (type == "3") {
                                this.typeText = "台胞证";
                                this.hasBirthDay = true;
                                this.zjType = type;
                            }
                            else if (type == "4") {
                                this.typeText = "港澳通行证";
                                this.hasBirthDay = true;
                                this.zjType = type;
                            }
                            this.isShowType = false;
                            $('html').removeClass('scrollFix');
                        }
                        else {
                            this.isShowType = true;
                            $('html').addClass('scrollFix');
                        }
                    },
                    submitOrder: function () {
                        shan.tools.statisticsPing("370126");
                        var _self = this;
                        if (!this.checkOrder()) {
                            return;
                        }
                        //demo演示用
                        for(i in this.demoExamineePhone){
                            if (this.demoExamineePhone[i] == this.examineePhone) {
                                pop.alert("预约成功", function () {
                                    window.location.href = "/sz/biz/index";
                                });
                                return;
                            }
                        }
                        
                        this.isSending = true;
                        shan.ajax({
                            url: "/sz/biz/appointment_commit_async",
                            data: {
                                goodsCode: this.goodsCode,
                                institCode: this.institCode,
                                reserveTime: this.reserveTime,
                                pkgType: this.pkgType,
                                examineeName: this.examineeName,
                                examineeIcno: this.examineeIcno,
                                examineePhone: this.examineePhone,
                                testVersion: this.testVersion,
                                orderCode: this.orderCode,
                                certificateType: this.zjType,
                                birthDay: this.examineeDate
                            },
                            success: function (json) {
                                _self.isSending = false;
                                if (json && json.SZ_HEAD && json.SZ_HEAD.RESP_CODE == "S0000") {
                                    pop.alert("预约成功", function () {
                                        if (json.SZ_BODY.JUMP_URL) {
                                            window.location.href = json.SZ_BODY.JUMP_URL;
                                            shan.tools.statisticsPing('370141');
                                        } else {
                                            window.location.href = "/sz/biz/index";
                                            shan.tools.statisticsPing('370140');
                                        }
                                    });
                                } else {
                                    pop.alert("预约失败,"+json.SZ_HEAD.RESP_MSG);
                                }
                            }
                        });
                    },
                    checkOrder: function () {
                        if (this.checkName() 
                            && this.checkPhone() 
                            && this.checkGender() 
                            && this.checkCode() && this.pkgType != "" 
                            && this.checkBirthday()) {
                            return true;
                        }
                        else {
                            return false;
                        }
                    },
                    checkName: function () {
                        if (this.examineeName != '' && this.examineeName != undefined) {
                            return true;
                        }
                        else {
                            pop.alert('请输入体检人姓名');
                            return false;
                        }
                    },
                    checkCode: function () {

                        if (this.examineeIcno != '' && this.examineeIcno != undefined) {
                            if(this.zjType != '1'){
                                return true;
                            }
                            var _code = this.examineeIcno,
                                _gender = this.pkgType,
                                _codeInfo = false,
                                _age,
                                sex;
                            if (!idValidator.isValid(_code)) {
                                pop.alert('身份证号不正确');
                                return false;
                            }
                            else {
                                if (_gender == "") {
                                    pop.alert('请点击选择性别!');
                                    return false;
                                }

                                if (_gender == 'MW' || _gender == 'UW') {
                                    sex = 0;
                                }
                                else {
                                    sex = 1;
                                }
                                _codeInfo = idValidator.getInfo(_code);
                                if (!_codeInfo || typeof _codeInfo.sex == "undefined" || typeof _codeInfo.birth == "undefined") {
                                    pop.alert('请输入合法的身份证号');
                                    return false;
                                }
                                if (_codeInfo.sex != sex) {
                                    pop.alert('体检套餐性别与身份证号不符');
                                    return false;
                                }
                                return true;
                            }
                        }
                        else {
                            pop.alert('请输入体检人证件号码');
                            return false;
                        }
                    },
                    checkGender: function () {
                        if (this.pkgType != '' && this.pkgType != undefined) {
                            return true;
                        }
                        else {
                            pop.alert('请选择体检人性别');
                            return false;
                        }
                    },
                    checkPhone: function () {
                        var _val = this.examineePhone;
                        if (/^1\d{10}/.test(_val)) {
                            return true;
                        }
                        else {
                            pop.alert('请输入正确的手机号码');
                            return false;
                        }
                    },
                    checkBirthday: function(){
                        if(this.hasBirthDay && /^1|2\d{3}-\d{1}|\d{2}-\d{1}|\d{2}/.test(this.date)){
                            pop.alert('请按格式输入出生日期,如："2017-6-15"');
                            return false;
                        }
                        else{
                            return true;
                        }
                    },
                    initPage: function () {
                        var _self = this;
                        try {
                            if (publicData.goodsCode != '') {
                                _self.goodsCode = publicData.goodsCode;
                                _self.institCode = publicData.institCode;
                                _self.reserveTime = publicData.date;
                                _self.goodsName = publicData.goodsName;
                                _self.location = publicData.location;
                                _self.institution = publicData.institution;
                                _self.attr1 = publicData.attr1;
                                _self.attr2 = publicData.attr2;
                                _self.attr3 = publicData.attr3;
                                _self.orderCode = publicData.orderCode;
                                _self.examineeName = publicData.examineeName;
                                _self.examineeIcno = publicData.examineeIcno;
                                _self.examineePhone = publicData.examineePhone;
                                _self.sexText = publicData.sexText;
                                shan.ajax({
                                    data: {
                                        url: '/openpreset/genders.htm',
                                        institCode: _self.institCode,
                                        orderCode: _self.orderCode
                                    },
                                    success: function (json) {
                                        if (typeof json != 'undefined' && json.SZ_HEAD.RESP_CODE == 'S0000') {
                                            for (i in json.SZ_BODY.SEX_D) {
                                                var key = json.SZ_BODY.SEX_D[i];
                                                if (key == "M") {
                                                    _self.hasM = true;
                                                }
                                                else if (key == "UW") {
                                                    _self.hasUW = true;
                                                }
                                                else if (key == "MW") {
                                                    _self.hasMW = true;
                                                }
                                            }
                                            var _temp = _self.reserveTime.split('-'),
                                                year = _temp[0],
                                                month = _temp[1],
                                                day = _temp[2],
                                                weekList = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'],
                                                i = new Date(_self.reserveTime).getDay();
                                            _self.date = year + '年' + month + '月' + day + '日' + ' ' + weekList[i];
                                        }
                                        else {
                                            //pop.alert("抱歉，系统出错，请联系客服400-676-2960");
                                            router.push({path: '/'});
                                        }
                                        $('html').addClass('bgfff');
                                    }
                                })
                            }
                            else {
                                shan.ajax({
                                    url: '/sz/biz/get_appointment_commit_async',
                                    data: {},
                                    success: function (json) {
                                        if (typeof json != 'undefined') {
                                            _self.goodsCode = json.goodsCode;
                                            _self.institCode = json.institCode;
                                            _self.reserveTime = json.date;
                                            _self.goodsName = json.goodsName;
                                            _self.location = json.location;
                                            _self.institution = json.institution;
                                            _self.attr1 = json.attr1;
                                            _self.attr2 = json.attr2;
                                            _self.attr3 = json.attr3;
                                            _self.orderCode = json.orderCode;
                                            _self.examineeName = json.examineeName;
                                            _self.examineeIcno = json.examineeIcno;
                                            _self.examineePhone = json.examineePhone;
                                            _self.sexText = '';
                                            shan.ajax({
                                                data: {
                                                    url: '/openpreset/genders.htm',
                                                    institCode: _self.institCode,
                                                    orderCode: _self.orderCode
                                                },
                                                success: function (json) {
                                                    if (typeof json != 'undefined' && json.SZ_HEAD.RESP_CODE == 'S0000') {
                                                        for (i in json.SZ_BODY.SEX_D) {
                                                            var key = json.SZ_BODY.SEX_D[i];
                                                            if (key == "M") {
                                                                _self.hasM = true;
                                                            }
                                                            else if (key == "UW") {
                                                                _self.hasUW = true;
                                                            }
                                                            else if (key == "MW") {
                                                                _self.hasMW = true;
                                                            }
                                                        }
                                                        var _temp = _self.reserveTime.split('-'),
                                                            year = _temp[0],
                                                            month = _temp[1],
                                                            day = _temp[2],
                                                            weekList = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'],
                                                            i = new Date(_self.reserveTime).getDay();
                                                        _self.date = year + '年' + month + '月' + day + '日' + ' ' + weekList[i];
                                                    }
                                                    else {
                                                        pop.alert("抱歉，系统出错，请联系客服400-676-2960");
                                                        //router.push({path:'/'});
                                                    }
                                                    $('html').addClass('bgfff');
                                                }
                                            })
                                        }
                                    }
                                })
                            }

                        }
                        catch (e) {
                            pop.alert('SORRY,订单错误！', function () {
                                history.go(-1);
                            });
                        }
                    }
                },
                activated: function () {
                    this.initPage();
                }

            };

            const routes = [
                {path: '/', component: vm},
                {path: '/commit', component: commit}
            ];

            const router = new VueRouter({
                routes: routes
            });

            const app = new Vue({
                el: '#app',
                router: router
            });

        }
    };


    var run = function () {
        f.init();
    }

    //初始化函数
    exports.run = run;
});
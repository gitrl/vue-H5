define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/fastclick');
    require('lib/vue/vue');

    var f = {
        init: function () {
            
            $(function () {
                FastClick.attach(document.body);
            });
        }
    };

    var vm = new Vue({
        el: '#vue',
        data: {//数据
            
        },
        methods: {//方法
            goback: function(){
                window.location.href = "/sz/biz/index?status=3";
            }
        },
        created: function () {//创建实例后
            try {
                

                
            }
            catch (e) {
                pop.alert('SORRY,订单错误！');
            }

        }
    });

    var run = function () {
        f.init();
    }

    //初始化函数
    exports.run = run;
});
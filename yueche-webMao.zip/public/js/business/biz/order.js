define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/fastclick');
    require('lib/vue/vue');
    require('lib/vue/vue-router.min.js');
    require('lib/iscroll');
    Vue.use(VueRouter);
    var publicData = {
        requireGoodsAddPkg: [],
        optionsGoodsAddPkg: [],
        goodsAddPkg: [],
        curPrice: 0,
        isNormal: false,
        curFirstPrice: 0,
        curSecondPrice: 0
    };

    var f = {
        init: function () {
            var _self = this;
            shan.tools.statisticsPing("370106");

            $(function () {
                FastClick.attach(document.body);
            });
            try {
                g_data = JSON.parse(g_data);
                if (typeof g_data.GOODS_D.requiredGoodsAddList == 'undefined') {
                    g_data.GOODS_D.requiredGoodsAddList = [];
                }
                if (typeof g_data.GOODS_D.optionalGoodsAddList == 'undefined') {
                    g_data.GOODS_D.optionalGoodsAddList = [];
                }
                if (typeof g_data.GOODS_D.goodsAmt == 'undefined' || g_data.GOODS_D.goodsAmt < 0) {
                    g_data.GOODS_D.goodsAmt = 0;
                }
            }
            catch (e) {
                pop.message.show('SORRY,订单错误！');
            }

            const first = {
                template: '#first',
                data: function () {
                    return {//数据
                        orderCode: '',
                        goodsCode: g_data.GOODS_D.goodsCode,
                        goodsName: g_data.GOODS_D.goodsName,
                        goodsItemTotal: g_data.GOODS_D.pkgItemNum,
                        goodsFeatureList: g_data.GOODS_D.goodsFeatureList,
                        requiredGoodsAddList: g_data.GOODS_D.requiredGoodsAddList,
                        requiredGoodsAddTempData: [],
                        curPrice: g_data.GOODS_D.goodsAmt,
                    }
                },
                computed: {//计算属性
                    isFree: function () {
                        return this.curPrice == 0 ? true : false;
                    },
                    curPriceStr: function () {
                        return (this.curPrice / 1000).toFixed(2);
                    }
                },
                methods: {//方法
                    clickAddPkg: function (_obj, _parentIndex, _index, _equal, isSwitchBtn) {
                        if (isSwitchBtn) {
                            shan.tools.statisticsPing("370108");
                            var $checkbox = $(_obj.currentTarget).find('.checkbox');
                            var $parent = $(_obj.currentTarget).parents('.product-more-items');
                            if ($checkbox.prop('checked')) {
                                $checkbox.prop('checked', false);
                                $parent.removeClass('active');
                                this.requiredGoodsAddTempData[_parentIndex].hasChoosedItemNum--;
                            }
                            else {
                                if (this.requiredGoodsAddTempData[_parentIndex].hasChoosedItemNum < this.requiredGoodsAddTempData[_parentIndex].choosedItemNum) {
                                    $checkbox.prop('checked', true);
                                    $parent.addClass('active');
                                    this.requiredGoodsAddTempData[_parentIndex].hasChoosedItemNum++;
                                } else {
                                    pop.message.show('本加项包只能选择' + _equal + '项');
                                }
                            }
                        } else {
                            var $checkbox = $(_obj.currentTarget).parent('.product-more-items').find('.checkbox');
                            var $parent = $(_obj.currentTarget).parent('.product-more-items');
                            if (!$checkbox.prop('checked')) {
                                if (this.requiredGoodsAddTempData[_parentIndex].hasChoosedItemNum < this.requiredGoodsAddTempData[_parentIndex].choosedItemNum) {
                                    $checkbox.prop('checked', true);
                                    $parent.addClass('active');
                                    this.requiredGoodsAddTempData[_parentIndex].hasChoosedItemNum++;
                                } else {
                                    pop.message.show('本加项包只能选择' + _equal + '项');
                                }
                            }
                        }
                    },
                    goSecond: function () {
                        if (this.isHasChoosedRequireGoodsAdd()) {
                            this.countRequireGoodsAdd();
                            publicData.curFirstPrice = this.curPrice;
                            if (g_data.GOODS_D.optionalGoodsAddList.length > 0) {
                                router.push({path: '/add'});
                            }
                            else {
                                router.push({path: '/affirm'});
                            }
                        } else {
                            pop.message.show('请按规则选择加项包');
                        }
                    },
                    countRequireGoodsAdd: function () {
                        publicData.requireGoodsAddPkg = [];
                        $('.checkbox').each(function () {
                            if ($(this).prop('checked')) {
                                publicData.requireGoodsAddPkg.push($(this).attr('data-id'));
                            }
                        });
                    },
                    isHasChoosedRequireGoodsAdd: function () {
                        var _bool = true;
                        for (var i = 0; i < this.requiredGoodsAddTempData.length; i++) {
                            if (this.requiredGoodsAddTempData[i].hasChoosedItemNum != this.requiredGoodsAddTempData[i].choosedItemNum) {
                                _bool = false;
                                break;
                            }
                        }
                        return _bool;
                    },
                    watchDetail: function () {
                        window.location.href = '/sz/biz/goods_detail/goodsCode/' + this.goodsCode;
                    }

                },
                created: function () {//创建实例后
                    for (var i = 0; i < this.requiredGoodsAddList.length; i++) {
                        this.requiredGoodsAddTempData[i] = {};
                        this.requiredGoodsAddTempData[i].choosedItemNum = this.requiredGoodsAddList[i].choosedItemNum;
                        this.requiredGoodsAddTempData[i].hasChoosedItemNum = 0;
                    }
                },
                mounted: function () {//创建dom后

                },
                activated: function () {
                    publicData.isNormal = true;
                }
            };
            const second = {
                template: '#second',
                data: function () {
                    return {//数据
                        optionalGoodsAddList: g_data.GOODS_D.optionalGoodsAddList[0],
                        choosedItemNum: g_data.GOODS_D.optionalGoodsAddList[0].choosedItemNum,
                        optionalGoodsAddTempData: [],
                        curPrice: 0,
                    }
                },
                computed: {//计算属性
                    isFree: function () {
                        return this.curPrice == 0 ? true : false;
                    },
                    curPriceStr: function () {
                        return (this.curPrice / 1000).toFixed(2);
                    }

                },
                methods: {//方法
                    clickAddPkg: function (_obj, _parentIndex, _index, _equal, isSwitchBtn) {
                        if (isSwitchBtn) {
                            var $checkbox = $(_obj.currentTarget).find('.checkbox');
                            var $parent = $(_obj.currentTarget).parents('.product-more-items');
                            if ($checkbox.prop('checked')) {
                                $checkbox.prop('checked', false);
                                this.curPrice -= parseInt(parseFloat($checkbox.attr('data-price')) * 1000);
                                $parent.removeClass('active');
                                this.optionalGoodsAddTempData[_parentIndex].hasChoosedItemNum--;
                            }
                            else {
                                if (this.optionalGoodsAddTempData[_parentIndex].hasChoosedItemNum <= this.optionalGoodsAddTempData[_parentIndex].choosedItemNum) {
                                    $checkbox.prop('checked', true);
                                    $parent.addClass('active');
                                    this.curPrice += parseInt(parseFloat($checkbox.attr('data-price')) * 1000);
                                    this.optionalGoodsAddTempData[_parentIndex].hasChoosedItemNum++;
                                } else {
                                    pop.message.show('本加项包最多能选择' + _equal + '项');
                                }
                            }
                        } else {
                            var $checkbox = $(_obj.currentTarget).parent('.product-more-items').find('.checkbox');
                            var $parent = $(_obj.currentTarget).parent('.product-more-items');
                            if (!$checkbox.prop('checked')) {
                                if (this.optionalGoodsAddTempData[_parentIndex].hasChoosedItemNum <= this.optionalGoodsAddTempData[_parentIndex].choosedItemNum) {
                                    $checkbox.prop('checked', true);
                                    $parent.addClass('active');
                                    this.curPrice += parseInt(parseFloat($checkbox.attr('data-price')) * 1000);
                                    this.optionalGoodsAddTempData[_parentIndex].hasChoosedItemNum++;
                                } else {
                                    pop.message.show('本加项包最多能选择' + _equal + '项');
                                }
                            }
                        }
                    },
                    goThird: function () {
                        if (this.isHasChoosedRequireGoodsAdd()) {
                            this.countRequireGoodsAdd();
                            publicData.curSecondPrice = this.curPrice;
                            router.push({path: '/affirm'});
                        } else {
                            pop.message.show('请按规则选择加项包');
                        }
                    },
                    countRequireGoodsAdd: function () {
                        publicData.optionsGoodsAddPkg = [];
                        $('.checkbox').each(function () {
                            if ($(this).prop('checked')) {
                                publicData.optionsGoodsAddPkg.push($(this).attr('data-id'));
                            }
                        });
                    },
                    isHasChoosedRequireGoodsAdd: function () {
                        var _bool = true;
                        for (var i = 0; i < this.optionalGoodsAddTempData.length; i++) {
                            if (this.optionalGoodsAddTempData[i].hasChoosedItemNum > this.optionalGoodsAddTempData[i].choosedItemNum) {
                                _bool = false;
                                break;
                            }
                        }
                        return _bool;
                    }
                },
                created: function () {//创建实例后
                    shan.tools.statisticsPing("370110");
                    this.optionalGoodsAddTempData[0] = {};
                    this.optionalGoodsAddTempData[0].choosedItemNum = this.optionalGoodsAddList.choosedItemNum;
                    this.optionalGoodsAddTempData[0].hasChoosedItemNum = 0;
                },
                mounted: function () {//创建dom后
                    //$('.tag-items-box').each(function () {
                    //    var _width = 30;
                    //    $(this).children('.item').each(function () {
                    //        _width += ($(this).get(0).offsetWidth + 8);
                    //    });
                    //    $(this).css('width', _width / 100 + 'rem');
                    //    new IScroll($(this).parent('.tag-items-box-wrap').get(0), {
                    //        scrollX: true,
                    //        scrollY: false,
                    //        mouseWheel: true,
                    //        preventDefault: false
                    //    });
                    //});
                },
                activated: function () {
                    if (!publicData.isNormal) {
                        router.replace({path: '/'});
                    }
                }
            };
            const third = {
                template: '#third',
                data: function () {
                    return {//数据
                        orderCode: '',
                        goodsCode: g_data.GOODS_D.goodsCode,
                        goodsName: g_data.GOODS_D.goodsName,
                        goodsItemTotal: g_data.GOODS_D.pkgItemNum,
                        goodsFeatureList: g_data.GOODS_D.goodsFeatureList,
                        requiredGoodsAddList: [],
                        optionalGoodsAddList: [],
                        curPrice: 0,
                    }
                },
                computed: {//计算属性
                    isFree: function () {
                        return this.curPrice == 0 ? true : false;
                    },
                    hasRequiredGoodsAddList: function () {
                        return this.requiredGoodsAddList.length > 0 ? true : false;
                    },
                    hasOptionalGoodsAddList: function () {
                        return this.optionalGoodsAddList.length > 0 ? true : false;
                    },
                    curPriceStr: function () {
                        return (this.curPrice / 1000).toFixed(2);
                    }
                },
                methods: {//方法
                    submitOrder: function () {
                        shan.tools.statisticsPing("370114");
                        if ($('#sDealCheckbox').prop('checked')) {
                            shan.ajax({
                                url: '/sz/biz/order_commit_async',
                                data: {
                                    goodsCode: this.goodsCode,
                                    pkgGroupCodes: publicData.goodsAddPkg.join(',')
                                },
                                success: function (json) {
                                    if (typeof json != 'undefined' && json.SZ_HEAD.RESP_CODE == 'S0000') {
                                        window.location.href = json.SZ_BODY.href;
                                    }
                                    else {
                                        pop.message.show(json.SZ_HEAD.RESP_MSG)
                                    }
                                }
                            })
                        } else {
                            pop.message.show('请您阅读并同意用户协议');
                        }
                    }

                },
                created: function () {//创建实例后
                    shan.tools.statisticsPing("370112");
                    $('body').on('click', '#sDealCheck', function () {
                        if ($('#sDealCheckbox').prop('checked')) {
                            $('#sDealCheckbox').prop('checked', false);
                        }
                        else {
                            $('#sDealCheckbox').prop('checked', true);
                        }
                    });
                    $('body').on('click', '#readRules', function () {
                        $('#pmask').removeClass('hidden');
                        $('#userAgreement').show();
                    });
                    $('body').on('click', '.pCloseBtn', function () {
                        $('#pmask').addClass('hidden');
                        $('#userAgreement').hide();
                    })
                },
                mounted: function () {//创建dom后

                },
                activated: function () {
                    if (!publicData.isNormal) {
                        router.replace({path: '/'});
                    }
                    publicData.goodsAddPkg = publicData.requireGoodsAddPkg.concat(publicData.optionsGoodsAddPkg);
                    this.requiredGoodsAddList = [];
                    this.optionalGoodsAddList = [];
                    this.curPrice = (publicData.curFirstPrice + publicData.curSecondPrice);
                    for (var i = 0; i < g_data.GOODS_D.requiredGoodsAddList.length; i++) {
                        for (var j = 0; j < g_data.GOODS_D.requiredGoodsAddList[i].pkgGroupList.length; j++) {
                            for (var x = 0; x < publicData.goodsAddPkg.length; x++) {
                                if (g_data.GOODS_D.requiredGoodsAddList[i].pkgGroupList[j].id == publicData.goodsAddPkg[x]) {
                                    this.requiredGoodsAddList.push(g_data.GOODS_D.requiredGoodsAddList[i].pkgGroupList[j]);
                                    break;
                                }
                            }
                        }
                    }
                    for (var i = 0; i < g_data.GOODS_D.optionalGoodsAddList.length; i++) {
                        for (var j = 0; j < g_data.GOODS_D.optionalGoodsAddList[i].pkgGroupList.length; j++) {
                            for (var x = 0; x < publicData.goodsAddPkg.length; x++) {
                                if (g_data.GOODS_D.optionalGoodsAddList[i].pkgGroupList[j].id == publicData.goodsAddPkg[x]) {
                                    this.optionalGoodsAddList.push(g_data.GOODS_D.optionalGoodsAddList[i].pkgGroupList[j]);
                                    break;
                                }
                            }
                        }
                    }
                }
            };

            const routes = [
                {path: '/', component: first},
                {path: '/add', component: second},
                {path: '/affirm', component: third}
            ];

            const router = new VueRouter({
                routes: routes
            });

            const app = new Vue({
                el: '#app',
                router: router
            });


        }
    };


    var run = function () {
        f.init();
    }

    //初始化函数
    exports.run = run;
});
define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/fastclick');
    require('lib/vue/vue');
    require('lib/share/wxshare');

    var f = {
        init: function () {
            shan.tools.statisticsPing("370104");
            $(function () {
                FastClick.attach(document.body);
                var controller=new wxController();
                controller.init(
                    ['onMenuShareTimeline','onMenuShareAppMessage'],
                    function(){
                        controller.configShareTimeline({
                            title:'员工体检线上预约系统',
                            link:window.location.href,
                            imgUrl:"https://"+window.location.host+"/static/images/activity/appointment_online/share_hw.png",
                            success:function(){},
                            cancel:function(){}
                        });
                        controller.configShareAppMessage({
                            title:'员工体检线上预约系统',
                            desc:'进入以完成预约、预约状态查询或修改、查看体检报告',
                            link:window.location.href,
                            imgUrl:"https://"+window.location.host+"/static/images/activity/appointment_online/share_hw.png",
                            type:'',
                            dataUrl:'',
                            success:function(){
                            },
                            cancel:function(){

                            }
                        });
                    }
                )
            });
        }
    };

    var vm = new Vue({
        el: '#vue',
        data: {//数据
            orderArr: [],
            comReportHref: "",
            activityCode: '',
            noOrder:  false
        },
        created: function () {//创建实例后
            try{
                var obj = JSON.parse(g_order);

                this.orderArr = this.formatData(obj.businessOrderList);
                this.companyName = obj.companyName;
                this.examineeName = obj.examineeName;
                this.activityCode = g_activityCode || '';
            }
            catch (e) {
                pop.alert('SORRY,订单错误！');
            }

        },
        methods: {//方法
            formatData: function(dataArr){
                var outArr = [];
                for(var i in dataArr){
                    var item = dataArr[i];
                    
                    //活动状态
                    if(item.activityStatus == '0'){ //活动未开始
                        item.productStatus = "unreserved";
                        item.productButtonStatus = "yo-btn-wait";
                        item.productButtonName = "活动未开始";
                        item.gotoHref = "#";

                        item.productDesc = "请于"+item.startTimeStr+"开始预约";
                        item.institDesc = "";
                        item.isShowBtn = true;
                    }
                    else if(item.activityStatus == '2'){ //活动已结束
                        
                        if(item.unifiedOrderStatus == "REPORT_UPLOAD"){
                            item.status == 3;
                            item.productStatus = "reported";
                            item.productButtonStatus = "yo-btn-report";
                            if(g_isDemo*1){
                                item.gotoHref = "/sz/report/demo?years=0";
                            }
                            else if(item.reportType == 1){
                                item.gotoHref = "/sz-health-report.php?orderCode=" + item.orderCode;
                            }
                            else {
                                item.gotoHref = "/sz/report/index?orderCode=" + item.orderCode;
                            }
                            
                            item.productDesc = "体检日期: "+item.reserveTimeStr;
                            item.institDesc = "体检地址: "+item.institName;
                            item.productButtonName = "查看报告";
                            item.isShowBtn = true;
                        }
                        else if(item.unifiedOrderStatus == "RESERVE_SUCC" || item.unifiedOrderStatus == "CHECK_FINISHED"){
                            item.productStatus = "reserved";
                            item.productButtonStatus = "yo-btn-wait";
                            item.productDesc = "已于"+item.endTimeStr+"结束";
                            item.productButtonName = "活动已结束";
                            item.institDesc = "";
                            item.isShowBtn = true;
                            item.gotoHref = "#";
                        }
                        else{
                            item.productStatus = "unreserved";
                            item.productButtonStatus = "yo-btn-wait";
                            item.productButtonName = "活动已结束";
                            item.gotoHref = "#";

                            item.productDesc = "已于"+item.endTimeStr+"结束";
                            item.institDesc = "";
                            item.isShowBtn = true;
                        }
                    }else{ //活动中
                        //订单状态
                        if(typeof item.unifiedOrderStatus == "undefined" 
                        || item.unifiedOrderStatus == "NOPAY_NORESERVE" 
                        || item.unifiedOrderStatus == "NEED_RESERVE_PAYED"){ //新订单 待预约 待支付
                            
                            item.productStatus = "unreserved";
                            item.productButtonStatus = "yo-btn-reserve";
                            item.productButtonName = "立即预约";
                            if(item.unifiedOrderStatus == "NEED_RESERVE_PAYED" ){ //支付完成 待预约
                                item.gotoHref = "/sz/biz/appointment?orderCode=" + item.orderCode+"&DATA=370105";
                            }
                            else{
                                item.gotoHref = "/sz/biz/order?goodsCode=" + item.goodsCode+"&DATA=370105";
                            }

                            item.productDesc = "请在"+item.endTimeStr+"前完成体检";
                            item.institDesc = "";
                            item.isShowBtn = true;
                        }else if(item.unifiedOrderStatus == "RESERVE_SUCC"){ //已预约
                            
                            item.productStatus = "reserved";
                            item.productButtonStatus = "yo-btn-reserve";
                            item.gotoHref = "/sz/biz/detail?orderCode=" + item.orderCode+"&DATA=370127";
                           
                            item.productDesc = "体检日期: "+item.reserveTimeStr;
                            item.institDesc = "体检地址: "+item.institName;
                            item.productButtonName = "查看预约信息";
                            item.isShowBtn = true;
                        }else if(item.unifiedOrderStatus == "REPORT_UPLOAD"){ //报告已出


                            item.productStatus = "reported";
                            item.productButtonStatus = "yo-btn-report";
                            if(g_isDemo*1){
                                item.gotoHref = "/sz/report/demo?years=0";
                            }
                            else if(item.reportType == 1){
                                item.gotoHref = "/sz-health-report.php?orderCode=" + item.orderCode;
                            }
                            else {
                                item.gotoHref = "/sz/report/index?orderCode=" + item.orderCode;
                            }
                            
                            item.productDesc = "体检日期: "+item.reserveTimeStr;
                            item.institDesc = "体检地址: "+item.institName;
                            item.productButtonName = "查看报告";
                            item.isShowBtn = true;
                        }
                        else if(item.unifiedOrderStatus == "CHECK_FINISHED"){ //等待报告
                            
                            item.productStatus = "wait";
                            item.productDesc = "体检日期: "+item.reserveTimeStr;
                            item.institDesc = "体检地址: "+item.institName;
                            item.isShowBtn = false;
                        }
                        else{
                            continue;
                        }
                    }
                    
                    outArr.push(item);
                }
                return outArr;
            },
            goto : function(index){
                window.location.href = this.orderArr[index].gotoHref;
            },
            goToFamily: function(){
                shan.tools.statisticsPing("370134");
                window.location.href = "/sz/biz/order_family?origin=1&activityCode=" + this.activityCode;
            }
        }

    });

    var run = function () {
        f.init();
    }

    //初始化函数
    exports.run = run;
});
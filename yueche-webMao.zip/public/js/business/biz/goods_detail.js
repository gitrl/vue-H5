define(function (require, exports, module) {
    require('lib/fastclick');

    var f = {
        init: function () {
            FastClick.attach(document.body);
        }
    };


    var run = function () {
        f.init();
    }

    //初始化函数
    exports.run = run;
});
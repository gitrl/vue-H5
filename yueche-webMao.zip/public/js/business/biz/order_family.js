define(function (require, exports, module) {
    //var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    //require('lib/fastclick');
    require('lib/vue/vue.min');
    var origin = shan.tools.getUrlParam('origin');

    var f = {
        init: function(){
            //$(function () {
                //FastClick.attach(document.body);
            //});
            var vm = new Vue({
                el: '#app',
                data: {
                    GOODS_DTO_LIST: [],     //套餐列表
                    pickedArr: [], //选中的套餐
                    isDisabled: origin !== '2',  //下一步按钮禁止的样式
                    isFull: origin === '2'   //下一步按钮直接返回的样式
                },
                created: function(){
                    shan.tools.statisticsPing('370139');
                    try{
                        this.GOODS_DTO_LIST = JSON.parse(g_GOODS_DTO_LIST);
                    }catch(e){
                        pop.alert('服务器繁忙，请稍后再试~');
                    }
                },
                methods: {
                    //点击套餐开关
                    pickCombo: function(index){
                        shan.tools.statisticsPing((370300 + parseInt(index)).toString());
                        if(origin !== '2'){ //从账户页进来
                            if(this.isDisabled && this.pickedArr.length == 1){//初次点选
                                this.isDisabled = false;
                                return;
                            }
                            if(!this.isDisabled && this.pickedArr.length == 1){//当前项撤销
                                this.isDisabled = true;
                                return;
                            }
                            if(this.isDisabled && this.pickedArr.length > 1){//点选其它项
                                this.isDisabled = false;
                                this.pickedArr.shift();
                            }
                        }

                        if(origin === '2'){//从预约完成后进来
                            if(this.isFull && this.pickedArr.length == 1){//初次点选
                                this.isFull = false;
                                return;
                            }
                            if(!this.isFull && this.pickedArr.length == 1){//撤销当前项
                                this.isFull = true;
                                return;
                            }
                            if(this.isFull && this.pickedArr.length > 1){//点选其它项
                                this.isFull = false;
                                this.pickedArr.shift();
                            }

                        }
                    },
                    //点击下一步
                    nextPage: function(){
                        if(this.isFull && !this.isDisabled){//预约完成后直接下一步
                            window.location.href = '/sz/biz/index';
                            shan.tools.statisticsPing('370138');
                        }else if(!this.isFull && !this.isDisabled){ //选择了套餐进入下单页
                            window.location.href = '/sz/biz/order?DATA=370105&goodsCode=' + this.pickedArr[0].goodsCode;
                            shan.tools.statisticsPing('370137');
                        }
                    }
                }
            })
        }
    };
    var run = function () {
        f.init();
    };
    exports.run = run;
});
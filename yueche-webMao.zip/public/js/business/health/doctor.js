define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    require('lib/fastclick');
    require('lib/jquery.lazyload.min.js');
    
    var f = {
        init: function () {
            var _self=this;
            $(function () {
                FastClick.attach(document.body);
            });
            $('img.lazy').lazyload({
                container: $(".flex"),
                effect: 'fadeIn',
                placeholder: "/static/images/avatar.jpg",
                threshold: 0
            });
            //页面展示
            shan.tools.statisticsPing("130014");
        },
        bindEvent : function(){

        }
    };

    var run = function () {
        f.init();
        //f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});

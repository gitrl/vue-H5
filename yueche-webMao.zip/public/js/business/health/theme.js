define(function (require, exports, module) {
    var $ = require('jquery');
    var shan = require('lib/shan_base');
    var pop = require('lib/dialog');
    var ping = require('lib/ping');
    require('lib/fastclick');
    require('lib/share/wxshare');
    var szAudio = require('lib/sz-audio');
    require('lib/jquery.lazyload.min.js');

    
    var opt = {
        ele: $('#szAudio').get(0),
        min: 0,
        step: 1,
        firstPingID: '130008',
        thirdPingID: '130009'
    };
    var keys = shan.tools.getUrlParam("themeId");
    var options = {
        title: '',
        desc: '',
        imgUrl: "http://m.shanzhen.me/static/images/health/theme_details/share/" + keys + '.jpg'
    };
    var f = {
        init: function () {
            $(function () {
                FastClick.attach(document.body);
                var _audio = szAudio.init(opt);
                //app加头部
                if(shan.tools.isMyApp()){
                    var header = require('lib/add-header');
                    header.run('善诊-父母健康找善诊');
                }
            });


            ping.pingInit({
                container: $(".flex"),
                el: $(".product")
            });

            $('img.lazy').lazyload({
                container: $(".flex"),
                effect: 'fadeIn',
                placeholder: "/static/images/avatar.jpg",
                threshold: 0
            });
            /*var vm = new Vue({
                el:'#theme',
                data: {
                    shareObject: {
                        'hidden': true
                    }
                },
                methods: {
                    shareFriend: function(){
                        this.shareObject = {
                            'hidden': false
                        };
                        shan.tools.statisticsPing("130010");
                    },
                    noMask: function(){
                        this.shareObject = {
                            'hidden': true
                        }
                    },
                    audioPlay: function(){
                        shan.tools.statisticsPing("130007");
                    }
                }
            });*/

            //页面展示
            shan.tools.statisticsPing("130006");
        },
        bindEvent : function(){
            //点击分享按钮
            $('.footer-share').on('click',function(e){
                $('.share-to-friend').removeClass('hidden');
                shan.tools.statisticsPing("130010");
            });
            //点击遮罩
            $('.share-to-friend').on('click',function(e){
                $(this).addClass('hidden');
            });
            //点击播放按钮
            $('#playBtn').on('click',function(e){
                shan.tools.statisticsPing("130007");
            });

            switch (keys.toString()){
                case '00010':
                    options.title = '脖子不舒服|是时候入手这些神器了';
                    options.desc = '善诊 「健康是一种生活态度」';
                    break;
                case '00020':
                    options.title = '胃疼福音|想怎么吃就怎么吃';
                    options.desc = '善诊 「健康是一种生活态度」';
                    break;
                case '00030':
                    options.title = '抗衰老三件套|让老妈越来越美';
                    options.desc = '父母健康找善诊';
                    break;
                case '00040':
                    options.title = '给全家老少的口罩选购指南';
                    options.desc = '善诊 「健康是一种生活态度」';
                    break;
                case '00050':
                    options.title = '给老妈老爸的礼物|腿脚灵便 远离骨质疏松';
                    options.desc = '父母健康找善诊';
                    break;
                case '00060':
                    options.title = '便秘终结者|爸妈不再受便秘之苦';
                    options.desc = '父母健康找善诊';
                    break;
                case '00070':
                    options.title = '降血脂|帮爸妈选择真正有效的鱼油';
                    options.desc = '父母健康找善诊';
                    break;
                case '00080':
                    options.title = '高血糖健康生活必备';
                    options.desc = '父母健康找善诊';
                    break;
                case '00090':
                    options.title = '一本神奇的书|据说看过的人都成功戒烟了';
                    options.desc = '善诊 「健康是一种生活态度」';
                    break;
                case '00100':
                    options.title = '给爸妈选购一款合适的血压计 ';
                    options.desc = '父母健康找善诊';
                    break;
                case '00110':
                    options.title = '【中老年体检】春节送给父母的首选礼物 ';
                    options.desc = '父母健康找善诊';
                    break;
                case '00120':
                    options.title = '【年轻人体检】你的身体被掏空了吗';
                    options.desc = '善诊 「健康是一种生活态度」';
                    break;
                default:
                    options.title = '父母健康找善诊';
                    options.desc = '善诊 「健康是一种生活态度」';
                    break;

            }
            //配置微信分享
            var controller = new wxController();
            controller.init(
                ['onMenuShareTimeline', 'onMenuShareAppMessage'],
                function () {
                    controller.configShareTimeline({
                        title: options.title, // 分享标题
                        desc:  options.desc, // 分享描述
                        imgUrl: options.imgUrl, //分享图标
                        success: function () {
                        },
                        cancel: function () {
                        }
                    });
                    controller.configShareAppMessage({
                        title: options.title, // 分享标题
                        desc:  options.desc, // 分享描述
                        imgUrl: options.imgUrl, //分享图标
                        type: '', // 分享类型,music、video或link，不填默认为link
                        dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
                        success: function () {
                        },
                        cancel: function () {
                        }
                    });
                }
            );
        }
    };

    var run = function () {
        f.init();
        f.bindEvent();
    }

    //初始化函数
    exports.run = run;
});

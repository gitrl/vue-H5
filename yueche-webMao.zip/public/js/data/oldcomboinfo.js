define(function (require, exports, module) {
    var COMBOINFO = {
        "PDT922304899": {
            "sname":"孝心套餐",
            "name": "关爱父母孝心套餐",
            "title": "基础体检套餐",
            "szPrice":235,
            "activityPrice":0
        },
        "PDT852914987": {
            "sname":"孝心升级",
            "name": "关爱父母孝心升级",
            "title": "中老年基础体检套餐",
            "szPrice":334,
            "activityPrice":99
        },
        "GDS94300" :{
            "sname":"标准套餐",
            "name": "关爱父母标准套餐",
            "title": "高性价比必查套餐",
            "szPrice":598,
            "activityPrice":398
        },
        "PDT023031628" :{
            "sname":"高级套餐",
            "name": "关爱父母高级套餐",
            "title": "升级多种肿瘤筛查",
            "szPrice":796,
            "activityPrice":596
        },
        "PDT269149814" :{
            "sname":"豪华套餐",
            "name": "关爱父母豪华套餐",
            "title": "适合中老年的全面健康检查",
            "szPrice":1698,
            "activityPrice":1398
        },
        "GDS110010102" :{
            "sname":"肿瘤专项",
            "name": "肿瘤专项套餐",
            "title": "高压人群常见癌症必查",
            "szPrice":586,
            "activityPrice":386
        },
        "GDS110010103" :{
            "sname":"妇科专项",
            "name": "妇科专项(HPV检测)",
            "title": "为已婚女性定制的体检套餐",
            "szPrice":599,
            "activityPrice":399
        },
        "GDS110010101" :{
            "sname":"办公族年度",
            "name": "办公族年度套餐",
            "szPrice":595,
            "activityPrice":395
        },
        "GDS110010104" :{
            "sname":"高级无忧",
            "name": "高级无忧套餐",
            "szPrice":718,
            "activityPrice":518
        },
        "GDS110010105" :{
            "sname":"尊享全面",
            "name": "尊享全面套餐",
            "szPrice":1398,
            "activityPrice":1198
        }
    };

    //初始化函数
    exports.data = COMBOINFO;
});
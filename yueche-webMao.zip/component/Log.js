"use strict";
var path = require('path');
var logConf = require('../config/log_conf.json');
var log4js = require('log4js');
var fs = require('fs');
var dgram = require('dgram');
var readline = require('readline');
var underscore = require('underscore');
var udpClient = dgram.createSocket('udp4');
var util = require('util');

var _appName =  process.argv[1].split(path.sep).pop();
var _port = + process.argv[2] || 0;
var _binName = util.format('%s_%s',_appName,_port);

logConf.CONFIG_OBJ.appenders.forEach(function(one){
    var pidTag = process.pid; 
    var szPattern = '|%d|%5.5p%|%m';
    if (one.type === 'logstashUDP') {
        one.fields = { 'bin' : _binName };
        one.layout = { 'type' : 'pattern' , 
                       'pattern' :  szPattern,};
     }
});

var _ = {};

_.logConf = { "appenders" : [], "replaceConsole" : true };

function replaceConsole() {

  log4js.configure(_.logConf);
  var udp_logger_norm = log4js.getLogger('udp_norm');
  udp_logger_norm.setLevel(logConf.LOG_LEVEL);

  function replaceWith(fn) {
    return function() {
      fn.apply(udp_logger_norm, arguments);
    };
  }
  ['log','debug','info','warn','error'].forEach(function (item) {
    console[item] = replaceWith(item === 'log' ? udp_logger_norm.info : udp_logger_norm[item]);
  });
  //console.error = function() {
        //var str = util.format.apply(this, arguments);
        ////错误输出到两个地方
        //udp_logger_norm.info(str);
        //udp_logger_high.error(str);
  //};
}

function recoverConsole() {
  //_.logConf.appenders = [logConf.CONSOLE_CONF];
  //log4js.configure(_.logConf);
  log4js.configure(logConf.CONSOLE_CONF);

 var logger = log4js.getLogger('console');
  //var logger = log4js.getLogger();
  //logger.setLevel(logConf.LOG_LEVEL);
  logger.level = logConf.LOG_LEVEL;
  //log4js.replaceConsole(logger);
}

var logInit = function( bUDP ) {
    if ( bUDP ) {
        _.logConf = underscore.clone(logConf.CONFIG_OBJ);
        console.log('Enable UDP Logger to %s:%d',_.logConf.appenders[0].host,_.logConf.appenders[0].port);
        replaceConsole();
    }else{
        _.logConf.appenders = [logConf.CONFIG_CONF];
        recoverConsole();
    }
    _.nowUDPStatus = bUDP;

    //处理console stack hook 要在log4js之后
    //delete require.cache[require.resolve('console-trace')];
    //var console_trace = require('console-trace')({always:true});
};


//定期发送心跳包 检查UDP Server是否存活 
//如果超过两次Gap 没有收到回包 则 切换回本地console log模式
_.tLastEcho = new Date().getTime();
_.GAP_TIME = 2000;
_.echoStr = 'gamer';
_.nowUDPStatus = false;

var checkUdpServer = function() {
    var udpPort = logConf.CONFIG_OBJ.appenders[0].port || null;
    var udpHost = logConf.CONFIG_OBJ.appenders[0].host || null;
    if (udpPort && udpHost) {
        var buffer = new Buffer(_.echoStr);
        udpClient.send(buffer,0,buffer.length,udpPort,udpHost,function(err) {
            if (err) { console.error(err); }
        });
    }

    var dtNow = new Date().getTime();
    if ((dtNow - _.tLastEcho) > (5 * _.GAP_TIME)) {
        if (_.nowUDPStatus === true) {
            //切换到标准输出
            logInit(false);
        }
    }else if (logConf.ENABLE_UDP === true && _.nowUDPStatus === false){
        //UDP服务器恢复 切换回UDP输出
        logInit(true);
    }
};

var initFunc = function() {

    logInit(logConf.ENABLE_UDP);

    udpClient.on('message',function(message,remote) {
        if (message.toString() === _.echoStr) {
            _.tLastEcho = new Date().getTime();
        }
    });
    
    if (logConf.ENABLE_UDP) {
        setTimeout(function() {
            setInterval(checkUdpServer,_.GAP_TIME);
        },1000);
    }
};

initFunc();

module.exports.logger = console;



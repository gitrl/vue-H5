/****************************************************************************************
功能 ： 用户访问记录 
        为了不影响响应时间 在请求结束后才记录日志
author : lancexiao
history : 2014-9-11 create
****************************************************************************************/
var onFinished = require('on-finished');
var util = require('util');
var path = require('path');

//日志最大长度
var defaultBufferDuration = 1000;

module.exports = function access(format, options) {
  if (format === undefined) {
    console.log('init log failed!')
  }

  options = options || {}

  // format function
  var fmt = compile(exports[format] || format || exports.default)

  // options
  var stream = options.stream || process.stdout
    , buffer = options.buffer;

  // buffering support
  if (buffer) {  
    var buf = []
    var timer = null
    var interval = 'number' == typeof buffer
      ? buffer
      : defaultBufferDuration
  }

  //文件过滤类型
  var filter = {
    pang:undefined,
    css:undefined,
    html:undefined,
    "/":0
  }

  function getExtention(filename){
    var p = filename.lastIndexOf(".") + 1;
    return filename.substring(p);
  }
  
  return function logger(req, res, next) {
    req._startAt = process.hrtime();
    req._startTime = new Date;
    req._remoteAddress = req.connection && req.connection.remoteAddress;

    function logRequest(){
      var line = fmt(exports, req, res);
      if (null == line) return;
      stream.write(line + '\n');
    };
    //检测请求的文件类型
    /*
    var type = getExtention(req.originalUrl);
    var fileCheck = filter[type];
    if(typeof(fileCheck) == "undefined")
    {
      next();
      return;
    }
    */
    //写访问日志
    onFinished(res, logRequest);
    //黑名单校验
    next();
  };
};

function compile(format) {
	
  if (typeof format === 'function') {
    // already compiled
    return format
  }

  if (typeof format !== 'string') {
    throw new TypeError('argument format must be a function or string')
  }

  var fmt = format.replace(/"/g, '\\"')
  var js = '  return "' + fmt.replace(/:([-\w]{2,})(?:\[([^\]]+)\])?/g, function(_, name, arg){
    return '"\n    + (tokens["' + name + '"](req, res, "' + arg + '") || "-") + "';
  }) + '";'

  return new Function('tokens, req, res', js);
};

exports.token = function(name, fn) {
  exports[name] = fn;
  return this;
};

exports.format = function(name, fmt){
  exports[name] = fmt;
  return this;
};

exports.format('dev', function(tokens, req, res){
  var color = 32; // green
  var status = res.statusCode;

  if (status >= 500) color = 31; // red
  else if (status >= 400) color = 33; // yellow
  else if (status >= 300) color = 36; // cyan

  var fn = compile('\x1b[0m:method :url \x1b[' + color + 'm:status \x1b[0m:response-time ms - :remote-addr\x1b - :referrer');

  return fn(tokens, req, res);
});

/**
 * request url
 */

exports.token('url', function(req){
  return req.originalUrl;
});

/**
 * request method
 */

exports.token('method', function(req){
  return req.method;
});

/**
 * response time in milliseconds
 */

exports.token('response-time', function(req, res){
  if (!res._header || !req._startAt) return '';
  var diff = process.hrtime(req._startAt);
  var ms = diff[0] * 1e3 + diff[1] * 1e-6;
  return ms.toFixed(3);
});

/**
 * UTC date
 */

exports.token('date', function(){
  return new Date().toUTCString();
});

/**
 * response status code
 */

exports.token('status', function(req, res){
  return res._header ? res.statusCode : null;
});

/**
 * normalized referrer
 */

exports.token('referrer', function(req){
  return req.headers['referer'] || req.headers['referrer'];
});

/**
 * remote address
 */

exports.token('remote-addr', function(req){
  if (req.ip) return req.ip;
  if (req._remoteAddress) return req._remoteAddress;
  if (req.connection) return req.connection.remoteAddress;
  return undefined;
});

/**
 * UA string
 */

exports.token('user-agent', function(req){
  return req.headers['user-agent'];
});

/**
 * request header
 */

exports.token('req', function(req, res, field){
	
  return req.headers[field.toLowerCase()];
});

/**
 * response header
 */

exports.token('res', function(req, res, field){
  return (res._headers || {})[field.toLowerCase()];
});
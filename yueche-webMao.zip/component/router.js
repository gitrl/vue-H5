var path = require('path');
var util = require('util');
var fs = require('fs');
const basePath = "./controller";
const urlRegex = '/';

initRoutes = function(app){
	//读取指定controller目录的文件名数组
	var list = fs.readdirSync(basePath);
    var pending = list.length;
    if (!pending) return;
    list.forEach(function(file) {

      var absfile = path.resolve("./controller", file);
      
      var stat = fs.statSync(absfile);
        if (stat && stat.isDirectory()) {
            //skip
        } else {
        	//加载router
            var controllerName = file.replace('.js','');
            var modulePath = path.join(basePath, file);
            var controller = require("../"+modulePath);

            app.use(urlRegex + controllerName, controller);
           
        }
      
    });
		
	
};

module.exports = initRoutes;


var path = require('path');
//require('./Log');
var promise = require('bluebird');
var needle = require('needle');
var needlePromisify = promise.promisifyAll(needle);
var router = require('./router');
var util = require('util');
var localConf = require('../config/config.json');
var fs = require('fs');
var sha1 = require('crypto-js/sha1');

var Comm = {
  g_band:{},
  g_car: {},
  config : function (Main) { //初始化
    //配置模板引擎
    Main.set('views', path.join(__dirname, '../views'));
    Main.set('view engine', 'ejs');

    console.log("init engine complete");
    Comm.getCarList();

    return function init(req, res, next) {
      Comm.init(req, res);
      next();
    }
  },
  getCarJson: function(id){
    if(Comm.getConf('initCarJson')){ //从网络获取
      needle.get("https://www.autohome.com.cn//ashx/AjaxIndexCarFind.ashx?type=3&value="+id, function(err, resp){

        console.log("id:" + id);
        if(resp && 200 == resp.statusCode){
          Comm.g_car[id] = JSON.parse(resp.body);

          if(Comm.getConf('initCarJson')){
            fs.writeFile('./car/'+id+'.json', resp.body, function(err) {
              if(err){
                console.log(err);
              }
            });
          }
        }
      });
    }else{
      fs.readFile('./car/'+id+'.json', function(err, data)  {
        if (err) throw err;
        //console.log(JSON.parse(data));
        Comm.g_car[id] = JSON.parse(data);
      });
    }

  },
  getCarList: function(){
    if(Comm.getConf('initCarJson')){ //从网络获取
      needle.get("https://www.autohome.com.cn/ashx/AjaxIndexCarFind.ashx?type=6", function(err, response){

        if(response && 200 == response.statusCode){
          Comm.g_band = JSON.parse(response.body);

          if(Comm.getConf('initCarJson')){
            console.log("create band Json file !!!");
            fs.writeFile('./car/band.json', response.body, function(err) {
              if(err){
                console.log(err);
              }
            });

          }
        }

      });
    }
    else{ //从本地获取
      Comm.g_band = JSON.parse(fs.readFileSync('./car/band.json'));
    }

    for(key in Comm.g_band.result.branditems){
      var id = Comm.g_band.result.branditems[key].id;
      Comm.getCarJson(id);
    }

  },
  getConf : function(key){

      if(localConf[key]){
        return localConf[key];
      }
      else{
          return "";
      }
  },
  initRoutes: function (Main) { //配置路由
    router(Main);
  },
  init: function(req, res) { //整个请求的公共入口
    console.log("Comm init!!!");
  },
  post: function(action, data, req){
      //设置请求URL
      var serverHost = Comm.getConf('defaultServerHost');

      var queryUrl = serverHost + '/' + action;

      //设置header
      var options = {
          json :true,
          open_timeout : 5000, //5 sec延迟
          headers : {
              cookies :JSON.stringify({key: "value"}),
              connection: 'Keep-Alive'   ,
              ugid: 1
          }
      };

      console.log('backend post url: '+queryUrl + ', data: ' + util.inspect(data));

      return needlePromisify.postAsync(queryUrl, data, options).then(function(response){
          console.log('query response: ' + util.inspect(response.body));

          if(response && 200 == response.statusCode){
              return response.body;
          }
          return false;
      }).catch(function(err) {
          console.error(err);
      });
  },
  get: function(){

  },
  createNonceStr: function(){
    var chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    var str = "";
    for(var i=0;i<16;i++){
      str += chars.substr(parseInt(Math.random()*15, 10) );
    }
    return str;
  },
  getSignature: function(ticket, timestamp, url, noc){
    var str = "jsapi_ticket=" + ticket + "&noncestr=" + noc + "&timestamp=" + timestamp + "&url=" + url;
    return sha1(str);
  }

};

module.exports = Comm;
